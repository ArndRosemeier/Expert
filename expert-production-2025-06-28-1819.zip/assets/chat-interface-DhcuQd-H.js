var g=Object.defineProperty;var f=(c,e,t)=>e in c?g(c,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):c[e]=t;var r=(c,e,t)=>f(c,typeof e!="symbol"?e+"":e,t);var u=(c,e,t)=>new Promise((s,o)=>{var i=d=>{try{a(t.next(d))}catch(n){o(n)}},l=d=>{try{a(t.throw(d))}catch(n){o(n)}},a=d=>d.done?s(d.value):Promise.resolve(d.value).then(i,l);a((t=t.apply(c,e)).next())});import{x as m}from"./index-UK0hBwmZ.js";import"./vendor-B_KD8BnD.js";const h=class h{constructor(e,t,s,o){r(this,"openRouterClient");r(this,"settingsManager");r(this,"messages",[]);r(this,"isStreamingResponse",!1);r(this,"currentStreamingMessageId",null);r(this,"selectedModelPurpose","creator");r(this,"customSystemPrompt",null);r(this,"chatTitle","AI Chat");r(this,"chatContainer",null);r(this,"messagesContainer",null);r(this,"messageInput",null);r(this,"sendButton",null);r(this,"stopButton",null);r(this,"modelPurposeSelect",null);this.openRouterClient=e,this.settingsManager=t,this.customSystemPrompt=s||null,this.chatTitle=o||"AI Chat"}loadLastUsedModel(){return u(this,null,function*(){try{const t=yield(yield m.getInstance()).get(h.LAST_CHAT_MODEL_KEY);t&&["creator","editor","rater"].includes(t)&&(this.selectedModelPurpose=t)}catch(e){console.warn("Failed to load last used chat model:",e)}})}saveLastUsedModel(){return u(this,null,function*(){try{yield(yield m.getInstance()).set(h.LAST_CHAT_MODEL_KEY,this.selectedModelPurpose)}catch(e){console.warn("Failed to save last used chat model:",e)}})}initialize(e){return u(this,null,function*(){this.chatContainer=e,yield this.loadLastUsedModel(),this.render(),this.setupEventListeners()})}render(){this.chatContainer&&(this.chatContainer.innerHTML=`
            <div class="chat-interface" style="
                display: flex;
                height: 100%;
                width: 100%;
                font-family: system-ui, -apple-system, sans-serif;
                background: #f7f7f8;
            ">
                <!-- Sidebar -->
                <div class="chat-sidebar" style="
                    width: 260px;
                    background: #171717;
                    color: white;
                    display: flex;
                    flex-direction: column;
                    border-right: 1px solid #333;
                ">
                    <div class="sidebar-header" style="
                        padding: 1rem;
                        border-bottom: 1px solid #333;
                    ">
                        <h3 style="
                            margin: 0;
                            font-size: 1.1rem;
                            font-weight: 600;
                            color: white;
                        ">${this.chatTitle}</h3>
                    </div>
                    <div class="sidebar-content" style="
                        flex: 1;
                        padding: 1rem;
                        display: flex;
                        flex-direction: column;
                        gap: 1rem;
                    ">
                        <button id="clear-chat-btn" style="
                            background: #333;
                            color: white;
                            border: 1px solid #555;
                            border-radius: 6px;
                            padding: 0.75rem;
                            font-size: 0.9rem;
                            cursor: pointer;
                            transition: background-color 0.2s;
                        " onmouseover="this.style.backgroundColor='#444'" onmouseout="this.style.backgroundColor='#333'">
                            Clear Chat
                        </button>
                        <div style="
                            font-size: 0.8rem;
                            color: #888;
                            line-height: 1.4;
                        ">
                            ${this.customSystemPrompt?'<p style="color: #10b981; margin-bottom: 0.5rem;"><strong>✓ Context Loaded</strong></p><p>This chat has specific context about your document structure. Ask questions about the content, request edits, or get suggestions.</p>':"<p>Select a model and start chatting. Your conversation will build context as you continue.</p>"}
                        </div>
                    </div>
                    <div class="sidebar-footer" style="
                        padding: 1rem;
                        border-top: 1px solid #333;
                        font-size: 0.8rem;
                        color: #888;
                        text-align: center;
                    ">
                        Expert AI Assistant
                    </div>
                </div>

                <!-- Main Chat Area -->
                <div class="chat-main" style="
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    background: white;
                ">
                    <!-- Messages Container -->
                    <div class="messages-container" id="messages-container" style="
                        flex: 1;
                        overflow-y: auto;
                        padding: 1rem;
                        display: flex;
                        flex-direction: column;
                        gap: 1rem;
                    ">
                        <!-- Messages will be populated here -->
                    </div>

                    <!-- Input Container -->
                    <div class="input-container" style="
                        border-top: 1px solid #e5e5e5;
                        padding: 1rem;
                        background: white;
                    ">
                        <!-- Model Selector -->
                        <div class="model-selector" style="
                            max-width: 800px;
                            margin: 0 auto 1rem auto;
                            display: flex;
                            align-items: center;
                            gap: 1rem;
                            padding: 0.75rem;
                            background: #f8f9fa;
                            border-radius: 8px;
                            border: 1px solid #e5e5e5;
                        ">
                            <label for="model-purpose-select" style="
                                font-size: 0.9rem;
                                font-weight: 500;
                                color: #374151;
                                white-space: nowrap;
                            ">Model:</label>
                            <select id="model-purpose-select" style="
                                flex: 1;
                                padding: 0.5rem;
                                border: 1px solid #d1d5db;
                                border-radius: 6px;
                                font-size: 0.9rem;
                                background: white;
                                color: #374151;
                            ">
                                <option value="creator">Creator: ${this.getModelDisplayName("creator")}</option>
                                <option value="editor">Editor: ${this.getModelDisplayName("editor")}</option>
                                <option value="rater">Rater: ${this.getModelDisplayName("rater")}</option>
                            </select>
                        </div>
                        <div class="input-wrapper" style="
                            max-width: 800px;
                            margin: 0 auto;
                            position: relative;
                        ">
                            <textarea 
                                id="message-input" 
                                placeholder="Type your message here..."
                                style="
                                    width: 100%;
                                    min-height: 60px;
                                    max-height: 200px;
                                    padding: 1rem 3rem 1rem 1rem;
                                    border: 1px solid #d1d5db;
                                    border-radius: 12px;
                                    resize: none;
                                    font-family: inherit;
                                    font-size: 1rem;
                                    line-height: 1.5;
                                    outline: none;
                                    box-sizing: border-box;
                                "
                            ></textarea>
                            <button 
                                id="send-btn" 
                                class="send-button"
                                style="
                                    position: absolute;
                                    right: 8px;
                                    bottom: 8px;
                                    background: #007bff;
                                    color: white;
                                    border: none;
                                    border-radius: 8px;
                                    width: 32px;
                                    height: 32px;
                                    cursor: pointer;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    transition: background-color 0.2s;
                                    opacity: 0.6;
                                "
                                disabled
                            >
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="m22 2-7 20-4-9-9-4Z"/>
                                    <path d="M22 2 11 13"/>
                                </svg>
                            </button>
                            <button 
                                id="stop-btn" 
                                class="stop-button"
                                style="
                                    position: absolute;
                                    right: 8px;
                                    bottom: 8px;
                                    background: #dc3545;
                                    color: white;
                                    border: none;
                                    border-radius: 8px;
                                    width: 32px;
                                    height: 32px;
                                    cursor: pointer;
                                    display: none;
                                    align-items: center;
                                    justify-content: center;
                                    transition: background-color 0.2s;
                                "
                            >
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                                    <rect x="6" y="6" width="12" height="12" rx="2"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `,this.messagesContainer=this.chatContainer.querySelector("#messages-container"),this.messageInput=this.chatContainer.querySelector("#message-input"),this.sendButton=this.chatContainer.querySelector("#send-btn"),this.stopButton=this.chatContainer.querySelector("#stop-btn"),this.modelPurposeSelect=this.chatContainer.querySelector("#model-purpose-select"),this.modelPurposeSelect&&(this.modelPurposeSelect.value=this.selectedModelPurpose))}setupEventListeners(){var t;if(!this.messageInput||!this.sendButton||!this.stopButton||!this.modelPurposeSelect)return;this.messageInput.addEventListener("input",()=>{this.autoResizeTextarea(),this.updateSendButtonState()}),this.messageInput.addEventListener("keydown",s=>{s.key==="Enter"&&!s.shiftKey&&(s.preventDefault(),!this.isStreamingResponse&&this.messageInput.value.trim()&&this.sendMessage())}),this.sendButton.addEventListener("click",()=>{!this.isStreamingResponse&&this.messageInput.value.trim()&&this.sendMessage()}),this.stopButton.addEventListener("click",()=>{this.stopGeneration()}),this.modelPurposeSelect.addEventListener("change",s=>{this.selectedModelPurpose=s.target.value,this.saveLastUsedModel()});const e=(t=this.chatContainer)==null?void 0:t.querySelector("#clear-chat-btn");e&&e.addEventListener("click",()=>{this.clearMessages()})}autoResizeTextarea(){this.messageInput&&(this.messageInput.style.height="auto",this.messageInput.style.height=`${Math.min(this.messageInput.scrollHeight,200)}px`)}updateSendButtonState(){if(!this.sendButton||!this.messageInput)return;const t=this.messageInput.value.trim().length>0&&!this.isStreamingResponse;this.sendButton.disabled=!t,this.sendButton.style.opacity=t?"1":"0.6",this.sendButton.style.cursor=t?"pointer":"not-allowed"}toggleButtons(e){!this.sendButton||!this.stopButton||(e?(this.sendButton.style.display="none",this.stopButton.style.display="flex"):(this.sendButton.style.display="flex",this.stopButton.style.display="none"))}sendMessage(){return u(this,null,function*(){var d;if(!this.messageInput||!this.messagesContainer)return;const e=this.messageInput.value.trim();if(!e||this.isStreamingResponse)return;this.messageInput.value="",this.autoResizeTextarea(),this.updateSendButtonState();const t={id:this.generateId(),role:"user",content:e,timestamp:new Date,isStreaming:!1};this.messages.push(t),this.displayMessage(t);const s={id:this.generateId(),role:"assistant",content:"",timestamp:new Date,isStreaming:!0};this.messages.push(s);const o=this.displayMessage(s);this.isStreamingResponse=!0,this.currentStreamingMessageId=s.id,this.toggleButtons(!0),this.updateSendButtonState();const i=[];this.customSystemPrompt&&i.push({role:"system",content:this.customSystemPrompt});const l=this.messages.filter(n=>!n.isStreaming).map(n=>({role:n.role,content:n.content}));i.push(...l),i.push({role:"user",content:e});const a={onStart:()=>{},onChunk:n=>{s.content+=n,this.updateMessageContent(o,s.content),this.scrollToBottom()},onComplete:n=>{s.content=n,s.isStreaming=!1,this.updateMessageContent(o,n),this.isStreamingResponse=!1,this.currentStreamingMessageId=null,this.toggleButtons(!1),this.updateSendButtonState()},onError:n=>{console.error("Chat streaming error:",n),s.content=`Error: ${n.message}`,s.isStreaming=!1,this.updateMessageContent(o,s.content),this.isStreamingResponse=!1,this.currentStreamingMessageId=null,this.toggleButtons(!1),this.updateSendButtonState()}};try{yield this.openRouterClient.chatStreamConversation(this.selectedModelPurpose,i,a)}catch(n){console.error("Failed to start chat stream:",n),(d=a.onError)==null||d.call(a,n instanceof Error?n:new Error("Unknown error"))}})}stopGeneration(){if(this.isStreamingResponse&&(this.openRouterClient.abort(),this.isStreamingResponse=!1,this.currentStreamingMessageId=null,this.toggleButtons(!1),this.updateSendButtonState(),this.currentStreamingMessageId)){const e=this.messages.find(t=>t.id===this.currentStreamingMessageId);e&&(e.isStreaming=!1,e.content+=`

[Generation stopped by user]`)}}displayMessage(e){if(!this.messagesContainer)throw new Error("Messages container not found");const t=document.createElement("div");t.id=`message-${e.id}`,t.className=`message message-${e.role}`;const s=e.role==="user";t.style.cssText=`
            display: flex;
            flex-direction: column;
            max-width: 70%;
            align-self: ${s?"flex-end":"flex-start"};
            margin-bottom: 1rem;
        `;const o=document.createElement("div");o.className="message-content",o.style.cssText=`
            background: ${s?"#007bff":"#f1f3f4"};
            color: ${s?"white":"#333"};
            padding: 0.75rem 1rem;
            border-radius: 18px;
            word-wrap: break-word;
            white-space: pre-wrap;
            line-height: 1.4;
            ${s?"border-bottom-right-radius: 4px;":"border-bottom-left-radius: 4px;"}
        `;const i=document.createElement("div");if(i.className="message-text",i.textContent=e.content,e.isStreaming){const a=document.createElement("span");if(a.className="streaming-cursor",a.textContent="▋",a.style.cssText=`
                animation: blink 1s infinite;
                margin-left: 2px;
            `,i.appendChild(a),!document.querySelector("#streaming-animation")){const d=document.createElement("style");d.id="streaming-animation",d.textContent=`
                    @keyframes blink {
                        0%, 50% { opacity: 1; }
                        51%, 100% { opacity: 0; }
                    }
                `,document.head.appendChild(d)}}o.appendChild(i),t.appendChild(o);const l=document.createElement("div");return l.className="message-timestamp",l.style.cssText=`
            font-size: 0.75rem;
            color: #888;
            margin-top: 0.25rem;
            text-align: ${s?"right":"left"};
        `,l.textContent=this.formatTimestamp(e.timestamp),t.appendChild(l),this.messagesContainer.appendChild(t),this.scrollToBottom(),t}updateMessageContent(e,t){const s=e.querySelector(".message-text");if(s){const o=e.id.replace("message-",""),i=this.messages.find(a=>a.id===o),l=s.querySelector(".streaming-cursor");s.textContent=t,l&&(i!=null&&i.isStreaming)&&s.appendChild(l)}}clearMessages(){this.messages=[],this.messagesContainer&&(this.messagesContainer.innerHTML="")}scrollToBottom(){this.messagesContainer&&(this.messagesContainer.scrollTop=this.messagesContainer.scrollHeight)}formatTimestamp(e){const s=new Date().getTime()-e.getTime(),o=Math.floor(s/6e4),i=Math.floor(s/36e5),l=Math.floor(s/864e5);return o<1?"Just now":o<60?`${o}m ago`:i<24?`${i}h ago`:l<7?`${l}d ago`:e.toLocaleDateString()}generateId(){return Math.random().toString(36).substring(2)+Date.now().toString(36)}getModelDisplayName(e){return this.openRouterClient.getModelForPurpose(e)||"Not configured"}getMessages(){return this.messages}};r(h,"LAST_CHAT_MODEL_KEY","expert_app_last_chat_model");let p=h;export{p as ChatInterface};
