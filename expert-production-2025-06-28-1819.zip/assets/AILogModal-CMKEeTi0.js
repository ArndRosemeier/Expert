var u=Object.defineProperty,y=Object.defineProperties;var v=Object.getOwnPropertyDescriptors;var f=Object.getOwnPropertySymbols;var x=Object.prototype.hasOwnProperty,w=Object.prototype.propertyIsEnumerable;var h=(i,r,e)=>r in i?u(i,r,{enumerable:!0,configurable:!0,writable:!0,value:e}):i[r]=e,b=(i,r)=>{for(var e in r||(r={}))x.call(r,e)&&h(i,e,r[e]);if(f)for(var e of f(r))w.call(r,e)&&h(i,e,r[e]);return i},m=(i,r)=>y(i,v(r));var c=(i,r,e)=>h(i,typeof r!="symbol"?r+"":r,e);var p=(i,r,e)=>new Promise((o,n)=>{var t=d=>{try{s(e.next(d))}catch(g){n(g)}},a=d=>{try{s(e.throw(d))}catch(g){n(g)}},s=d=>d.done?o(d.value):Promise.resolve(d.value).then(t,a);s((e=e.apply(i,r)).next())});import{B as k,A as L,u as l}from"./index-UK0hBwmZ.js";import"./vendor-B_KD8BnD.js";class A extends k{constructor(e={id:"ai-log-modal"},o={}){super(m(b({},e),{title:"AI Request Log",maxWidth:"1200px",width:"95vw",maxHeight:"90vh"}),m(b({},o),{onOpen:()=>p(this,null,function*(){var n;yield(n=o.onOpen)==null?void 0:n.call(o),yield this.loadLogs()})}));c(this,"aiLogService");c(this,"loadingDiv",null);c(this,"contentDiv",null);this.aiLogService=L.getInstance()}render(){const e=l("div",{classes:["ai-log-modal-container"],attributes:{style:`
                    display: flex;
                    flex-direction: column;
                    height: 85vh;
                    min-height: 600px;
                `}}),o=this.createHeader();e.appendChild(o);const n=this.createBody();return e.appendChild(n),e}createHeader(){const e=l("div",{classes:["ai-log-header"],attributes:{style:`
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1rem 0;
                    border-bottom: 1px solid #e5e7eb;
                    margin-bottom: 1.5rem;
                `}}),o=l("h2",{content:"AI Request Log",attributes:{style:`
                    margin: 0;
                    font-size: 1.5rem;
                    font-weight: 600;
                    color: #1f2937;
                `}}),n=l("div",{classes:["ai-log-controls"],attributes:{style:`
                    display: flex;
                    gap: 0.75rem;
                `}}),t=l("button",{classes:["btn-danger"],content:"Clear Log",attributes:{style:`
                    padding: 0.5rem 1rem;
                    border: none;
                    border-radius: 6px;
                    font-size: 0.875rem;
                    font-weight: 500;
                    cursor: pointer;
                    background-color: #ef4444;
                    color: white;
                    transition: background-color 0.2s;
                `}});return t.addEventListener("click",()=>p(this,null,function*(){if(confirm("Are you sure you want to clear all AI logs? This action cannot be undone."))try{yield this.aiLogService.clearAllLogs(),yield this.loadLogs()}catch(a){console.error("Failed to clear AI logs:",a),alert("Failed to clear logs. Please try again.")}})),t.addEventListener("mouseenter",()=>{t.style.backgroundColor="#dc2626"}),t.addEventListener("mouseleave",()=>{t.style.backgroundColor="#ef4444"}),n.appendChild(t),e.appendChild(o),e.appendChild(n),e}createBody(){const e=l("div",{classes:["ai-log-body"],attributes:{style:`
                    flex: 1;
                    overflow-y: auto;
                    min-height: 0;
                `}});return this.loadingDiv=l("div",{classes:["loading-state"],attributes:{id:"log-loading",style:`
                    text-align: center;
                    padding: 3rem 2rem;
                    color: #6b7280;
                `},content:"<p>Loading AI logs...</p>"}),this.contentDiv=l("div",{attributes:{id:"log-content",style:"display: none;"}}),e.appendChild(this.loadingDiv),e.appendChild(this.contentDiv),e}loadLogs(){return p(this,null,function*(){if(!this.loadingDiv||!this.contentDiv){console.error("Modal elements not initialized");return}try{this.loadingDiv.style.display="block",this.contentDiv.style.display="none",console.log("Loading AI logs...");const e=yield this.aiLogService.getAllLogs();if(console.log("Loaded logs:",e.length,"entries"),this.loadingDiv.style.display="none",this.contentDiv.style.display="block",e.length===0){this.contentDiv.innerHTML=`
                    <div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: #6b7280;">
                        <h3 style="margin: 0 0 0.5rem 0; color: #374151;">No AI logs found</h3>
                        <p>Enable AI logging in settings to start collecting request logs.</p>
                    </div>
                `;return}this.renderLogsTable(this.contentDiv,e)}catch(e){console.error("Failed to load AI logs:",e),this.loadingDiv.style.display="none",this.contentDiv.style.display="block",this.contentDiv.innerHTML=`
                <div class="empty-state" style="text-align: center; padding: 3rem 2rem; color: #6b7280;">
                    <h3 style="margin: 0 0 0.5rem 0; color: #374151;">Error loading logs</h3>
                    <p>Failed to load AI logs. Please try again. Error: ${e instanceof Error?e.message:"Unknown error"}</p>
                </div>
            `}})}renderLogsTable(e,o){const n=`
            <table class="ai-log-table" style="
                width: 100%;
                border-collapse: collapse;
                font-size: 0.875rem;
                background-color: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                overflow: hidden;
            ">
                <thead>
                    <tr>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Timestamp</th>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Purpose</th>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Model</th>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Duration</th>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Prompt</th>
                        <th style="background-color: #f3f4f6; color: #374151; font-weight: 600; padding: 0.75rem; text-align: left; border-bottom: 1px solid #e5e7eb; white-space: nowrap;">Response</th>
                    </tr>
                </thead>
                <tbody>
                    ${o.map(t=>`
                        <tr style="transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='#f9fafb'" onmouseout="this.style.backgroundColor='white'">
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; width: 150px; white-space: nowrap; color: #6b7280;">${this.formatTimestamp(t.timestamp)}</td>
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; width: 120px; font-weight: 500; color: #3b82f6;">${this.escapeHtml(t.purpose)}</td>
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; width: 150px; color: #6b7280; font-family: monospace; font-size: 0.8rem;">${this.escapeHtml(t.model)}</td>
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; width: 80px; text-align: right; color: #6b7280;">${t.requestDuration}ms</td>
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 300px; word-wrap: break-word; position: relative;">
                                <div class="log-text" data-full-content="${this.escapeHtmlAttribute(t.prompt)}" data-type="prompt" style="
                                    max-height: 100px;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    display: -webkit-box;
                                    -webkit-line-clamp: 4;
                                    -webkit-box-orient: vertical;
                                    cursor: pointer;
                                    color: #374151;
                                    transition: background-color 0.2s;
                                " onmouseover="this.style.backgroundColor='#f3f4f6'; this.style.borderRadius='4px'" onmouseout="this.style.backgroundColor='transparent'">
                                    ${this.escapeHtml(this.truncateText(t.prompt,200))}
                                </div>
                            </td>
                            <td style="padding: 0.75rem; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 300px; word-wrap: break-word; position: relative;">
                                <div class="log-text ${t.response.startsWith("ERROR:")?"error-response":""}" data-full-content="${this.escapeHtmlAttribute(t.response)}" data-type="response" style="
                                    max-height: 100px;
                                    overflow: hidden;
                                    text-overflow: ellipsis;
                                    display: -webkit-box;
                                    -webkit-line-clamp: 4;
                                    -webkit-box-orient: vertical;
                                    cursor: pointer;
                                    color: ${t.response.startsWith("ERROR:")?"#ef4444":"#374151"};
                                    font-style: ${t.response.startsWith("ERROR:")?"italic":"normal"};
                                    transition: background-color 0.2s;
                                " onmouseover="this.style.backgroundColor='#f3f4f6'; this.style.borderRadius='4px'" onmouseout="this.style.backgroundColor='transparent'">
                                    ${this.escapeHtml(this.truncateText(t.response,200))}
                                </div>
                            </td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        `;e.innerHTML=n,this.setupLogTextHandlers(e)}setupLogTextHandlers(e){e.querySelectorAll(".log-text").forEach(n=>{n.addEventListener("click",function(){this.classList.toggle("expanded"),this.classList.contains("expanded")?(this.style.maxHeight="none",this.style.webkitLineClamp="none"):(this.style.maxHeight="100px",this.style.webkitLineClamp="4")}),n.addEventListener("dblclick",function(t){t.stopPropagation(),t.preventDefault();const a=this.getAttribute("data-full-content")||"",s=this.getAttribute("data-type")||"content";C(a,s)})})}formatTimestamp(e){return new Date(e).toLocaleString("en-US",{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit",second:"2-digit"})}truncateText(e,o){return e.length<=o?e:e.substring(0,o)+"..."}escapeHtml(e){const o=document.createElement("div");return o.textContent=e,o.innerHTML}escapeHtmlAttribute(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}}function C(i,r){const e=document.querySelector(".log-overlay");e&&e.remove();const o=l("div",{classes:["log-overlay"],attributes:{style:`
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background-color: rgba(0, 0, 0, 0.75);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 30000;
            `}}),n=r.charAt(0).toUpperCase()+r.slice(1);o.innerHTML=`
        <div class="log-overlay-content" style="
            width: 95vw;
            max-width: 1200px;
            height: 85vh;
            background-color: white;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        ">
            <div class="log-overlay-header" style="
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1.5rem 2rem;
                border-bottom: 1px solid #e5e7eb;
                background-color: #f9fafb;
                border-radius: 12px 12px 0 0;
            ">
                <h3 style="
                    font-size: 1.25rem;
                    font-weight: 600;
                    color: #1f2937;
                    margin: 0;
                ">${n} Content</h3>
                <button class="log-overlay-close" style="
                    background: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 50%;
                    width: 32px;
                    height: 32px;
                    cursor: pointer;
                    font-size: 1.2rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: background-color 0.2s;
                ">&times;</button>
            </div>
            <div class="log-overlay-body" style="
                flex: 1;
                padding: 1.5rem 2rem;
                overflow-y: auto;
            ">
                <div class="log-overlay-text" style="
                    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
                    font-size: 0.9rem;
                    line-height: 1.6;
                    color: #374151;
                    white-space: pre-wrap;
                    word-break: break-word;
                    background-color: #f8fafc;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    padding: 1.5rem;
                ">${i}</div>
            </div>
        </div>
    `,o.addEventListener("click",s=>{s.target===o&&o.remove()});const t=o.querySelector(".log-overlay-close");t&&(t.addEventListener("click",()=>o.remove()),t.addEventListener("mouseenter",()=>{t.style.backgroundColor="#dc2626"}),t.addEventListener("mouseleave",()=>{t.style.backgroundColor="#ef4444"}));const a=s=>{s.key==="Escape"&&(o.remove(),document.removeEventListener("keydown",a))};document.addEventListener("keydown",a),document.body.appendChild(o)}function T(){new A().open().catch(r=>{console.error("❌ Failed to open AI Log modal:",r)})}export{A as AILogModal,T as openAILogModal};
