const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/AILogModal-CMKEeTi0.js","assets/vendor-B_KD8BnD.js","assets/index-BTgsZSUm.js","assets/ContextInfoModal-D7FTTwSD.js","assets/chat-interface-DhcuQd-H.js"])))=>i.map(i=>d[i]);
var ar=Object.defineProperty,lr=Object.defineProperties;var cr=Object.getOwnPropertyDescriptors;var rt=Object.getOwnPropertySymbols;var dr=Object.prototype.hasOwnProperty,hr=Object.prototype.propertyIsEnumerable;var Be=(a,e,t)=>e in a?ar(a,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[e]=t,T=(a,e)=>{for(var t in e||(e={}))dr.call(e,t)&&Be(a,t,e[t]);if(rt)for(var t of rt(e))hr.call(e,t)&&Be(a,t,e[t]);return a},ee=(a,e)=>lr(a,cr(e));var p=(a,e,t)=>Be(a,typeof e!="symbol"?e+"":e,t);var h=(a,e,t)=>new Promise((r,o)=>{var n=l=>{try{s(t.next(l))}catch(c){o(c)}},i=l=>{try{s(t.throw(l))}catch(c){o(c)}},s=l=>l.done?r(l.value):Promise.resolve(l.value).then(n,i);s((t=t.apply(a,e)).next())});import{v as ot}from"./vendor-B_KD8BnD.js";(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))r(o);new MutationObserver(o=>{for(const n of o)if(n.type==="childList")for(const i of n.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&r(i)}).observe(document,{childList:!0,subtree:!0});function t(o){const n={};return o.integrity&&(n.integrity=o.integrity),o.referrerPolicy&&(n.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?n.credentials="include":o.crossOrigin==="anonymous"?n.credentials="omit":n.credentials="same-origin",n}function r(o){if(o.ep)return;o.ep=!0;const n=t(o);fetch(o.href,n)}})();const pr="modulepreload",ur=function(a){return"/"+a},nt={},D=function(e,t,r){let o=Promise.resolve();if(t&&t.length>0){let i=function(c){return Promise.all(c.map(d=>Promise.resolve(d).then(u=>({status:"fulfilled",value:u}),u=>({status:"rejected",reason:u}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),l=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));o=i(t.map(c=>{if(c=ur(c),c in nt)return;nt[c]=!0;const d=c.endsWith(".css"),u=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${c}"]${u}`))return;const g=document.createElement("link");if(g.rel=d?"stylesheet":pr,d||(g.as="script"),g.crossOrigin="",g.href=c,l&&g.setAttribute("nonce",l),document.head.appendChild(g),d)return new Promise((f,w)=>{g.addEventListener("load",f),g.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${c}`)))})}))}function n(i){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=i,window.dispatchEvent(s),!s.defaultPrevented)throw i}return o.then(i=>{for(const s of i||[])s.status==="rejected"&&n(s.reason);return e().catch(n)})};function x(a){const e=document.getElementById(a);if(!e)throw new Error(`Could not find element with id: ${a}`);return e}const Ie=()=>x("test-modal-container"),gr=()=>x("test-modal-content"),Le=()=>x("new-project-modal-container"),fr=()=>x("new-project-modal-content");function mr(){const a=["main-app","settingsBtn","modal-container","modal-content","test-modal-container","test-modal-content","runTestsBtn","newProjectBtn","importProjectBtn","new-project-modal-container","new-project-modal-content"];for(const e of a)if(!document.getElementById(e))throw new Error(`Could not find required DOM element with id: ${e}`)}class C{constructor(e,t,r){p(this,"name");p(this,"hierarchyLevels");p(this,"scaffoldingDocuments");this.name=e,this.hierarchyLevels=t,this.scaffoldingDocuments=r}}let vt=null,J=[],Z=null,wt=null,xt=null,Ct=null,St=null,Et=!1,Pt=null;const $e=()=>vt,ve=()=>J,se=()=>J.find(a=>a.rootNode.id===Z)||null,Se=()=>wt,V=()=>xt,De=()=>Ct,Y=()=>St,yr=()=>Et,Tt=()=>Pt,kt=a=>vt=a,Ee=a=>{J.push(a),Z||(Z=a.rootNode.id)},Xe=a=>{J.find(t=>t.rootNode.id===a)&&(Z=a)},At=a=>{const e=J.findIndex(t=>t.rootNode.id===a);e>=0&&(J.splice(e,1),Z===a&&(Z=J.length>0?J[0].rootNode.id:null))},Nt=a=>wt=a,It=a=>xt=a,Lt=a=>Ct=a,Mt=a=>St=a,br=a=>Et=a,vr=a=>Pt=a,wr=()=>se(),xr=a=>{a?J.find(t=>t.rootNode.id===a.rootNode.id)?Z=a.rootNode.id:Ee(a):Z=null},Cr=Object.freeze(Object.defineProperty({__proto__:null,addProject:Ee,getActiveProject:se,getCurrentProject:wr,getIsAppRendered:yr,getModelSelector:De,getOpenRouterClient:Se,getOrchestrator:$e,getOrchestratorPrompts:Tt,getProjects:ve,getSettingsManager:V,getTemplateManager:Y,removeProject:At,setActiveProject:Xe,setCurrentProject:xr,setIsAppRendered:br,setModelSelector:Lt,setOpenRouterClient:Nt,setOrchestrator:kt,setOrchestratorPrompts:vr,setSettingsManager:It,setTemplateManager:Mt},Symbol.toStringTag,{value:"Module"}));class ye{constructor(e){p(this,"db",null);p(this,"config");this.config=e}initialize(){return h(this,null,function*(){return new Promise((e,t)=>{if(!window.indexedDB){t(new Error("IndexedDB is not supported in this browser"));return}const r=indexedDB.open(this.config.name,this.config.version);r.onerror=()=>{var o;t(new Error(`Failed to open IndexedDB: ${(o=r.error)==null?void 0:o.message}`))},r.onsuccess=()=>{this.db=r.result,this.db.onversionchange=()=>{var n;(n=this.db)==null||n.close(),console.warn("IndexedDB version changed, please reload the page")};const o=this.config.stores.filter(n=>!this.db.objectStoreNames.contains(n.name));if(o.length>0){const n=o.map(i=>i.name).join(", ");console.error(`Missing object stores: ${n}. Database may need to be recreated.`),this.db.close(),t(new Error(`Missing object stores: ${n}. Please clear browser data and try again.`));return}e()},r.onupgradeneeded=o=>{const n=o.target.result,i=o.oldVersion,s=o.newVersion;console.log(`IndexedDB upgrade needed: ${i} -> ${s}`);for(const l of this.config.stores){let c;if(n.objectStoreNames.contains(l.name)){console.log(`Store '${l.name}' already exists, skipping`);continue}if(console.log(`Creating object store: ${l.name}`),c=n.createObjectStore(l.name,{keyPath:l.keyPath,autoIncrement:l.autoIncrement}),l.indexes)for(const d of l.indexes)console.log(`Creating index: ${d.name} on ${l.name}`),c.createIndex(d.name,d.keyPath,d.options)}console.log("IndexedDB upgrade completed")}})})}close(){this.db&&(this.db.close(),this.db=null)}get(e,t){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((r,o)=>{const s=this.db.transaction([e],"readonly").objectStore(e).get(t);s.onsuccess=()=>{r(s.result)},s.onerror=()=>{var l;o(new Error(`Failed to get data: ${(l=s.error)==null?void 0:l.message}`))}})})}set(e,t,r){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((o,n)=>{const i=this.db.transaction([e],"readwrite"),s=i.objectStore(e),l=s.keyPath?T({[s.keyPath]:t},r):r,c=s.put(l,s.keyPath?void 0:t);i.oncomplete=()=>{o()},i.onerror=()=>{var d;n(new Error(`Failed to set data: ${(d=i.error)==null?void 0:d.message}`))},c.onerror=()=>{var d;n(new Error(`Failed to set data: ${(d=c.error)==null?void 0:d.message}`))}})})}delete(e,t){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((r,o)=>{const s=this.db.transaction([e],"readwrite").objectStore(e).delete(t);s.onsuccess=()=>{r()},s.onerror=()=>{var l;o(new Error(`Failed to delete data: ${(l=s.error)==null?void 0:l.message}`))}})})}getAll(e){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((t,r)=>{const i=this.db.transaction([e],"readonly").objectStore(e).getAll();i.onsuccess=()=>{t(i.result)},i.onerror=()=>{var s;r(new Error(`Failed to get all data: ${(s=i.error)==null?void 0:s.message}`))}})})}clear(e){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((t,r)=>{const i=this.db.transaction([e],"readwrite").objectStore(e).clear();i.onsuccess=()=>{t()},i.onerror=()=>{var s;r(new Error(`Failed to clear store: ${(s=i.error)==null?void 0:s.message}`))}})})}bulkSet(e,t){return h(this,null,function*(){if(!this.db)throw new Error("Database not initialized");return new Promise((r,o)=>{const n=this.db.transaction([e],"readwrite"),i=n.objectStore(e);if(t.length===0){r();return}n.oncomplete=()=>{r()},n.onerror=()=>{var l;o(new Error(`Bulk operation failed: ${(l=n.error)==null?void 0:l.message}`))};for(const l of t){const c=i.keyPath?T({[i.keyPath]:l.key},l.value):l.value,d=i.put(c,i.keyPath?void 0:l.key);d.onerror=()=>{var u;o(new Error(`Failed to set item ${l.key}: ${(u=d.error)==null?void 0:u.message}`))}}})})}getStorageEstimate(){return h(this,null,function*(){if("storage"in navigator&&"estimate"in navigator.storage){const e=yield navigator.storage.estimate();return{quota:e.quota||0,usage:e.usage||0}}return{quota:0,usage:0}})}isInitialized(){return this.db!==null}}class Sr{constructor(e){p(this,"indexedDBService");p(this,"storeName","keyValue");this.indexedDBService=e}get(e){return h(this,null,function*(){try{const t=yield this.indexedDBService.get(this.storeName,e);return t==null?void 0:t.value}catch(t){throw console.error("IndexedDB get error:",t),new Error(`Failed to get data from storage: ${t instanceof Error?t.message:t}`)}})}set(e,t){return h(this,null,function*(){try{yield this.indexedDBService.set(this.storeName,e,{key:e,value:t})}catch(r){throw console.error("IndexedDB set error:",r),new Error(`Failed to save to IndexedDB: ${r}`)}})}delete(e){return h(this,null,function*(){try{yield this.indexedDBService.delete(this.storeName,e)}catch(t){throw console.error("IndexedDB delete error:",t),new Error(`Failed to delete data from storage: ${t instanceof Error?t.message:t}`)}})}getAll(e){return h(this,null,function*(){const t={};try{const r=yield this.indexedDBService.getAll(this.storeName);for(const o of r)(!e||o.key.startsWith(e))&&(t[o.key]=o.value)}catch(r){throw console.error("IndexedDB getAll error:",r),new Error(`Failed to get all data from storage: ${r instanceof Error?r.message:r}`)}return t})}clear(){return h(this,null,function*(){try{yield this.indexedDBService.clear(this.storeName)}catch(e){throw console.error("IndexedDB clear error:",e),new Error(`Failed to clear storage: ${e instanceof Error?e.message:e}`)}})}getUsage(){return h(this,null,function*(){try{return yield this.indexedDBService.getStorageEstimate()}catch(e){return console.error("Error getting IndexedDB usage:",e),{quota:0,usage:0}}})}isIndexedDB(){return!0}}const R=class R{static getInstance(){return h(this,null,function*(){return R.instance?R.instance:R.initPromise?R.initPromise:(R.initPromise=R.createStorageService(),R.instance=yield R.initPromise,R.initPromise=null,R.instance)})}static createStorageService(){return h(this,null,function*(){if(!R.isIndexedDBSupported())throw new Error("IndexedDB is not supported in this browser. This application requires IndexedDB for data storage.");const e={name:"ExpertAppDB",version:3,stores:[{name:"keyValue",keyPath:"key"},{name:"projects",keyPath:"id",indexes:[{name:"by-lastModified",keyPath:"lastModified"},{name:"by-template",keyPath:"templateName"}]},{name:"aiLogs",keyPath:"id",indexes:[{name:"by-timestamp",keyPath:"timestamp"},{name:"by-purpose",keyPath:"purpose"}]}]};let t=new ye(e);try{yield t.initialize()}catch(r){console.warn("IndexedDB initialization failed, attempting database reset:",r),t.close(),yield R.deleteDatabase(e.name),t=new ye(e),yield t.initialize()}return new Sr(t)})}static isIndexedDBSupported(){return typeof window!="undefined"&&"indexedDB"in window&&window.indexedDB!==null}static reset(){R.instance=null,R.initPromise=null}static deleteDatabase(e){return new Promise((t,r)=>{if(!window.indexedDB){t();return}const o=indexedDB.deleteDatabase(e);o.onsuccess=()=>{t()},o.onerror=()=>{var n;console.error(`Failed to delete database '${e}':`,o.error),r(new Error(`Failed to delete database: ${(n=o.error)==null?void 0:n.message}`))},o.onblocked=()=>{console.warn("Database deletion blocked. Close all tabs and try again."),setTimeout(t,1e3)}})}static getStorageInfo(){return h(this,null,function*(){if(R.isIndexedDBSupported())try{const t=yield(yield R.getInstance()).getUsage();return{type:"indexedDB",available:!0,quota:t.quota,usage:t.usage}}catch(e){return{type:"indexedDB",available:!1}}else return{type:"indexedDB",available:!1}})}};p(R,"instance",null),p(R,"initPromise",null);let $=R;const Q=Object.freeze(Object.defineProperty({__proto__:null,StorageService:$},Symbol.toStringTag,{value:"Module"})),oe=class oe{constructor(){p(this,"indexedDBService",null);p(this,"storeName","aiLogs")}static getInstance(){return oe.instance||(oe.instance=new oe),oe.instance}initialize(){return h(this,null,function*(){try{const e=yield $.getInstance();if(this.indexedDBService=e.indexedDBService,!this.indexedDBService)throw console.error("❌ Failed to get IndexedDBService from StorageService"),new Error("IndexedDBService not available");console.log("✅ AILogService initialized successfully")}catch(e){throw console.error("❌ Failed to initialize AILogService:",e),e}})}ensureInitialized(){return h(this,null,function*(){if(this.indexedDBService||(yield this.initialize()),!this.indexedDBService)throw new Error("Failed to initialize AILogService - IndexedDBService is not available")})}addLogEntry(e){return h(this,null,function*(){yield this.ensureInitialized();const t=ee(T({},e),{id:`ai-log-${Date.now()}-${Math.random().toString(36).substr(2,9)}`});try{yield this.indexedDBService.set(this.storeName,t.id,t)}catch(r){console.error("Failed to add AI log entry:",r)}})}getAllLogs(){return h(this,null,function*(){yield this.ensureInitialized();try{const e=yield this.indexedDBService.getAll(this.storeName);return console.log(`📋 Retrieved ${e.length} AI log entries from IndexedDB`),e.sort((t,r)=>new Date(r.timestamp).getTime()-new Date(t.timestamp).getTime())}catch(e){return console.error("Failed to retrieve AI logs:",e),[]}})}clearAllLogs(){return h(this,null,function*(){yield this.ensureInitialized();try{yield this.indexedDBService.clear(this.storeName),console.log("🗑️ All AI logs cleared from IndexedDB")}catch(e){console.error("Failed to clear AI logs:",e)}})}getLogsByPurpose(e){return h(this,null,function*(){return(yield this.getAllLogs()).filter(r=>r.purpose===e)})}getRecentLogs(e=50){return h(this,null,function*(){return(yield this.getAllLogs()).slice(0,e)})}};p(oe,"instance",null);let Ue=oe;function Oe(a){return Ne(a).replace(/\n/g,"<br>")}function Ne(a){const e=document.createElement("div");return e.textContent=a,e.innerHTML}function it(a){return a.replace(/[<>:"/\\|?*]/g,"_").replace(/\s+/g,"_")}function le(a){a.style.height="auto",a.style.height=a.scrollHeight+"px"}function m(a,e={}){const t=document.createElement(a);return e.classes&&t.classList.add(...e.classes),e.attributes&&Object.entries(e.attributes).forEach(([r,o])=>{t.setAttribute(r,o)}),e.content&&(t.textContent=e.content),e.innerHTML&&(t.innerHTML=e.innerHTML),t}function st(a,e,t,r){a.addEventListener(e,t),r.push(()=>a.removeEventListener(e,t))}const re={overlay:`
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 15000;
    `,content:`
        background-color: white;
        padding: 2.5rem;
        border-radius: 12px;
        max-width: 80vw;
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
    `,button:`
        padding: 0.75rem 1.5rem;
        border: none;
        border-radius: 8px;
        font-size: 0.875rem;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
    `,primaryButton:`
        background-color: #3b82f6;
        color: white;
    `,secondaryButton:`
        background-color: #6b7280;
        color: white;
    `,outlineButton:`
        border: 1px solid #d1d5db;
        background: transparent;
        color: #6b7280;
    `};class Qe{constructor(e,t={}){p(this,"id");p(this,"config");p(this,"hooks");p(this,"state");p(this,"element",null);p(this,"cleanupHandlers",[]);this.id=e.id,this.config=T({closable:!0,backdrop:!0},e),this.hooks=t,this.state={isOpen:!1,isOpening:!1,isClosing:!1}}open(){return h(this,null,function*(){var e,t;if(!(this.state.isOpen||this.state.isOpening)){this.state.isOpening=!0;try{yield this.createModal(),yield(t=(e=this.hooks).onOpen)==null?void 0:t.call(e),this.state.isOpen=!0,this.state.isOpening=!1}catch(r){throw this.state.isOpening=!1,r}}})}close(){return h(this,null,function*(){var e,t;if(!(!this.state.isOpen||this.state.isClosing)){this.state.isClosing=!0;try{yield(t=(e=this.hooks).onClose)==null?void 0:t.call(e),this.destroyModal(),this.state.isOpen=!1,this.state.isClosing=!1}catch(r){throw this.state.isClosing=!1,r}}})}destroy(){this.cleanup(),this.element&&this.element.parentNode&&this.element.parentNode.removeChild(this.element),this.element=null}handleAction(e,t){return h(this,null,function*(){var r,o;yield(o=(r=this.hooks).onAction)==null?void 0:o.call(r,e,t)})}createModal(){return h(this,null,function*(){if(this.element)return;this.element=m("div",{classes:["modal-overlay"],attributes:{"data-modal-id":this.id,style:re.overlay}});const e=m("div",{classes:["modal-content"],attributes:{style:this.buildContentStyle()}}),t=this.render();e.appendChild(t),this.config.closable&&this.addCloseButton(e),this.element.appendChild(e),this.setupEventHandlers(),document.body.appendChild(this.element),requestAnimationFrame(()=>{this.element&&(this.element.style.opacity="1")})})}destroyModal(){this.element&&(this.element.style.opacity="0",setTimeout(()=>{this.cleanup(),this.element&&this.element.parentNode&&this.element.parentNode.removeChild(this.element),this.element=null},200))}setupEventHandlers(){if(this.element&&(this.config.backdrop&&this.config.closable&&st(this.element,"click",e=>{e.target===this.element&&this.close()},this.cleanupHandlers),this.config.closable)){const e=t=>{t.key==="Escape"&&this.close()};document.addEventListener("keydown",e),this.cleanupHandlers.push(()=>{document.removeEventListener("keydown",e)})}}addCloseButton(e){const t=m("button",{classes:["modal-close"],attributes:{type:"button","aria-label":"Close modal",style:`
                    position: absolute;
                    top: 1rem;
                    right: 1rem;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    cursor: pointer;
                    color: #6b7280;
                    width: 2rem;
                    height: 2rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 0.375rem;
                    transition: background-color 0.2s;
                `},content:"×"});t.addEventListener("mouseenter",()=>{t.style.backgroundColor="#f3f4f6"}),t.addEventListener("mouseleave",()=>{t.style.backgroundColor="transparent"}),st(t,"click",()=>void this.close(),this.cleanupHandlers),e.style.position="relative",e.appendChild(t)}buildContentStyle(){let e=re.content;return this.config.width&&(e+=`width: ${this.config.width};`),this.config.height&&(e+=`height: ${this.config.height};`),this.config.maxWidth&&(e+=`max-width: ${this.config.maxWidth};`),this.config.maxHeight&&(e+=`max-height: ${this.config.maxHeight};`),e}cleanup(){this.cleanupHandlers.forEach(e=>e()),this.cleanupHandlers=[]}getState(){return T({},this.state)}isOpen(){return this.state.isOpen}}class Er{constructor(){p(this,"handlers",new Map)}emit(e,t){const r=this.handlers.get(e);r&&r.forEach(o=>o(t))}on(e,t){this.handlers.has(e)||this.handlers.set(e,[]),this.handlers.get(e).push(t)}off(e,t){const r=this.handlers.get(e);if(r){const o=r.indexOf(t);o>-1&&r.splice(o,1)}}}const ne=class ne{constructor(){p(this,"modals",new Map);p(this,"eventEmitter",new Er);p(this,"activeModals",[])}static getInstance(){return ne.instance||(ne.instance=new ne),ne.instance}register(e){if(this.modals.has(e.id))throw new Error(`Modal with id '${e.id}' is already registered`);const t={modal:e,state:{isOpen:!1,isOpening:!1,isClosing:!1}};this.modals.set(e.id,t)}unregister(e){const t=this.modals.get(e);t&&(t.state.isOpen&&t.modal.close(),this.removeFromActive(e),t.modal.destroy(),this.modals.delete(e))}get(e){var t;return(t=this.modals.get(e))==null?void 0:t.modal}getState(e){var t;return(t=this.modals.get(e))==null?void 0:t.state}updateState(e,t){const r=this.modals.get(e);r&&(r.state=T(T({},r.state),t))}open(e){return h(this,null,function*(){const t=this.modals.get(e);if(!t)throw new Error(`Modal with id '${e}' is not registered`);this.hasOpenModal()&&!this.isModalOpen(e)&&(yield this.closeAll()),this.updateState(e,{isOpening:!0}),this.eventEmitter.emit("modal:opening",{id:e,config:t.modal.config});try{yield t.modal.open(),this.updateState(e,{isOpen:!0,isOpening:!1}),this.addToActive(e),this.eventEmitter.emit("modal:opened",{id:e})}catch(r){throw this.updateState(e,{isOpening:!1}),r}})}close(e){return h(this,null,function*(){const t=this.modals.get(e);if(!(!t||!t.state.isOpen)){this.updateState(e,{isClosing:!0}),this.eventEmitter.emit("modal:closing",{id:e});try{yield t.modal.close(),this.updateState(e,{isOpen:!1,isClosing:!1}),this.removeFromActive(e),this.eventEmitter.emit("modal:closed",{id:e})}catch(r){throw this.updateState(e,{isClosing:!1}),r}}})}closeAll(){return h(this,null,function*(){const e=this.activeModals.slice();yield Promise.all(e.map(t=>this.close(t)))})}hasOpenModal(){return this.activeModals.length>0}isModalOpen(e){return this.activeModals.includes(e)}getOpenModals(){return[...this.activeModals]}getActiveModal(){const e=this.activeModals[this.activeModals.length-1];return e?this.get(e):void 0}emitAction(e,t,r){this.eventEmitter.emit("modal:action",{id:e,action:t,data:r})}on(e,t){this.eventEmitter.on(e,t)}off(e,t){this.eventEmitter.off(e,t)}getAllModalIds(){return Array.from(this.modals.keys())}clear(){this.closeAll(),this.modals.forEach(e=>e.modal.destroy()),this.modals.clear(),this.activeModals=[]}addToActive(e){this.activeModals.includes(e)||this.activeModals.push(e)}removeFromActive(e){const t=this.activeModals.indexOf(e);t>-1&&this.activeModals.splice(t,1)}};p(ne,"instance");let qe=ne;function Pr(){return qe.getInstance()}var $t=(a=>(a.Single="single",a.Hierarchy="hierarchy",a.Leaves="leaves",a))($t||{}),O=(a=>(a.HTML="html",a.Markdown="markdown",a.Plain="plain",a.Reimport="reimport",a))(O||{});class Tr{export(e,t){return h(this,null,function*(){let r,o,n;if(t.format===O.Reimport)r=this.exportNodeForReimport(e),o=t.filename||`${it(e.title)}_export.json`,n="application/json";else{r=this.exportNodeContent(e,t.scope,t.format);const i=this.getFileExtension(t.format);o=t.filename||`${it(e.title)}_${t.scope}.${i}`,n=this.getMimeType(t.format)}return{content:r,filename:o,mimeType:n}})}generateContent(e,t,r){switch(t){case O.HTML:return this.generateHtmlContent(e,r||"Export");case O.Markdown:return this.generateMarkdownContent(e);case O.Plain:return this.generatePlainTextContent(e);default:throw new Error(`Unsupported format: ${t}`)}}downloadFile(e){const t=new Blob([e.content],{type:e.mimeType}),r=URL.createObjectURL(t),o=document.createElement("a");o.href=r,o.download=e.filename,document.body.appendChild(o),o.click(),document.body.removeChild(o),URL.revokeObjectURL(r)}performExport(e,t,r,o){return h(this,null,function*(){const n={scope:r,format:o},i=yield this.export(t,n);this.downloadFile(i),alert(`Successfully exported "${t.title}" as ${i.filename}`)})}exportNodeForReimport(e){var r,o;const t={title:e.title,content:e.content,context:(r=e.context)!=null?r:void 0,generationPrompt:(o=e.generationPrompt)!=null?o:void 0,level:e.level,template:e.template,children:e.children.map(n=>this.exportNodeForReimportRecursive(n))};return JSON.stringify(t,null,2)}exportNodeForReimportRecursive(e){return{id:e.id,title:e.title,content:e.content,context:e.context,level:e.level,template:e.template,generationPrompt:e.generationPrompt,generationChildrenCount:e.generationChildrenCount,childLevelName:e.childLevelName,children:e.children.map(t=>this.exportNodeForReimportRecursive(t))}}exportNodeContent(e,t,r){return t===$t.Leaves?this.exportLowestLayer(e,r):this.exportAllLayers(e,r)}exportLowestLayer(e,t){const r=this.findLeafNodes(e);switch(t){case O.HTML:return this.generateHtmlContent(r,"Lowest Layer Content");case O.Markdown:return this.generateMarkdownContent(r);case O.Plain:return this.generatePlainTextContent(r);default:throw new Error(`Unsupported format: ${t}`)}}exportAllLayers(e,t){switch(t){case O.HTML:return this.generateHtmlHierarchy(e);case O.Markdown:return this.generateMarkdownHierarchy(e);case O.Plain:return this.generatePlainTextHierarchy(e);default:throw new Error(`Unsupported format: ${t}`)}}findLeafNodes(e){if(e.children.length===0)return[e];const t=[];for(const r of e.children)t.push(...this.findLeafNodes(r));return t}generateHtmlContent(e,t){let r=`<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${t}</title>
    <style>
        body { font-family: Georgia, serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 2rem; }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 0.5rem; }
        h2 { color: #34495e; margin-top: 2rem; }
        .content { margin-bottom: 2rem; padding: 1rem; background-color: #f8f9fa; border-left: 4px solid #007bff; }
        .meta { font-size: 0.9rem; color: #6c757d; margin-bottom: 0.5rem; }
    </style>
</head>
<body>
    <h1>${t}</h1>`;for(const o of e)o.content&&o.content.trim()&&(r+=`
    <h2>${Ne(o.title)}</h2>
    <div class="content">
        <div class="meta">Level: ${o.level}</div>
        ${Oe(o.content)}
    </div>`);return r+=`
</body>
</html>`,r}generateHtmlHierarchy(e,t=1){if(t===1){let r=`<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${Ne(e.title)} - Complete Hierarchy</title>
    <style>
        body { font-family: Georgia, serif; line-height: 1.6; max-width: 800px; margin: 0 auto; padding: 2rem; }
        h1 { color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 0.5rem; }
        h2, h3, h4, h5, h6 { color: #34495e; margin-top: 2rem; }
        .content { margin-bottom: 1.5rem; padding: 1rem; background-color: #f8f9fa; border-left: 4px solid #007bff; }
        .summary { margin-bottom: 1rem; padding: 0.75rem; background-color: #e7f3ff; border-left: 4px solid #0056b3; font-style: italic; }
        .level-${t} { margin-left: ${(t-1)*1.5}rem; }
    </style>
</head>
<body>`;return r+=this.generateHtmlHierarchyRecursive(e,t),r+=`
</body>
</html>`,r}else return this.generateHtmlHierarchyRecursive(e,t)}generateHtmlHierarchyRecursive(e,t){const r=`h${Math.min(t+1,6)}`;let o=`
    <div class="level-${t}">
        <${r}>${Ne(e.title)}</${r}>`;e.context&&e.context.trim()&&(o+=`
        <div class="summary">${Oe(e.context)}</div>`),e.content&&e.content.trim()&&(o+=`
        <div class="content">${Oe(e.content)}</div>`);for(const n of e.children)o+=this.generateHtmlHierarchyRecursive(n,t+1);return o+=`
    </div>`,o}generateMarkdownContent(e){let t=`# Lowest Layer Content

`;for(const r of e)r.content&&r.content.trim()&&(t+=`## ${r.title}

`,t+=`*Level: ${r.level}*

`,t+=`${r.content}

`,t+=`---

`);return t}generateMarkdownHierarchy(e,t=1){let o=`${"#".repeat(t)} ${e.title}

`;e.context&&e.context.trim()&&(o+=`*${e.context}*

`),e.content&&e.content.trim()&&(o+=`${e.content}

`);for(const n of e.children)o+=this.generateMarkdownHierarchy(n,t+1);return o}generatePlainTextContent(e){let t=`LOWEST LAYER CONTENT
${"=".repeat(20)}

`;for(const r of e)r.content&&r.content.trim()&&(t+=`${r.title.toUpperCase()}
`,t+=`${"-".repeat(r.title.length)}
`,t+=`Level: ${r.level}

`,t+=`${r.content}

`,t+=`${"~".repeat(50)}

`);return t}generatePlainTextHierarchy(e,t=0){const r="  ".repeat(t);let o=`${r}${e.title}
`;if(e.context&&e.context.trim()&&(o+=`${r}Context: ${e.context}
`),e.content&&e.content.trim()){const n=e.content.split(`
`);for(const i of n)o+=`${r}  ${i}
`}o+=`
`;for(const n of e.children)o+=this.generatePlainTextHierarchy(n,t+1);return o}getFileExtension(e){switch(e){case O.HTML:return"html";case O.Markdown:return"md";case O.Plain:return"txt";case O.Reimport:return"json";default:return"txt"}}getMimeType(e){switch(e){case O.HTML:return"text/html";case O.Markdown:return"text/markdown";case O.Plain:return"text/plain";case O.Reimport:return"application/json";default:return"text/plain"}}}class Dt extends Qe{constructor(t,r={}){super(t,r);p(this,"content");this.content=t.content}render(){const t=m("div",{classes:["generic-modal-container"]});if(this.config.title){const o=m("h2",{classes:["modal-title"],content:this.config.title,attributes:{style:`
                        margin: 0 0 1.5rem 0;
                        font-size: 1.5rem;
                        font-weight: 600;
                        color: #1f2937;
                    `}});t.appendChild(o)}const r=m("div",{classes:["modal-body"],innerHTML:this.content.content,attributes:{style:`
                    margin-bottom: 1.5rem;
                    line-height: 1.6;
                    color: #374151;
                `}});if(t.appendChild(r),this.content.actions&&this.content.actions.length>0){const o=this.createActionsContainer();t.appendChild(o)}return t}updateContent(t){if(this.content=t,this.isOpen()&&this.element){const r=this.element.querySelector(".modal-content");if(r){const o=this.render();r.innerHTML="",r.appendChild(o),this.config.closable&&this.addCloseButton(r)}}}createActionsContainer(){var r;const t=m("div",{classes:["modal-actions"],attributes:{style:`
                    display: flex;
                    gap: 0.75rem;
                    justify-content: flex-end;
                    margin-top: 1.5rem;
                    padding-top: 1rem;
                    border-top: 1px solid #e5e7eb;
                `}});return(r=this.content.actions)==null||r.forEach(o=>{const n=this.createActionButton(o);t.appendChild(n)}),t}createActionButton(t){const r=this.getButtonStyle(t.type||"secondary"),o=m("button",{classes:["modal-action-btn",`btn-${t.type||"secondary"}`],content:t.label,attributes:{"data-action-id":t.id,style:re.button+r}});return o.addEventListener("click",()=>h(this,null,function*(){try{yield t.handler(),yield this.handleAction(t.id)}catch(n){if((n==null?void 0:n.message)==="__KEEP_MODAL_OPEN__")return;console.error(`Error handling action ${t.id}:`,n)}})),o.addEventListener("mouseenter",()=>{o.style.opacity="0.9"}),o.addEventListener("mouseleave",()=>{o.style.opacity="1"}),o}getButtonStyle(t){switch(t){case"primary":return re.primaryButton;case"secondary":return re.secondaryButton;case"outline":return re.outlineButton;case"danger":return`
                    background-color: #dc2626;
                    color: white;
                `;default:return re.secondaryButton}}}function Rt(a,e={},t={}){const r=typeof a=="string"?{content:a}:a,o={id:e.id||`generic-modal-${Date.now()}`,title:e.title,width:e.width,height:e.height,maxWidth:e.maxWidth||"80vw",maxHeight:e.maxHeight||"90vh",closable:e.closable!==!1,backdrop:e.backdrop!==!1,content:r},n=new Dt(o,t);return n.open().catch(i=>{console.error("❌ Failed to open modal:",i)}),n}const at="expert_app_prompts",ce={content_generation_initial:`
        Your task is to respond to the following user prompt: "{{prompt}}"

        Your response will be rated by a just and unforegiving rater on the following criteria:
        - {{criteria}}

        Please generate a high-quality response that addresses these criteria.
    `.trim(),content_generation_iterative:`
        The user's original prompt was: "{{prompt}}".
        Your last response was: "{{lastResponse}}".
        It received feedback and the editor provided the following advice to improve it: "{{editorAdvice}}".

        Please generate a new response, incorporating the editor's advice. Remember, your response will be rated by a just and unforegiving rater on these criteria:
        - {{criteria}}
    `.trim(),rater:`
        You are a just and unforegiving rating agent. Your response MUST be a single, valid JSON array and nothing else. Do not include any text before or after the JSON.

        The user's original prompt was: "{{originalPrompt}}".
        
        Here is a response generated for that prompt:
        ---
        {{response}}
        ---
        
        Please rate this response objectively against all of the following criteria. Use your best judgment to assess the quality on a scale of 1-10.
        Do not aim to please, be just!
        
        Criteria to evaluate:
        - {{criteria}}
        
        Provide your response as a JSON array of objects. Each object must have three keys:
        - "criterion": The exact name of the criterion being rated (use the full original name).
        - "score": A number from 1 to 10 based on your objective assessment.
        - "justification": A brief explanation for your score, written in the tone of a critique.

        Example:
        [
            { "criterion": "Clarity & Conciseness", "score": 8, "justification": "The response is clear and well-structured." },
            { "criterion": "Engaging Flow", "score": 7, "justification": "The text is interesting but could have smoother transitions." }
        ]
    `.trim(),editor:`
        A response was generated: "{{response}}"
        It was rated against several criteria:
        {{ratings}}

        Please provide concise, actionable advice for the Creator LLM on how to improve the response to better meet the rating goals.
        Focus on what needs to change.
    `.trim(),summarize_system:`
        You are an expert at summarizing text for use as future context. Create a concise, factual summary of the following text, capturing the key points, main ideas, and any critical details.

        ---
        
        {{content}}
    `.trim(),expand_list_user:`
        You are working on the document path: "{{path}}".

        Here is the content of the document you are expanding:
        ---
        {{parent_content}}
        ---

        Here is the context of the document so far:
        ---
        {{context}}
        ---

        Based on this, generate a bullet point list of {{count}} titles for the '{{child_level_name}}' nodes that will follow. Each title must be on a new line and start with a single asterisk (*).
    `.trim(),content_generation_user:`
        You are writing the content for the node at the following path: "{{path}}".
        The title of this node is "{{title}}".

        Here is the context of the story so far:
        ---
        {{context}}
        ---

        {{draftorfresh}}

        IMPORTANT: Your response should contain ONLY the requested content text, nothing more. Do not include any introductory remarks, explanations, meta-commentary, or additional formatting. Just provide the pure content that belongs in this section.
    `.trim(),branch_content_generation_user:`
        You are an expert at outlining and structuring documents. You are working on a node at the path "{{path}}" with the title "{{title}}".
        This is a "branch" node, meaning it will be expanded into child nodes later. Your task is to generate the content for this branch node.

        This content should be a detailed prose outline or comprehensive summary that thoroughly describes what will logically follow. Include rich details about key points, characters, plot developments, themes, and specific elements that will help create meaningful child nodes. Be descriptive and specific rather than brief - this detailed content will be used to generate well-defined titles and content for the child nodes later. Do NOT use bullet points or markdown formatting.

        Here is the context of the document so far:
        ---
        {{context}}
        ---

        {{draftorfresh}}

        IMPORTANT: Your response should contain ONLY the requested outline content, nothing more. Do not include any introductory remarks, explanations, meta-commentary, or additional formatting. Just provide the pure outline text that belongs in this section.
    `.trim(),create_children_from_outline_user:`
        You are an expert at structuring documents. The following text is a free-form outline for a section of a document. Your task is to read this outline and generate exactly {{count}} entries for the '{{child_level_name}}' nodes that should be created from it.

        Generate exactly {{count}} entries - no more, no less. The entries expand the outline, the context is just there to help with this task.

        IMPORTANT: Your response must be a valid JSON array where each entry is an object with exactly two properties:
        - "title": the title of the subnode
        - "description": one sentence brief description of what should be covered in this subnode

        Example format:
        [
          {
            "title": "Introduction to the Topic",
            "description": "Provides an overview and sets the foundation for understanding the main concepts."
          },
          {
            "title": "Core Principles",
            "description": "Explains the fundamental principles and key concepts that underpin the topic."
          }
        ]

        Do not include any other text, explanations, or formatting. Only provide the JSON array.

        Here is the context of the document so far:
        ---
        {{context}}
        ---

        Here is the outline to process:
        {{outline_content}}
    `.trim(),prompt_for_child_generation_prompt:`You are an expert at creating generative prompts for a hierarchical document. The user is expanding a parent node. A new child node with the title "{{child_title}}" has just been created.

The parent node's content is:
---
{{parent_content}}
---

The broader context of the document is:
---
{{context}}
---

Based on all of this information, please write a detailed, one-paragraph prompt that can be used to generate the full text content for the new child node titled "{{child_title}}". The prompt should be self-contained and guide an AI to write content that logically follows the parent, fits within the document's context, and fulfills the promise of its title. Do not just repeat the title; create a rich instruction.`,context_synthesis_user:`You are an expert at distilling and synthesizing contextual information for content generation.

You have been given:
1. PARENT CONTEXT - inherited context from the parent node
2. NODE CONTENT - the actual content that was generated for this node

Your task is to create a new, synthesized context by:
- Distilling the parent context to only what remains relevant and important for child nodes of this level
- Incorporating new concepts, themes, characters, and elements that were introduced in the node content
- **PRESERVING STYLE INFORMATION**: Maintain details about writing style, tone, voice, narrative perspective, formatting preferences, and any stylistic patterns established in the content
- Creating a focused context that will guide generation of child nodes effectively while maintaining consistency

PARENT CONTEXT:
---
{{parent_context}}
---

NODE CONTENT:
---
{{node_content}}
---

Please generate a concise but comprehensive context summary that combines the essential elements from the parent context with the newly established concepts from this node's content. **Pay special attention to preserving style information** such as:
- Writing tone and voice
- Narrative perspective (first-person, third-person, etc.)
- Formatting patterns and structure
- Genre conventions and stylistic choices
- Any specific writing techniques or approaches used

Focus on what will be most useful for generating coherent child content that maintains stylistic consistency.`,context_extraction_user:`You are an expert at analyzing text and extracting specific information. Your task is to analyze the following content and extract information about: {{extraction_request}}

Please provide a clear, organized list or summary of the requested information. Be thorough but concise, and focus only on the specific type of information requested.

Content to analyze from "{{node_title}}":
---
{{content}}
---

Please extract and list all instances of: {{extraction_request}}

Format your response as a clear, organized summary that would be useful for reference.`,expand_text_user:`You are an expert at expanding and developing written content. Take the following text and create a more detailed, comprehensive version while maintaining the original meaning and tone.

Original text:
---
{{content}}
---

Please expand this text to make it more detailed and complete. Focus on adding depth, examples, and clarity while preserving the core message and writing style.`,node_chat_system:`You are an AI assistant helping a user work with their document structure. You have access to the following node data from their project:

{{node_data}}

The user can ask you questions about this content, request edits, analysis, or suggestions for improvement. You should:

1. Reference specific parts of the node hierarchy when relevant
2. Provide helpful suggestions for content development
3. Offer to help with editing, expansion, or restructuring
4. Answer questions about the content structure and relationships
5. Suggest improvements to writing quality, clarity, or organization

You have full context about the document structure and content. Be helpful, specific, and actionable in your responses.`};class kr{constructor(e,t={}){p(this,"settingsManager");p(this,"prompts");p(this,"config");p(this,"changeHandlers",[]);p(this,"saveHandlers",[]);this.settingsManager=e,this.config=T({autoSave:!0,showDescriptions:!0,showPlaceholders:!0},t),this.prompts=T({},this.settingsManager.getPrompts())}getPrompts(){return T({},this.prompts)}updatePrompt(e,t){const r=this.prompts[e];this.prompts[e]=t,this.changeHandlers.forEach(o=>{o({promptKey:e,oldValue:r,newValue:t})}),this.config.autoSave&&this.saveToStorage()}revertToDefaults(){return h(this,null,function*(){confirm("Are you sure you want to revert all prompts to their default values? Any unsaved changes will be lost.")&&(this.prompts=T({},ce),yield this.saveToStorage(),this.saveHandlers.forEach(t=>t()))})}saveToStorage(){return h(this,null,function*(){yield this.settingsManager.savePrompts(this.prompts),this.saveHandlers.forEach(e=>e())})}reloadFromStorage(){this.prompts=T({},this.settingsManager.getPrompts())}onPromptChange(e){this.changeHandlers.push(e)}onSave(e){this.saveHandlers.push(e)}renderEditor(e){e.innerHTML="",this.addStyles(e);const t=m("p",{content:"Configure the templates used by AI agents. Changes are saved automatically.",attributes:{style:"color: #6b7280; font-size: 0.875rem; margin-bottom: 1rem;"}});e.appendChild(t),Object.keys(this.prompts).forEach(o=>{const n=o,i=this.createPromptEditor(n);e.appendChild(i)});const r=this.createActionsContainer();e.appendChild(r)}createPromptEditor(e){const t=m("div",{classes:["prompt-editor"]}),r=m("label",{content:this.formatPromptName(e),attributes:{for:`prompt-${e}`}});if(t.appendChild(r),this.config.showDescriptions){const n=this.getPromptDescription(e);if(n){const i=m("p",{classes:["prompt-description"],content:n});t.appendChild(i)}}if(this.config.showPlaceholders){const n=this.getPromptPlaceholders(e);if(n.length>0){const i=m("div",{classes:["placeholders"],innerHTML:`Available placeholders: ${n.map(s=>`<code>{{${s}}}</code>`).join(", ")}`});t.appendChild(i)}}const o=m("textarea",{attributes:{id:`prompt-${e}`,value:this.prompts[e]}});return o.value=this.prompts[e],o.addEventListener("input",()=>{this.updatePrompt(e,o.value),le(o)}),setTimeout(()=>le(o),0),t.appendChild(o),t}createActionsContainer(){const e=m("div",{classes:["prompt-actions"]}),t=m("button",{classes:["btn-outline"],content:"Reset All Prompts to Defaults"});return t.addEventListener("click",()=>{this.revertToDefaults()}),e.appendChild(t),e}addStyles(e){const t=m("style",{innerHTML:`
                .prompt-editor { 
                    margin-bottom: 1.5rem; 
                }
                .prompt-editor label { 
                    font-weight: 500; 
                    display: block; 
                    margin-bottom: 0.5rem; 
                    color: #374151;
                }
                .prompt-editor textarea { 
                    width: 100%; 
                    min-height: 150px; 
                    font-family: 'Fira Code', 'Consolas', monospace;
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    resize: vertical;
                    line-height: 1.4;
                    background-color: #f9fafb;
                    transition: border-color 0.2s, background-color 0.2s;
                }
                .prompt-editor textarea:focus {
                    outline: none;
                    border-color: #3b82f6;
                    background-color: white;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                .placeholders { 
                    font-size: 0.8rem; 
                    font-style: italic; 
                    margin-bottom: 0.5rem; 
                    color: #6b7280; 
                }
                .placeholders code { 
                    background-color: #f3f4f6; 
                    padding: 2px 4px; 
                    border-radius: 3px; 
                    font-family: 'Fira Code', 'Consolas', monospace;
                    color: #1f2937;
                    border: 1px solid #e5e7eb;
                }
                .prompt-description { 
                    font-size: 0.875rem; 
                    margin-bottom: 0.75rem; 
                    color: #4b5563; 
                    line-height: 1.5;
                    font-style: italic;
                }
                .prompt-actions {
                    margin-top: 1.5rem;
                    padding-top: 1rem;
                    border-top: 1px solid #e5e7eb;
                    display: flex;
                    gap: 0.75rem;
                }
                .btn-outline {
                    padding: 0.5rem 1rem;
                    border: 1px solid #d1d5db;
                    background: transparent;
                    color: #6b7280;
                    border-radius: 6px;
                    font-size: 0.875rem;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .btn-outline:hover {
                    background-color: #f3f4f6;
                    color: #374151;
                    border-color: #9ca3af;
                }
            `});e.appendChild(t)}formatPromptName(e){return e.replace(/_/g," ").replace(/\b\w/g,t=>t.toUpperCase())}getPromptDescription(e){return{content_generation_initial:"Main system prompt for the iterative generation loop.",content_generation_iterative:"System prompt for subsequent iterations with feedback.",content_generation_user:"Template for generating content in leaf nodes.",branch_content_generation_user:"Template for generating content in branch nodes.",rater:"System prompt for the AI that scores generated content.",editor:"System prompt for the AI that provides improvement feedback.",summarize_system:"System prompt for summarizing generated content.",expand_list_user:"Prompt for generating bulleted lists of child titles.",create_children_from_outline_user:"Reads free-form text and generates structured child titles.",prompt_for_child_generation_prompt:"Creates generation prompts for new child nodes.",context_synthesis_user:"Combines parent context with node content to create focused context for child generation.",context_extraction_user:"Analyzes node content to extract specific information (characters, places, themes, etc.).",expand_text_user:"Simple prompt for expanding text with more detail.",node_chat_system:"System prompt for the chat interface when chatting about specific nodes."}[e]||null}getPromptPlaceholders(e){return{content_generation_initial:["prompt","criteria"],content_generation_iterative:["prompt","lastResponse","editorAdvice","criteria"],rater:["originalPrompt","response","criteria"],editor:["response","ratings"],summarize_system:["content"],expand_list_user:["path","context","child_level_name","count","parent_content","content"],content_generation_user:["path","context","title","content","draftorfresh"],branch_content_generation_user:["path","context","title","child_level_name","count","content","draftorfresh"],create_children_from_outline_user:["outline_content","child_level_name","context","content"],prompt_for_child_generation_prompt:["parent_content","context","child_title","content"],context_synthesis_user:["parent_context","node_content"],context_extraction_user:["extraction_request","node_title","content"],expand_text_user:["content","path","context","title"],node_chat_system:["node_data"]}[e]||[]}}class Ar{constructor(e,t){p(this,"settingsManager");p(this,"modelSelector");p(this,"changeHandlers",[]);p(this,"saveHandlers",[]);this.settingsManager=e,this.modelSelector=t}getProfileNames(){return this.settingsManager.getProfileNames()}getProfile(e){return this.settingsManager.getProfile(e)||null}getLastUsedProfileName(){return this.settingsManager.getLastUsedProfileName()}getLastUsedProfile(){return this.settingsManager.getLastUsedProfile()||null}createProfile(e){return h(this,null,function*(){if(!e.trim())return{success:!1,message:"Please enter a name for the new profile."};if(this.settingsManager.getProfile(e))return{success:!1,message:`A profile named "${e}" already exists.`};try{const t={selectedModels:this.modelSelector.getSelectedModels(),criteria:[],maxIterations:5,prompt:"",contextExtractionPrompt:""};return yield this.settingsManager.saveProfile(e,t),yield this.settingsManager.setLastUsedProfile(e),this.emitChange({type:"profile",data:{action:"created",profileName:e}}),{success:!0,message:`Profile "${e}" created and activated.`}}catch(t){return console.error("Failed to create profile:",t),{success:!1,message:"Failed to create profile. Please try again."}}})}saveCurrentSettingsToProfile(e,t,r){return h(this,null,function*(){const o={selectedModels:this.modelSelector.getSelectedModels(),criteria:t,maxIterations:r,prompt:"",contextExtractionPrompt:""};yield this.settingsManager.saveProfile(e,o),this.emitChange({type:"profile",data:{action:"saved",profileName:e}}),this.saveHandlers.forEach(n=>n())})}switchToProfile(e){return h(this,null,function*(){const t=this.settingsManager.getProfile(e);return t?(yield this.settingsManager.setLastUsedProfile(e),this.applyProfileToComponents(t),this.emitChange({type:"profile",data:{action:"switched",profileName:e,profile:t}}),t):null})}deleteProfile(e){return h(this,null,function*(){if(!e)return{success:!1,message:"No profile selected for deletion."};try{return this.settingsManager.deleteProfile(e),this.emitChange({type:"profile",data:{action:"deleted",profileName:e}}),{success:!0,message:`Profile "${e}" deleted.`}}catch(t){return console.error("Failed to delete profile:",t),{success:!1,message:"Failed to delete profile. Please try again."}}})}exportProfile(e){if(!e)return{success:!1,message:"Please select a profile to export."};try{return this.settingsManager.downloadProfileExport(e),{success:!0,message:`Profile "${e}" exported successfully.`}}catch(t){return console.error("Export failed:",t),{success:!1,message:"Failed to export profile. Please try again."}}}importProfileFromFile(e,t){return h(this,null,function*(){try{const r=yield this.settingsManager.importProfileFromFile(e,t);return r.success&&this.emitChange({type:"profile",data:{action:"imported",profileName:r.profileName}}),r}catch(r){return console.error("Import failed:",r),{success:!1,message:"Failed to import profile. Please check the file format and try again."}}})}isAILoggingEnabled(){return this.settingsManager.isAILoggingEnabled()}setAILoggingEnabled(e){return h(this,null,function*(){yield this.settingsManager.setAILoggingEnabled(e),this.emitChange({type:"aiLogging",data:{enabled:e}})})}applyProfileToComponents(e){e&&(e.selectedModels&&this.modelSelector.setSelectedModels(e.selectedModels),this.emitChange({type:"profile",data:{action:"applied",profile:e}}))}getCurrentSettings(e,t){return{selectedModels:this.modelSelector.getSelectedModels(),criteria:e,maxIterations:t,prompt:"",contextExtractionPrompt:""}}validateProfile(e){const t=[];return e?(Array.isArray(e.selectedModels)||t.push("Selected models must be an array"),Array.isArray(e.criteria)||t.push("Criteria must be an array"),(typeof e.maxIterations!="number"||e.maxIterations<1)&&t.push("Max iterations must be a positive number"),{valid:t.length===0,errors:t}):(t.push("Profile data is missing"),{valid:!1,errors:t})}duplicateProfile(e,t){return h(this,null,function*(){const r=this.getProfile(e);if(!r)return{success:!1,message:`Source profile "${e}" not found.`};if(this.getProfile(t))return{success:!1,message:`A profile named "${t}" already exists.`};try{return yield this.settingsManager.saveProfile(t,T({},r)),this.emitChange({type:"profile",data:{action:"duplicated",sourceProfileName:e,newProfileName:t}}),{success:!0,message:`Profile "${t}" created from "${e}".`}}catch(o){return console.error("Failed to duplicate profile:",o),{success:!1,message:"Failed to duplicate profile. Please try again."}}})}renameProfile(e,t){return h(this,null,function*(){const r=this.getProfile(e);if(!r)return{success:!1,message:`Profile "${e}" not found.`};if(this.getProfile(t))return{success:!1,message:`A profile named "${t}" already exists.`};try{return yield this.settingsManager.saveProfile(t,r),this.settingsManager.deleteProfile(e),this.getLastUsedProfileName()===e&&this.settingsManager.setLastUsedProfile(t),this.emitChange({type:"profile",data:{action:"renamed",oldName:e,newName:t}}),{success:!0,message:`Profile renamed from "${e}" to "${t}".`}}catch(o){return console.error("Failed to rename profile:",o),{success:!1,message:"Failed to rename profile. Please try again."}}})}onChange(e){this.changeHandlers.push(e)}onSave(e){this.saveHandlers.push(e)}offChange(e){const t=this.changeHandlers.indexOf(e);t>-1&&this.changeHandlers.splice(t,1)}offSave(e){const t=this.saveHandlers.indexOf(e);t>-1&&this.saveHandlers.splice(t,1)}emitChange(e){this.changeHandlers.forEach(t=>t(e))}getProfileStats(e){var r,o;const t=this.getProfile(e);return t?{criteriaCount:((r=t.criteria)==null?void 0:r.length)||0,modelsCount:((o=t.selectedModels)==null?void 0:o.length)||0}:null}ensureDefaultProfiles(){return h(this,null,function*(){this.getProfileNames().includes("default")||(yield this.createProfile("default"))})}}const lt="expert_app_settings_profiles",je="expert_app_last_used_profile",ct="expert_app_ai_logging_enabled",Ge=`You are an expert at analyzing text and extracting specific information. Your task is to analyze the following content and extract information about: {{extraction_request}}

Please provide a clear, organized list or summary of the requested information. Be thorough but concise, and focus only on the specific type of information requested.

Content to analyze from "{{node_title}}":
---
{{content}}
---

Please extract and list all instances of: {{extraction_request}}

Format your response as a clear, organized summary that would be useful for reference.`,_t=[{name:"Prompt Adherence",description:"The response directly addresses the given prompt and stays on topic throughout. It fulfills the specific request without wandering off into tangential areas.",goal:9,outline:!0,leaf:!0},{name:"Clarity & Conciseness",description:"The writing is direct, easy to understand, and avoids unnecessary words or filler phrases.",goal:7,outline:!0,leaf:!0},{name:"Natural & Authentic Tone",description:"The language sounds human and authentic. It avoids being overly formal, academic, or robotic.",goal:7,outline:!0,leaf:!0},{name:"Engaging Flow",description:"The text is interesting and holds the reader's attention. Sentences and paragraphs transition smoothly.",goal:8,outline:!1,leaf:!0},{name:"Varied Sentence Structure",description:"The length and structure of sentences are varied to create a pleasing rhythm, avoiding monotony.",goal:7,outline:!1,leaf:!0},{name:"Subtlety (Show, Don't Tell)",description:"The writing implies emotions and ideas through description and action rather than stating them directly. It avoids being on-the-nose.",goal:8,outline:!1,leaf:!0},{name:"Avoids AI Clichés",description:"The text avoids common AI phrases like 'In conclusion,' 'It's important to note,' 'delve into,' 'tapestry of,' 'testament to,' 'in the realm of,' 'navigate the landscape,' 'meticulous examination of,' 'crucial,' 'pivotal,' 'essential,' 'underscores,' 'harness,' 'illuminate,' 'transformative,' 'fostering,' 'utilize,' 'thus,' 'furthermore,' or 'ostensibly'",goal:8,outline:!0,leaf:!0},{name:"Understated Language",description:"The prose avoids overly dramatic, sensational, or grandiose language. The tone is measured and appropriate.",goal:8,outline:!0,leaf:!0},{name:"Specificity & Concrete Detail",description:"The writing uses specific, concrete details and examples rather than vague generalities.",goal:8,outline:!1,leaf:!0},{name:"Original Phrasing",description:"The text avoids common idioms and clichés, opting for more original ways to express ideas.",goal:7,outline:!0,leaf:!0},{name:"Stylistic Variation",description:"Natural shifts in rhythm, tone, and phrasing that reflect a human voice.",goal:8,outline:!1,leaf:!0},{name:"Emotional Subtlety",description:"Emotions are implied or layered rather than explicitly stated.",goal:8,outline:!1,leaf:!0},{name:"Lexical Character",description:"Word choices feel personal, distinctive, or slightly idiosyncratic without being distracting.",goal:8,outline:!1,leaf:!0},{name:"Human-like Naming",goal:8,description:"If a new character is introduced with a generic placeholder name (e.g., 'a character', 'the archivist'), replace it with a more human-sounding name. Avoid overused fantasy/AI-generated names like Elara, Lyra, Lyria, Chen, Kai, Raven, Yuki, Marcus, Zara, Voss, Aria, Moonshadow, Seraphina, Ashwood, Clive, Maximilian, Everett, Benedict, Oswald, Rupert, Magnus, Stormrider, Dawnwalker, Shadowblade, Emberheart, Snowsong, Park, Johnson, Thorne, Alaric, Nyx, Orion, Cassian, Mira, Selene, Vale, Kieran, Nova, Soren, Sylas, Astrid, Calix, Xander, Draven, Isolde, Aerin, Kael, Thalia, or Dorian. Instead, use more natural, varied names that feel authentic and less predictable. Do not change names that are already established.",outline:!0,leaf:!1},{name:"Avoids Dramatical Reframing",description:`The text avoids artificially elevating the significance of ordinary actions, objects, or perceptions through dramatic recontextualization. This includes explicit patterns like "It wasn't X. It was Y." as well as subtler forms of rhetorical inflation — where minor events are presented as symbolically profound, emotionally transformative, or mythically significant without narrative justification.

Examples to avoid:
• "It wasn't just food. It was fuel."
• "He wasn't waiting. He was strategizing."
• "Fixing the cart wasn't a simple repair; it was the beginning of an unlikely alliance."

Strong writing presents events and choices with clarity and restraint, allowing significance to emerge organically rather than through overt authorial framing.`,goal:8,outline:!0,leaf:!0}];function Nr(a){return typeof a!="object"||a===null?!1:Object.values(a).every(e=>typeof e=="object"&&e!==null&&"prompt"in e&&typeof e.prompt=="string"&&"criteria"in e&&Array.isArray(e.criteria)&&e.criteria.every(t=>typeof t=="object"&&t!==null&&"name"in t&&"goal"in t&&typeof t.name=="string"&&typeof t.goal=="number"&&(t.outline===void 0||typeof t.outline=="boolean")&&(t.leaf===void 0||typeof t.leaf=="boolean")&&(t.description===void 0||typeof t.description=="string"))&&"maxIterations"in e&&typeof e.maxIterations=="number"&&"selectedModels"in e&&typeof e.selectedModels=="object"&&e.selectedModels!==null&&(e.contextExtractionPrompt===void 0||typeof e.contextExtractionPrompt=="string"))}class de{constructor(){p(this,"profiles",{});p(this,"lastUsedProfileName",null);p(this,"prompts");p(this,"storageService");p(this,"initializationPromise");p(this,"aiLoggingEnabled",!1);this.storageService=$.getInstance(),this.prompts=T({},ce),this.initializationPromise=this.initializeAsync()}waitForInitialization(){return h(this,null,function*(){return this.initializationPromise})}initializeAsync(){return h(this,null,function*(){yield this.loadProfiles(),yield this.loadLastUsedProfile(),yield this.loadPrompts(),yield this.loadAILoggingSetting()})}loadProfiles(){return h(this,null,function*(){try{const t=yield(yield this.storageService).get(lt);t&&Nr(t)?(this.profiles=t,Object.keys(this.profiles).forEach(r=>{this.profiles[r].contextExtractionPrompt||(this.profiles[r].contextExtractionPrompt=Ge)}),yield this.saveProfiles()):(console.warn("Invalid settings profiles found in storage. Ignoring."),this.profiles={})}catch(e){console.error("Failed to load settings profiles from storage",e),this.profiles={}}if(Object.keys(this.profiles).length===0){const e={prompt:"",criteria:_t,maxIterations:5,selectedModels:{},contextExtractionPrompt:Ge};this.profiles={default:e},yield this.setLastUsedProfile("default"),yield this.saveProfiles()}})}loadPrompts(){return h(this,null,function*(){try{const t=yield(yield this.storageService).get(at);t?this.prompts=T(T({},ce),t):this.prompts=T({},ce)}catch(e){console.error("Failed to load prompts from storage",e),this.prompts=T({},ce)}})}loadLastUsedProfile(){return h(this,null,function*(){try{const t=yield(yield this.storageService).get(je);this.lastUsedProfileName=t||null}catch(e){console.error("Failed to load last used profile from storage",e),this.lastUsedProfileName=null}})}loadAILoggingSetting(){return h(this,null,function*(){try{const e=yield this.storageService;this.aiLoggingEnabled=(yield e.get(ct))||!1}catch(e){console.error("Failed to load AI logging setting from storage",e),this.aiLoggingEnabled=!1}})}getPrompts(){return this.prompts}savePrompts(e){return h(this,null,function*(){this.prompts=e;try{yield(yield this.storageService).set(at,this.prompts)}catch(t){console.error("Failed to save prompts to storage",t)}})}getProfileNames(){return Object.keys(this.profiles)}getProfile(e){return this.profiles[e]}saveProfile(e,t){return h(this,null,function*(){if(!e)throw new Error("Profile name cannot be empty.");this.profiles[e]=t,yield this.saveProfiles()})}deleteProfile(e){return h(this,null,function*(){if(e==="default"){alert("Cannot delete the default profile.");return}if(delete this.profiles[e],this.lastUsedProfileName===e){this.lastUsedProfileName=null;try{yield(yield this.storageService).delete(je)}catch(t){console.error("Failed to remove last used profile from storage",t)}}yield this.saveProfiles()})}getLastUsedProfile(){if(this.lastUsedProfileName)return this.getProfile(this.lastUsedProfileName);const e=this.getProfileNames();return e.length>0?this.getProfile(e[0]):void 0}getLastUsedProfileName(){if(this.lastUsedProfileName&&this.profiles[this.lastUsedProfileName])return this.lastUsedProfileName;const e=this.getProfileNames();return e.length>0?e[0]:null}setLastUsedProfile(e){return h(this,null,function*(){this.lastUsedProfileName=e;try{yield(yield this.storageService).set(je,e)}catch(t){console.error("❌ Failed to save last used profile to storage",t)}})}saveProfiles(){return h(this,null,function*(){try{yield(yield this.storageService).set(lt,this.profiles)}catch(e){console.error("Failed to save settings profiles to storage",e)}})}exportProfile(e){const t=this.getProfile(e);return t?{exportVersion:"1.0",exportDate:new Date().toISOString(),profileName:e,profile:{prompt:t.prompt,criteria:t.criteria,maxIterations:t.maxIterations,selectedModels:t.selectedModels,contextExtractionPrompt:t.contextExtractionPrompt},prompts:this.prompts}:null}importProfile(e,t=!1){return h(this,null,function*(){try{if(!e||typeof e!="object")return{success:!1,message:"Invalid export data format"};if(!e.profileName||!e.profile||!e.prompts)return{success:!1,message:"Export data is missing required fields (profileName, profile, or prompts)"};const r=e.profileName,o=e.profile;if(!this.isValidProfileStructure(o))return{success:!1,message:"Invalid profile structure in export data"};if(this.profiles[r]&&!t)return{success:!1,message:`Profile "${r}" already exists. Do you want to overwrite it?`,profileName:r};let n=o.selectedModels;this.profiles[r]&&t&&(n=this.profiles[r].selectedModels);const i={prompt:o.prompt,criteria:o.criteria,maxIterations:o.maxIterations,selectedModels:n,contextExtractionPrompt:o.contextExtractionPrompt||Ge};if(yield this.saveProfile(r,i),e.prompts&&typeof e.prompts=="object"){const s=T(T({},this.prompts),e.prompts);yield this.savePrompts(s)}return{success:!0,message:`Profile "${r}" imported successfully`,profileName:r}}catch(r){return console.error("Error importing profile:",r),{success:!1,message:`Import failed: ${r instanceof Error?r.message:"Unknown error"}`}}})}isValidProfileStructure(e){return typeof e=="object"&&e!==null&&"prompt"in e&&typeof e.prompt=="string"&&"criteria"in e&&Array.isArray(e.criteria)&&e.criteria.every(t=>typeof t=="object"&&t!==null&&"name"in t&&"goal"in t&&typeof t.name=="string"&&typeof t.goal=="number"&&(t.outline===void 0||typeof t.outline=="boolean")&&(t.leaf===void 0||typeof t.leaf=="boolean")&&(t.description===void 0||typeof t.description=="string"))&&"maxIterations"in e&&typeof e.maxIterations=="number"&&"selectedModels"in e&&typeof e.selectedModels=="object"&&e.selectedModels!==null&&(e.contextExtractionPrompt===void 0||typeof e.contextExtractionPrompt=="string")}downloadProfileExport(e){const t=this.exportProfile(e);if(!t){alert(`Profile "${e}" not found.`);return}const r=JSON.stringify(t,null,2),o=new Blob([r],{type:"application/json"}),n=URL.createObjectURL(o),i=document.createElement("a");i.href=n,i.download=`expert-app-profile-${e}-${new Date().toISOString().split("T")[0]}.json`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(n)}importProfileFromFile(e,t){return h(this,null,function*(){try{const r=yield e.text(),o=JSON.parse(r),n=yield this.importProfile(o,!1);return!n.success&&n.profileName&&n.message.includes("already exists")&&t?(yield t(n.profileName))?yield this.importProfile(o,!0):{success:!1,message:"Import cancelled by user"}:n}catch(r){return{success:!1,message:`Failed to parse import file: ${r instanceof Error?r.message:"Invalid JSON format"}`}}})}isAILoggingEnabled(){return this.aiLoggingEnabled}setAILoggingEnabled(e){return h(this,null,function*(){this.aiLoggingEnabled=e;try{yield(yield this.storageService).set(ct,e)}catch(t){console.error("Failed to save AI logging setting to storage",t)}})}}class Ir{constructor(e){p(this,"container");p(this,"criteria",[]);p(this,"changeHandlers",[]);this.container=e,this.initializeStyles(),this.render()}getCriteria(){return this.extractCriteriaFromUI()}setCriteria(e){this.criteria=this.migrateCriteriaFormat(e),this.render(),this.emitChange()}addCriterion(e){const t=T({name:"New Criterion...",goal:8,description:"",outline:!0,leaf:!0},e),r=this.container.querySelector(".criteria-list"),o=this.createCriterionElement(t);r.appendChild(o);const n=o.querySelector("textarea");if(n){n.style.display="block",n.focus(),le(n);const i=o.querySelector(".criterion-text-display");i&&(i.style.display="none")}this.emitChange()}removeCriterion(e){const r=this.container.querySelector(".criteria-list").querySelectorAll(".criterion");e>=0&&e<r.length&&(r[e].remove(),this.emitChange())}resetToDefaults(){confirm("This will replace your current criteria list with the application defaults. Are you sure?")&&this.setCriteria([..._t])}copyCriteria(){return h(this,null,function*(){const e=this.extractCriteriaFromUI();if(e.length>0)try{yield navigator.clipboard.writeText(JSON.stringify(e,null,2)),alert("Criteria copied to clipboard!")}catch(t){console.error("Failed to copy criteria: ",t),alert("Failed to copy criteria. See console for details.")}else alert("No criteria to copy.")})}pasteCriteria(){return h(this,null,function*(){try{const e=yield navigator.clipboard.readText(),t=JSON.parse(e);this.isCriteriaArray(t)?confirm("Are you sure you want to replace your current criteria with the content from your clipboard?")&&this.setCriteria(t):alert("Clipboard content is not valid criteria data.")}catch(e){console.error("Failed to paste criteria: ",e),alert("Failed to read from clipboard or parse data. See console for details.")}})}onChange(e){this.changeHandlers.push(e)}offChange(e){const t=this.changeHandlers.indexOf(e);t>-1&&this.changeHandlers.splice(t,1)}validateCriteria(e){const t=[];return Array.isArray(e)?(e.forEach((r,o)=>{(!r.name||r.name.trim()==="")&&t.push(`Criterion ${o+1}: Name is required`),(typeof r.goal!="number"||r.goal<1||r.goal>10)&&t.push(`Criterion ${o+1}: Goal must be between 1 and 10`),r.outline===!1&&r.leaf===!1&&t.push(`Criterion ${o+1}: Must be enabled for at least outline or leaf nodes`)}),{valid:t.length===0,errors:t}):(t.push("Criteria must be an array"),{valid:!1,errors:t})}render(){this.container.innerHTML="";const e=m("div",{classes:["criteria-actions"]}),t=m("button",{classes:["btn-primary"],content:"Add Criterion"});t.addEventListener("click",()=>this.addCriterion());const r=m("button",{classes:["btn-secondary"],content:"Reset to Defaults"});r.addEventListener("click",()=>this.resetToDefaults());const o=m("button",{classes:["btn-secondary"],content:"Copy All"});o.addEventListener("click",()=>this.copyCriteria());const n=m("button",{classes:["btn-secondary"],content:"Paste"});n.addEventListener("click",()=>this.pasteCriteria()),e.appendChild(t),e.appendChild(r),e.appendChild(o),e.appendChild(n);const i=m("div",{classes:["criteria-list"]});i.addEventListener("click",s=>{var l;s.target.classList.contains("remove-criterion-btn")&&((l=s.target.closest(".criterion"))==null||l.remove(),this.emitChange())}),i.addEventListener("input",()=>{this.emitChange()}),i.addEventListener("change",()=>{this.emitChange()}),this.container.appendChild(e),this.container.appendChild(i),this.criteria.forEach(s=>{const l=this.createCriterionElement(s);i.appendChild(l);const c=l.querySelector("textarea");c&&le(c)})}createCriterionElement(e){const t=m("div",{classes:["criterion"]}),r=e.description?`${e.name}. ${e.description}`:e.name,o=m("textarea",{attributes:{placeholder:"e.g., 'Clarity and conciseness'",value:r}});o.addEventListener("input",g=>{le(g.target)}),o.addEventListener("focus",function(){this.selectionStart=this.selectionEnd=this.value.length});const n=m("input",{attributes:{type:"number",min:"1",max:"10",value:e.goal.toString(),title:"Goal (1-10)"}}),i=m("input",{classes:["outline-checkbox"],attributes:{type:"checkbox",title:"Use for outline/branch nodes"}});i.checked=e.outline!==!1;const s=m("input",{classes:["leaf-checkbox"],attributes:{type:"checkbox",title:"Use for leaf nodes"}});s.checked=e.leaf!==!1;const l=m("button",{classes:["remove-criterion-btn"],innerHTML:"&times;",attributes:{title:"Remove criterion"}}),c=m("div",{classes:["criterion-text-display"]}),d=m("div",{attributes:{style:"flex-grow: 1; position: relative;"}});t.setAttribute("data-full-text",r);const u=g=>{c.textContent=g.split(".")[0]+(g.includes(".")&&g.split(".")[0]!==g?".":"")};return u(r),o.value=r,o.style.display="none",c.addEventListener("click",()=>{const g=t.getAttribute("data-full-text")||r;o.value=g,c.style.display="none",o.style.display="block",o.focus(),le(o)}),o.addEventListener("blur",()=>{t.setAttribute("data-full-text",o.value),o.style.display="none",c.style.display="block",u(o.value)}),d.appendChild(c),d.appendChild(o),t.appendChild(d),t.appendChild(n),t.appendChild(i),t.appendChild(s),t.appendChild(l),t}extractCriteriaFromUI(){const e=[];return this.container.querySelectorAll(".criterion").forEach(r=>{const o=r,n=r.querySelector("textarea"),i=r.querySelector('input[type="number"]'),s=r.querySelector(".outline-checkbox"),l=r.querySelector(".leaf-checkbox");if(n&&i&&s&&l){const c=o.getAttribute("data-full-text")||n.value,d=parseInt(i.value,10),u=s.checked,g=l.checked;if(c&&!isNaN(d)){const f=c.indexOf(".");let w,y;f!==-1&&f<c.length-1?(w=c.substring(0,f),y=c.substring(f+1).trim()):(w=c,y=void 0);const S={name:w,goal:d,outline:u,leaf:g};y&&(S.description=y),e.push(S)}}}),e}isCriteriaArray(e){return Array.isArray(e)&&e.every(t=>typeof t=="object"&&t!==null&&"name"in t&&"goal"in t&&typeof t.name=="string"&&typeof t.goal=="number"&&(t.outline===void 0||typeof t.outline=="boolean")&&(t.leaf===void 0||typeof t.leaf=="boolean")&&(t.description===void 0||typeof t.description=="string"))}migrateCriteriaFormat(e){return e.map(t=>{const r={name:t.name,goal:t.goal,outline:t.outline!==void 0?t.outline:!0,leaf:t.leaf!==void 0?t.leaf:!0};return t.description&&(r.description=t.description),r})}emitChange(){const e=this.extractCriteriaFromUI();this.changeHandlers.forEach(t=>{t({criteria:e})})}initializeStyles(){const e=m("style",{innerHTML:`
                .criteria-actions {
                    margin-bottom: 1rem;
                    display: flex;
                    gap: 0.5rem;
                    flex-wrap: wrap;
                }
                
                .criteria-actions .btn-primary,
                .criteria-actions .btn-secondary {
                    padding: 0.5rem 1rem;
                    border: none;
                    border-radius: 6px;
                    font-size: 0.875rem;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .criteria-actions .btn-primary {
                    background-color: #3b82f6;
                    color: white;
                }
                
                .criteria-actions .btn-primary:hover {
                    background-color: #2563eb;
                }
                
                .criteria-actions .btn-secondary {
                    background-color: #6b7280;
                    color: white;
                }
                
                .criteria-actions .btn-secondary:hover {
                    background-color: #4b5563;
                }
                
                .criteria-list {
                    display: flex;
                    flex-direction: column;
                    gap: 0.75rem;
                }
                
                .criterion {
                    display: flex;
                    align-items: flex-start;
                    gap: 0.75rem;
                    padding: 1rem;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    background-color: #f9fafb;
                    transition: border-color 0.2s;
                }
                
                .criterion:hover {
                    border-color: #d1d5db;
                }
                
                .criterion-text-display {
                    min-height: 1.5rem;
                    padding: 0.5rem;
                    cursor: pointer;
                    border-radius: 4px;
                    transition: background-color 0.2s;
                    font-size: 0.9rem;
                    color: #374151;
                }
                
                .criterion-text-display:hover {
                    background-color: #e5e7eb;
                }
                
                .criterion textarea {
                    min-height: 2.5rem;
                    font-family: inherit;
                    padding: 0.5rem;
                    border: 1px solid #d1d5db;
                    border-radius: 4px;
                    resize: vertical;
                    font-size: 0.9rem;
                    line-height: 1.4;
                }
                
                .criterion textarea:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                
                .criterion input[type="number"] {
                    width: 60px;
                    padding: 0.5rem;
                    border: 1px solid #d1d5db;
                    border-radius: 4px;
                    text-align: center;
                    font-size: 0.9rem;
                }
                
                .criterion input[type="number"]:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                
                .criterion input[type="checkbox"] {
                    margin: 0;
                    transform: scale(1.2);
                    cursor: pointer;
                }
                
                .remove-criterion-btn {
                    background: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 50%;
                    width: 28px;
                    height: 28px;
                    cursor: pointer;
                    font-size: 1.2rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: background-color 0.2s;
                    flex-shrink: 0;
                }
                
                .remove-criterion-btn:hover {
                    background-color: #dc2626;
                }
            `});document.querySelector("#criteria-editor-styles")||(e.id="criteria-editor-styles",document.head.appendChild(e))}}class Lr{constructor(e,t){p(this,"container");p(this,"settingsService");p(this,"selectionHandlers",[]);p(this,"actionHandlers",[]);p(this,"refreshCallback");p(this,"profileSelect");p(this,"newProfileInput");p(this,"currentProfileDisplay");this.container=e,this.settingsService=t,this.settingsService.onChange(this.handleSettingsChange.bind(this)),this.render(),this.populate()}getSelectedProfileName(){return this.profileSelect.value}setSelectedProfile(e){this.profileSelect.value=e,this.updateCurrentProfileDisplay(e)}refresh(){this.populate(),this.refreshCallback&&this.refreshCallback()}onRefresh(e){this.refreshCallback=e}onSelectionChange(e){this.selectionHandlers.push(e)}onAction(e){this.actionHandlers.push(e)}offSelectionChange(e){const t=this.selectionHandlers.indexOf(e);t>-1&&this.selectionHandlers.splice(t,1)}offAction(e){const t=this.actionHandlers.indexOf(e);t>-1&&this.actionHandlers.splice(t,1)}showProfileStats(e){const t=this.settingsService.getProfileStats(e);if(t){const r=`Profile: ${e}

Criteria: ${t.criteriaCount}
Models: ${t.modelsCount}`;alert(r)}else alert(`Profile "${e}" not found.`)}resetAllToDefaults(){var r,o;const e=Array.from(document.querySelectorAll(".criteria-actions button"));for(const n of e)if((r=n.textContent)!=null&&r.includes("Reset to Defaults")){n.click();break}const t=Array.from(document.querySelectorAll(".prompt-actions button"));for(const n of t)if((o=n.textContent)!=null&&o.includes("Reset All Prompts to Defaults")){n.click();break}}validateProfileName(e){return e.trim()?this.settingsService.getProfile(e)?{valid:!1,error:`Profile "${e}" already exists`}:/[<>:"/\\|?*]/.test(e)?{valid:!1,error:"Profile name contains invalid characters"}:e.length>50?{valid:!1,error:"Profile name is too long (max 50 characters)"}:{valid:!0}:{valid:!1,error:"Profile name cannot be empty"}}render(){this.container.innerHTML="",this.addStyles();const e=m("div",{classes:["profile-selection"]}),t=m("label",{content:"Active Profile:",attributes:{for:"profile-select"}});this.profileSelect=m("select",{attributes:{id:"profile-select"}}),this.profileSelect.addEventListener("change",()=>h(this,null,function*(){const b=this.profileSelect.value,P=yield this.settingsService.switchToProfile(b);this.updateCurrentProfileDisplay(b),this.emitSelection(b,P)})),this.currentProfileDisplay=m("span",{classes:["current-profile"],content:""}),e.appendChild(t),e.appendChild(this.profileSelect),e.appendChild(this.currentProfileDisplay);const r=m("div",{classes:["profile-creation"]}),o=m("label",{content:"Create New Profile:",attributes:{for:"new-profile-input"}});this.newProfileInput=m("input",{attributes:{id:"new-profile-input",type:"text",placeholder:"Enter profile name..."}}),this.newProfileInput.addEventListener("keydown",b=>{b.key==="Enter"&&(b.preventDefault(),this.createProfile())});const n=m("button",{classes:["btn-primary"],content:"Create Profile"});n.addEventListener("click",()=>this.createProfile()),r.appendChild(o);const i=m("div",{classes:["input-group"]});i.appendChild(this.newProfileInput),i.appendChild(n),r.appendChild(i);const s=m("div",{classes:["profile-actions"]}),l=m("label",{content:"Profile Actions:"}),c=m("div",{classes:["action-buttons"]}),d=m("button",{classes:["btn-danger"],content:"Delete"});d.addEventListener("click",()=>this.deleteProfile());const u=m("button",{classes:["btn-secondary"],content:"Export"});u.addEventListener("click",()=>this.exportProfile());const g=m("button",{classes:["btn-secondary"],content:"Import"});g.addEventListener("click",()=>this.importProfile());const f=m("button",{classes:["btn-secondary"],content:"Duplicate"});f.addEventListener("click",()=>this.duplicateProfile());const w=m("button",{classes:["btn-secondary"],content:"Rename"});w.addEventListener("click",()=>this.renameProfile());const y=m("button",{classes:["btn-secondary"],content:"Reset to Defaults"});y.addEventListener("click",()=>this.resetAllToDefaults()),c.appendChild(d),c.appendChild(u),c.appendChild(g),c.appendChild(f),c.appendChild(w),c.appendChild(y),s.appendChild(l),s.appendChild(c);const S=m("input",{attributes:{type:"file",accept:".json",style:"display: none;"}});S.addEventListener("change",b=>this.handleFileImport(b)),this.container.appendChild(e),this.container.appendChild(r),this.container.appendChild(s),this.container.appendChild(S)}populate(){const e=this.settingsService.getProfileNames(),t=this.settingsService.getLastUsedProfileName();this.profileSelect.innerHTML=e.map(r=>`<option value="${r}" ${r===t?"selected":""}>${r}</option>`).join(""),this.updateCurrentProfileDisplay(t||"")}updateCurrentProfileDisplay(e){this.currentProfileDisplay&&e&&(this.currentProfileDisplay.textContent=`(${e})`)}createProfile(){return h(this,null,function*(){const e=this.newProfileInput.value.trim(),t=this.validateProfileName(e);if(!t.valid){alert(t.error),this.newProfileInput.focus();return}try{const r=yield this.settingsService.createProfile(e);r.success&&(this.newProfileInput.value="",this.refresh(),this.setSelectedProfile(e),this.emitAction({action:"created",profileName:e,data:r})),alert(r.message)}catch(r){console.error("Failed to create profile:",r),alert("Failed to create profile. Please try again.")}})}deleteProfile(){return h(this,null,function*(){const e=this.getSelectedProfileName();if(!(!e||!confirm(`Are you sure you want to delete the profile "${e}"?`)))try{const r=yield this.settingsService.deleteProfile(e);if(r.success){this.refresh();const o=this.settingsService.getProfile("default");o&&(this.setSelectedProfile("default"),this.emitSelection("default",o)),this.emitAction({action:"deleted",profileName:e,data:r}),alert(r.message)}else alert(r.message)}catch(r){console.error("Failed to delete profile:",r),alert("Failed to delete profile. Please try again.")}})}exportProfile(){const e=this.getSelectedProfileName();if(!e){alert("Please select a profile to export.");return}try{const t=this.settingsService.exportProfile(e);this.emitAction({action:"exported",profileName:e,data:t}),t.success||alert(t.message)}catch(t){console.error("Export failed:",t),alert("Failed to export profile. Please try again.")}}importProfile(){this.container.querySelector('input[type="file"]').click()}handleFileImport(e){return h(this,null,function*(){var o;const t=e.target,r=(o=t.files)==null?void 0:o[0];if(r){try{const n=yield this.settingsService.importProfileFromFile(r,i=>h(this,null,function*(){return confirm(`Profile "${i}" already exists. Do you want to overwrite it?

Note: Your existing OpenRouter API key will be preserved.`)}));if(n.success){if(this.refresh(),n.profileName){this.setSelectedProfile(n.profileName);const i=this.settingsService.getProfile(n.profileName);this.emitSelection(n.profileName,i)}this.emitAction({action:"imported",profileName:n.profileName||"",data:n}),alert(n.message)}else alert(`Import failed: ${n.message}`)}catch(n){console.error("Import failed:",n),alert("Failed to import profile. Please check the file format and try again.")}t.value=""}})}duplicateProfile(){return h(this,null,function*(){const e=this.getSelectedProfileName();if(!e)return;const t=prompt(`Enter a name for the duplicate of "${e}":`);if(!t)return;const r=this.validateProfileName(t);if(!r.valid){alert(r.error);return}try{const o=yield this.settingsService.duplicateProfile(e,t);o.success&&(this.refresh(),this.setSelectedProfile(t),this.emitAction({action:"duplicated",profileName:t,data:{sourceProfileName:e,newProfileName:t}})),alert(o.message)}catch(o){console.error("Failed to duplicate profile:",o),alert("Failed to duplicate profile. Please try again.")}})}renameProfile(){return h(this,null,function*(){const e=this.getSelectedProfileName();if(!e)return;const t=prompt(`Enter a new name for "${e}":`);if(!t)return;const r=this.validateProfileName(t);if(!r.valid){alert(r.error);return}try{const o=yield this.settingsService.renameProfile(e,t);o.success&&(this.refresh(),this.setSelectedProfile(t),this.emitAction({action:"renamed",profileName:t,data:{oldName:e,newName:t}})),alert(o.message)}catch(o){console.error("Failed to rename profile:",o),alert("Failed to rename profile. Please try again.")}})}handleSettingsChange(e){e.type==="profile"&&e.data.action==="switched"&&this.updateCurrentProfileDisplay(e.data.profileName)}emitSelection(e,t){this.selectionHandlers.forEach(r=>{r({profileName:e,profile:t})})}emitAction(e){this.actionHandlers.forEach(t=>{t(e)})}addStyles(){const e=m("style",{innerHTML:`
                .profile-selection,
                .profile-creation,
                .profile-actions {
                    margin-bottom: 1.5rem;
                    padding: 1rem;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    background-color: #f9fafb;
                }
                
                .profile-selection label,
                .profile-creation label,
                .profile-actions label {
                    display: block;
                    font-weight: 500;
                    margin-bottom: 0.5rem;
                    color: #374151;
                }
                
                .profile-selection select {
                    width: 100%;
                    max-width: 300px;
                    padding: 0.5rem;
                    border: 1px solid #d1d5db;
                    border-radius: 6px;
                    background-color: white;
                    font-size: 0.9rem;
                }
                
                .current-profile {
                    margin-left: 0.5rem;
                    font-style: italic;
                    color: #6b7280;
                }
                
                .input-group {
                    display: flex;
                    gap: 0.5rem;
                    align-items: center;
                }
                
                .input-group input {
                    flex: 1;
                    padding: 0.5rem;
                    border: 1px solid #d1d5db;
                    border-radius: 6px;
                    font-size: 0.9rem;
                }
                
                .input-group input:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                
                .action-buttons {
                    display: flex;
                    gap: 0.5rem;
                    flex-wrap: wrap;
                }
                
                .btn-primary,
                .btn-secondary,
                .btn-danger,
                .btn-info {
                    padding: 0.5rem 1rem;
                    border: none;
                    border-radius: 6px;
                    font-size: 0.875rem;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .btn-primary {
                    background-color: #3b82f6;
                    color: white;
                }
                
                .btn-primary:hover {
                    background-color: #2563eb;
                }
                
                .btn-secondary {
                    background-color: #6b7280;
                    color: white;
                }
                
                .btn-secondary:hover {
                    background-color: #4b5563;
                }
                
                .btn-danger {
                    background-color: #ef4444;
                    color: white;
                }
                
                .btn-danger:hover {
                    background-color: #dc2626;
                }
                
                .btn-info {
                    background-color: #06b6d4;
                    color: white;
                }
                
                .btn-info:hover {
                    background-color: #0891b2;
                }
            `});document.querySelector("#profile-selector-styles")||(e.id="profile-selector-styles",document.head.appendChild(e))}}class Mr extends Qe{constructor(t){super(ee(T({},t),{title:"Settings",id:"settings-modal",closable:!1}));p(this,"settingsManager");p(this,"modelSelector");p(this,"refreshGlobalProfileSelector");p(this,"promptService");p(this,"settingsService");p(this,"criteriaEditor");p(this,"profileSelector");p(this,"hasUnsavedChanges",!1);p(this,"saveTimeout",null);p(this,"maxIterationsInput");p(this,"unsavedIndicator");p(this,"currentProfileDisplay");p(this,"aiLoggingCheckbox");this.settingsManager=t.settingsManager,this.modelSelector=t.modelSelector,this.refreshGlobalProfileSelector=t.refreshGlobalProfileSelector,this.promptService=new kr(this.settingsManager,{autoSave:!1,showDescriptions:!0,showPlaceholders:!0}),this.settingsService=new Ar(this.settingsManager,this.modelSelector),this.setupServiceEventHandlers()}emit(t,r){}render(){return this.renderContent()}renderContent(){const t=m("div",{classes:["settings-modal-container"]});this.addStyles(t);const r=this.createHeader(),o=this.createBody(),n=this.createFooter();return t.appendChild(r),t.appendChild(o),t.appendChild(n),setTimeout(()=>this.initializeComponents(),0),t}createHeader(){const t=m("div",{classes:["modal-header"]}),r=m("h2",{content:"Settings"}),o=m("button",{classes:["close-button"],innerHTML:"&times;"});return o.addEventListener("click",()=>{this.handleClose()}),t.appendChild(r),t.appendChild(o),t}createBody(){const t=m("div",{classes:["modal-body"]}),r=this.createProfileSection();t.appendChild(r);const o=this.createModelsSection();t.appendChild(o);const n=this.createCriteriaSection();t.appendChild(n);const i=this.createIterationsSection();t.appendChild(i);const s=this.createPromptsSection();t.appendChild(s);const l=this.createLoggingSection();return t.appendChild(l),t}createProfileSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"Profile Management"});this.currentProfileDisplay=m("div",{classes:["current-profile-info"]});const o=m("div",{classes:["profile-container"]});return t.appendChild(r),t.appendChild(this.currentProfileDisplay),t.appendChild(o),t}createModelsSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"AI Models"}),o=m("div",{attributes:{id:"settings-models-container"}});return t.appendChild(r),t.appendChild(o),t}createCriteriaSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"Quality Criteria"}),o=m("div",{classes:["criteria-container"]});return t.appendChild(r),t.appendChild(o),t}createIterationsSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"Generation Settings"}),o=m("label",{content:"Max Iterations:",attributes:{for:"modal-max-iterations"}});return this.maxIterationsInput=m("input",{attributes:{type:"number",id:"modal-max-iterations",min:"1",max:"10",value:"5"}}),this.maxIterationsInput.addEventListener("input",()=>{this.autoSave()}),t.appendChild(r),t.appendChild(o),t.appendChild(this.maxIterationsInput),t}createPromptsSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"AI Prompts"}),o=m("div",{attributes:{id:"settings-prompts-container"}});return t.appendChild(r),t.appendChild(o),t}createLoggingSection(){const t=m("div",{classes:["settings-section"]}),r=m("h3",{content:"AI Logging"}),o=m("div",{classes:["checkbox-container"]});this.aiLoggingCheckbox=m("input",{attributes:{type:"checkbox",id:"ai-logging-checkbox"}});const n=m("label",{content:"Enable AI conversation logging",attributes:{for:"ai-logging-checkbox"}}),i=m("button",{classes:["btn-secondary"],content:"View AI Logs",attributes:{id:"view-ai-logs-btn"}});return this.aiLoggingCheckbox.addEventListener("change",()=>h(this,null,function*(){yield this.settingsService.setAILoggingEnabled(this.aiLoggingCheckbox.checked),this.autoSave()})),i.addEventListener("click",()=>h(this,null,function*(){const{openAILogModal:s}=yield D(()=>h(this,null,function*(){const{openAILogModal:l}=yield import("./AILogModal-CMKEeTi0.js");return{openAILogModal:l}}),__vite__mapDeps([0,1]));s()})),o.appendChild(this.aiLoggingCheckbox),o.appendChild(n),t.appendChild(r),t.appendChild(o),t.appendChild(i),t}createFooter(){const t=m("div",{classes:["modal-footer"]}),r=m("div",{classes:["footer-left"]});this.unsavedIndicator=m("div",{classes:["unsaved-indicator"],content:"Unsaved changes"}),r.appendChild(this.unsavedIndicator);const o=m("div",{classes:["footer-right"]}),n=m("button",{classes:["btn-secondary"],content:"Cancel"}),i=m("button",{classes:["btn-primary"],content:"Save & Close"});return n.addEventListener("click",()=>{this.handleCancel()}),i.addEventListener("click",()=>{this.handleSave()}),o.appendChild(n),o.appendChild(i),t.appendChild(r),t.appendChild(o),t}initializeComponents(){var i,s,l,c;const t=(i=this.element)==null?void 0:i.querySelector(".profile-container");t&&(this.profileSelector=new Lr(t,this.settingsService),this.profileSelector.onSelectionChange(d=>{this.applyProfileToUI(d.profile),this.updateCurrentProfileDisplay(d.profileName),this.emit("profileChanged",d.profileName),this.refreshGlobalProfileSelector&&this.refreshGlobalProfileSelector()}),this.profileSelector.onAction(d=>{this.refreshGlobalProfileSelector&&this.refreshGlobalProfileSelector()}));const r=(s=this.element)==null?void 0:s.querySelector(".criteria-container");r&&(this.criteriaEditor=new Ir(r),this.criteriaEditor.onChange(()=>{this.autoSave()}));const o=(l=this.element)==null?void 0:l.querySelector("#settings-models-container");o&&(this.modelSelector.render(o),o.addEventListener("change",()=>this.autoSave()),o.addEventListener("input",()=>this.autoSave()));const n=(c=this.element)==null?void 0:c.querySelector("#settings-prompts-container");n&&(this.promptService.renderEditor(n),this.promptService.onPromptChange(()=>{this.autoSave()})),this.loadCurrentSettings()}loadCurrentSettings(){const t=this.settingsService.getLastUsedProfile();t&&this.applyProfileToUI(t),this.aiLoggingCheckbox&&(this.aiLoggingCheckbox.checked=this.settingsService.isAILoggingEnabled()),this.updateCurrentProfileDisplay(this.settingsService.getLastUsedProfileName()||""),this.updateUnsavedIndicator(!1)}applyProfileToUI(t){t&&(this.saveTimeout&&(window.clearTimeout(this.saveTimeout),this.saveTimeout=null),t.selectedModels&&this.modelSelector.setSelectedModels(t.selectedModels),this.criteriaEditor&&t.criteria&&this.criteriaEditor.setCriteria(t.criteria),this.maxIterationsInput&&(this.maxIterationsInput.value=String(t.maxIterations||5)),this.updateUnsavedIndicator(!1))}updateCurrentProfileDisplay(t){this.currentProfileDisplay&&(this.currentProfileDisplay.innerHTML=`
                <strong>Active Profile:</strong> ${t}
                <div style="margin-top: 0.25rem; font-size: 0.8em; opacity: 0.8;">
                    Changes are automatically saved to this profile
                </div>
            `)}updateUnsavedIndicator(t){this.hasUnsavedChanges=t,this.unsavedIndicator&&(this.unsavedIndicator.style.display=t?"flex":"none")}autoSave(){this.updateUnsavedIndicator(!0),this.saveTimeout&&window.clearTimeout(this.saveTimeout),this.saveTimeout=window.setTimeout(()=>h(this,null,function*(){yield this.saveCurrentSettingsToProfile(),this.updateUnsavedIndicator(!1)}),2e3)}saveCurrentSettingsToProfile(){return h(this,null,function*(){var n,i;const t=this.settingsService.getLastUsedProfileName();if(!t)return;const r=((n=this.criteriaEditor)==null?void 0:n.getCriteria())||[],o=parseInt(((i=this.maxIterationsInput)==null?void 0:i.value)||"5",10);yield this.settingsService.saveCurrentSettingsToProfile(t,r,o),this.emit("settingsChanged",{type:"saved",data:{profileName:t,criteria:r,maxIterations:o}})})}handleSave(){return h(this,null,function*(){this.saveTimeout&&window.clearTimeout(this.saveTimeout),yield this.saveCurrentSettingsToProfile(),this.updateUnsavedIndicator(!1),this.emit("saved"),this.close()})}handleCancel(){this.hasUnsavedChanges&&!confirm("You have unsaved changes. Are you sure you want to cancel?")||(this.emit("cancelled"),this.close())}handleClose(){this.hasUnsavedChanges&&!confirm("You have unsaved changes. Are you sure you want to close?")||this.close()}setupServiceEventHandlers(){this.settingsService.onChange(t=>{this.emit("settingsChanged",{type:t.type,data:t.data})}),this.promptService.onSave(()=>{this.emit("settingsChanged",{type:"promptsSaved",data:{}})})}destroy(){this.saveTimeout&&window.clearTimeout(this.saveTimeout),super.destroy()}addStyles(t){const r=m("style",{innerHTML:`
                .settings-modal-container {
                    width: 80vw;
                    max-width: 1200px;
                    display: flex;
                    flex-direction: column;
                    max-height: 90vh;
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
                }
                
                .settings-modal-container .modal-header {
                    padding: 1.5rem 2rem 1rem 2rem;
                    border-bottom: 1px solid #e5e7eb;
                    flex-shrink: 0;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .settings-modal-container .modal-header h2 {
                    margin: 0;
                    font-size: 1.5rem;
                    font-weight: 600;
                    color: #111827;
                }
                
                .settings-modal-container .close-button {
                    background: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 50%;
                    width: 32px;
                    height: 32px;
                    cursor: pointer;
                    font-size: 1.2rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: background-color 0.2s;
                }
                
                .settings-modal-container .close-button:hover {
                    background-color: #dc2626;
                }
                
                .settings-modal-container .modal-body {
                    padding: 1.5rem 2rem;
                    display: flex;
                    flex-direction: column;
                    gap: 1.5rem;
                    overflow-y: auto;
                    flex: 1;
                }
                
                .settings-modal-container .modal-footer {
                    padding: 1rem 2rem 1.5rem 2rem;
                    border-top: 1px solid #e5e7eb;
                    flex-shrink: 0;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    gap: 1rem;
                }
                
                .settings-modal-container .footer-left {
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    font-size: 0.875rem;
                    color: #6b7280;
                }
                
                .settings-modal-container .footer-right {
                    display: flex;
                    gap: 0.75rem;
                }
                
                .settings-modal-container .unsaved-indicator {
                    display: none;
                    color: #f59e0b;
                    font-weight: 500;
                    align-items: center;
                    gap: 0.5rem;
                }
                
                .settings-modal-container .unsaved-indicator::before {
                    content: "●";
                    font-size: 1.2em;
                }
                
                .settings-modal-container .settings-section {
                    background-color: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    padding: 1.5rem;
                }
                
                .settings-modal-container .settings-section h3 {
                    margin-top: 0;
                    margin-bottom: 1rem;
                    color: #111827;
                    font-size: 1.125rem;
                    font-weight: 600;
                }
                
                .settings-modal-container .current-profile-info {
                    padding: 0.75rem 1rem;
                    background-color: #eff6ff;
                    border: 1px solid #bfdbfe;
                    border-radius: 8px;
                    font-size: 0.875rem;
                    color: #1e40af;
                    margin-bottom: 1rem;
                }
                
                .settings-modal-container .checkbox-container {
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                    margin-bottom: 1rem;
                }
                
                .settings-modal-container .checkbox-container input[type="checkbox"] {
                    width: 18px;
                    height: 18px;
                    cursor: pointer;
                }
                
                .settings-modal-container .checkbox-container label {
                    cursor: pointer;
                    font-size: 0.9rem;
                    color: #374151;
                }
                
                .settings-modal-container input[type="number"] {
                    padding: 0.5rem;
                    border: 1px solid #d1d5db;
                    border-radius: 6px;
                    font-size: 0.9rem;
                    width: 80px;
                }
                
                .settings-modal-container input[type="number"]:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                
                .settings-modal-container label {
                    display: block;
                    margin-bottom: 0.5rem;
                    font-weight: 500;
                    color: #374151;
                }
                
                .btn-primary,
                .btn-secondary,
                .btn-danger {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 0.875rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .btn-primary {
                    background-color: #3b82f6;
                    color: white;
                }
                
                .btn-primary:hover {
                    background-color: #2563eb;
                }
                
                .btn-secondary {
                    background-color: #6b7280;
                    color: white;
                }
                
                .btn-secondary:hover {
                    background-color: #4b5563;
                }
                
                .btn-danger {
                    background-color: #ef4444;
                    color: white;
                }
                
                .btn-danger:hover {
                    background-color: #dc2626;
                }
            `});t.appendChild(r)}}class $r extends Qe{constructor(t){super(ee(T({},t),{title:"📤 Export Content",id:"export-modal"}));p(this,"projectManager");p(this,"node");p(this,"exportService");p(this,"scopeSelect");p(this,"formatSelect");p(this,"exportButton");p(this,"nodeInfoDisplay");this.projectManager=t.projectManager,this.node=t.node,this.exportService=new Tr}render(){return this.renderContent()}renderContent(){const t=m("div",{classes:["export-modal-container"]});this.addStyles(t);const r=this.createHeader(),o=this.createBody(),n=this.createFooter();return t.appendChild(r),t.appendChild(o),t.appendChild(n),t}createHeader(){const t=m("div",{classes:["modal-header"]}),r=m("h2",{content:"📤 Export Content"});return t.appendChild(r),t}createBody(){const t=m("div",{classes:["modal-body"]}),r=this.createExportSection(),o=this.createNodeInfoSection();return t.appendChild(r),t.appendChild(o),t}createExportSection(){const t=m("div",{classes:["export-section"]}),r=m("h3",{content:"Export Options"}),o=this.createScopeOption(),n=this.createFormatOption();return t.appendChild(r),t.appendChild(o),t.appendChild(n),t}createScopeOption(){const t=m("div",{classes:["export-option"]}),r=m("label",{content:"Scope:",attributes:{for:"export-scope-select"}});return this.scopeSelect=m("select",{attributes:{id:"export-scope-select"}}),[{value:"leafOnly",label:"Lowest hierarchy layer (deepest content)"},{value:"hierarchical",label:"All layers (complete hierarchy)"},{value:"reimport",label:"For reimport (JSON format)"}].forEach(n=>{const i=m("option",{attributes:{value:n.value},content:n.label});this.scopeSelect.appendChild(i)}),this.scopeSelect.addEventListener("change",()=>{this.updateFormatState()}),setTimeout(()=>this.updateFormatState(),0),t.appendChild(r),t.appendChild(this.scopeSelect),t}createFormatOption(){const t=m("div",{classes:["export-option"]}),r=m("label",{content:"Format:",attributes:{for:"export-format-select"}});return this.formatSelect=m("select",{attributes:{id:"export-format-select"}}),[{value:"html",label:"HTML"},{value:"plain",label:"Plain Text"},{value:"markdown",label:"Markdown"}].forEach(n=>{const i=m("option",{attributes:{value:n.value},content:n.label});this.formatSelect.appendChild(i)}),t.appendChild(r),t.appendChild(this.formatSelect),t}createNodeInfoSection(){return this.nodeInfoDisplay=m("div",{classes:["node-info"]}),this.updateNodeInfo(),this.nodeInfoDisplay}updateNodeInfo(){if(!this.nodeInfoDisplay)return;const t=this.getNodePath(),r=this.node.children.length;this.nodeInfoDisplay.innerHTML=`
            <div class="node-info-content">
                <strong>Node:</strong> ${this.node.title}<br>
                <strong>Path:</strong> ${t}<br>
                <strong>Children:</strong> ${r} direct child nodes
            </div>
        `}getNodePath(){try{return this.projectManager&&typeof this.projectManager.getNodePath=="function"?this.projectManager.getNodePath(this.node.id):this.buildNodePath(this.node)}catch(t){return console.warn("Failed to get node path:",t),this.node.title}}buildNodePath(t){const r=[];let o=t;for(;o;){r.unshift(o.title);break}return r.join(" > ")}createFooter(){const t=m("div",{classes:["modal-footer"]}),r=m("button",{classes:["btn-secondary"],content:"Cancel"}),o=m("button",{classes:["btn-secondary"],content:"📋 Copy to Clipboard"});return this.exportButton=m("button",{classes:["btn-primary"],content:"💾 Export File"}),r.addEventListener("click",()=>{this.close()}),o.addEventListener("click",()=>{this.handleClipboardExport()}),this.exportButton.addEventListener("click",()=>{this.handleExport()}),t.appendChild(r),t.appendChild(o),t.appendChild(this.exportButton),t}updateFormatState(){if(!this.scopeSelect||!this.formatSelect)return;const t=this.scopeSelect.value==="reimport";this.formatSelect.disabled=t,t&&(this.formatSelect.value="html")}handleClipboardExport(){return h(this,null,function*(){if(!this.scopeSelect||!this.formatSelect)return;let t,r;if(this.scopeSelect.value==="reimport"){alert("Reimport format is not supported for clipboard export. Please select a different scope.");return}switch(this.scopeSelect.value){case"leafOnly":t="leaves";break;case"hierarchical":t="hierarchy";break;default:t="single"}r=this.formatSelect.value;try{const o=yield this.exportService.export(this.node,{scope:t,format:r});yield navigator.clipboard.writeText(o.content),alert("Content successfully copied to clipboard!"),this.close()}catch(o){const n=o instanceof Error?o.message:"Unknown error";alert(`Failed to copy to clipboard: ${n}`)}})}handleExport(){return h(this,null,function*(){if(!this.scopeSelect||!this.formatSelect||!this.exportButton)return;let t,r;if(this.scopeSelect.value==="reimport")t="single",r="reimport";else{switch(this.scopeSelect.value){case"leafOnly":t="leaves";break;case"hierarchical":t="hierarchy";break;default:t="single"}r=this.formatSelect.value}this.exportButton.disabled=!0,this.exportButton.textContent="Exporting...";try{yield this.exportService.performExport(this.projectManager,this.node,t,r),this.close()}catch(o){const n=o instanceof Error?o.message:"Unknown error";alert(`Export failed: ${n}`),this.exportButton.disabled=!1,this.exportButton.textContent="Export"}})}handleCancel(){this.close()}addStyles(t){const r=m("style",{innerHTML:`
                .export-modal-container {
                    width: 60vw;
                    max-width: 800px;
                    background: white;
                    border-radius: 12px;
                    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
                }
                
                .export-modal-container .modal-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1.5rem 2rem 1rem;
                    border-bottom: 1px solid #e5e7eb;
                }
                
                .export-modal-container .modal-header h2 {
                    margin: 0;
                    font-size: 1.25rem;
                    font-weight: 600;
                    color: #111827;
                }
                
                .export-modal-container .close-button {
                    background: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 50%;
                    width: 32px;
                    height: 32px;
                    cursor: pointer;
                    font-size: 1.2rem;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    transition: background-color 0.2s;
                }
                
                .export-modal-container .close-button:hover {
                    background-color: #dc2626;
                }
                
                .export-modal-container .modal-body {
                    padding: 1.5rem 2rem;
                    display: flex;
                    flex-direction: column;
                    gap: 1.5rem;
                }
                
                .export-modal-container .modal-footer {
                    display: flex;
                    gap: 0.75rem;
                    justify-content: flex-end;
                    padding: 1rem 2rem 1.5rem;
                    border-top: 1px solid #e5e7eb;
                }
                
                .export-modal-container .export-section {
                    background-color: #f9fafb;
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    padding: 1.5rem;
                }
                
                .export-modal-container .export-section h3 {
                    margin-top: 0;
                    margin-bottom: 1rem;
                    color: #1f2937;
                    font-size: 1.125rem;
                    font-weight: 600;
                }
                
                .export-modal-container .export-option {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    margin-bottom: 1rem;
                }
                
                .export-modal-container .export-option:last-child {
                    margin-bottom: 0;
                }
                
                .export-modal-container .export-option label {
                    font-weight: 500;
                    color: #374151;
                    cursor: pointer;
                    user-select: none;
                    min-width: 80px;
                    flex-shrink: 0;
                }
                
                .export-modal-container .export-option select {
                    flex-grow: 1;
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    background-color: white;
                    font-size: 0.875rem;
                    cursor: pointer;
                }
                
                .export-modal-container .export-option select:disabled {
                    background-color: #f3f4f6;
                    color: #6b7280;
                    cursor: not-allowed;
                }
                
                .export-modal-container .export-option select:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                
                .export-modal-container .node-info {
                    padding: 1rem;
                    background-color: #eff6ff;
                    border: 1px solid #bfdbfe;
                    border-radius: 8px;
                }
                
                .export-modal-container .node-info-content {
                    font-size: 0.875rem;
                    color: #1e40af;
                    line-height: 1.5;
                }
                
                .btn-primary,
                .btn-secondary {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 0.875rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .btn-primary {
                    background-color: #3b82f6;
                    color: white;
                }
                
                .btn-primary:hover:not(:disabled) {
                    background-color: #2563eb;
                }
                
                .btn-primary:disabled {
                    background-color: #9ca3af;
                    cursor: not-allowed;
                }
                
                .btn-secondary {
                    background-color: #6b7280;
                    color: white;
                }
                
                .btn-secondary:hover {
                    background-color: #4b5563;
                }
            `});t.appendChild(r)}}class Bt{constructor(e){p(this,"dependencies");p(this,"registry",Pr());this.dependencies=e}setupModalCleanup(e){const t=e.close.bind(e);return e.close=()=>h(this,null,function*(){yield t(),this.registry.unregister(e.id)}),e}createSettingsModal(e={}){const{autoOpen:t=!0,replaceExisting:r=!0}=e;if(r){const i=this.registry.get("settings-modal");i&&i.close()}const o={id:"settings-modal",settingsManager:this.dependencies.settingsManager,modelSelector:this.dependencies.modelSelector,refreshGlobalProfileSelector:this.dependencies.refreshGlobalProfileSelector},n=new Mr(o);return this.registry.register(n),this.setupModalCleanup(n),t&&n.open(),n}createExportModal(r){return h(this,arguments,function*(e,t={}){const{autoOpen:o=!0,replaceExisting:n=!0}=t;if(!this.dependencies.projectManager)throw new Error("ProjectManager is required for ExportModal");if(n){const l=this.registry.get("export-modal");l&&l.close()}const i={id:"export-modal",projectManager:this.dependencies.projectManager,node:e},s=new $r(i);return this.registry.register(s),this.setupModalCleanup(s),o&&s.open(),s})}createGenericModal(e,t,r={}){const{autoOpen:o=!0,replaceExisting:n=!1}=r,i=`generic-modal-${Date.now()}`;n&&this.registry.getOpenModals().filter(c=>c.startsWith("generic-modal-")).forEach(c=>{const d=this.registry.get(c);d&&d.close()});const s=new Dt({id:i,title:t,content:typeof e=="string"?{content:e}:e});return this.registry.register(s),this.setupModalCleanup(s),o&&s.open(),s}alert(e,t="Alert"){return new Promise(r=>{const o=this.createGenericModal({content:`<p>${e}</p>`,actions:[{id:"ok",label:"OK",type:"primary",handler:()=>h(this,null,function*(){yield o.close(),r()})}]},t,{replaceExisting:!1})})}confirm(e,t="Confirm",r="Confirm",o="Cancel"){return new Promise(n=>{const i=this.createGenericModal({content:`<p>${e}</p>`,actions:[{id:"cancel",label:o,type:"secondary",handler:()=>h(this,null,function*(){yield i.close(),n(!1)})},{id:"confirm",label:r,type:"primary",handler:()=>h(this,null,function*(){yield i.close(),n(!0)})}]},t,{replaceExisting:!1})})}prompt(e,t="",r="Input Required"){return new Promise(o=>{const n=`prompt-input-${Date.now()}`,i=this.createGenericModal({content:`
                        <p>${e}</p>
                        <input type="text" id="${n}" value="${t}" 
                               style="width: 100%; padding: 0.5rem; margin-top: 1rem; border: 1px solid #d1d5db; border-radius: 4px;">
                    `,actions:[{id:"cancel",label:"Cancel",type:"secondary",handler:()=>h(this,null,function*(){yield i.close(),o(null)})},{id:"ok",label:"OK",type:"primary",handler:()=>h(this,null,function*(){const s=document.getElementById(n),l=s?s.value:"";yield i.close(),o(l)})}]},r,{replaceExisting:!1});setTimeout(()=>{const s=document.getElementById(n);s&&(s.focus(),s.select())},100)})}closeAll(){return h(this,null,function*(){yield this.registry.closeAll()})}getModal(e){return this.registry.get(e)}getActiveModalIds(){return this.registry.getOpenModals()}updateDependencies(e){this.dependencies=T(T({},this.dependencies),e)}}function Ot(a){return new Bt(a)}let Ve=null;function jt(a){Ve=a}function ue(){if(!Ve)throw new Error("Default modal factory not set. Call setDefaultModalFactory() first.");return Ve}function We(){return ue().createSettingsModal()}function Dr(a){return ue().createExportModal(a)}function Rr(a,e){return ue().alert(a,e)}function _r(a,e){return ue().confirm(a,e)}function Br(a,e,t){return ue().prompt(a,e,t)}const Or=Object.freeze(Object.defineProperty({__proto__:null,ModalFactory:Bt,createModalFactory:Ot,getDefaultModalFactory:ue,openExportModal:Dr,openSettingsModal:We,setDefaultModalFactory:jt,showAlert:Rr,showConfirm:_r,showPrompt:Br},Symbol.toStringTag,{value:"Module"}));function fe(a){const e=Ie(),t=gr();e&&t&&(t.innerHTML=a,e.style.display="flex")}function Gt(){const a=Ie();a&&(a.style.display="none")}function Ke(a){Gr(a);const e=Le();e&&(e.style.display="flex")}function Re(){const a=Le();a&&(a.style.display="none")}function jr(a,e){D(()=>Promise.resolve().then(()=>Or),void 0).then(r=>h(null,[r],function*({ModalFactory:t}){try{const o=V(),n=De();if(!o||!n)throw new Error("Required dependencies not available");const s=yield new t({settingsManager:o,modelSelector:n,projectManager:a}).createExportModal(e)}catch(o){alert("Failed to open export dialog. Please try again.")}})).catch(t=>{alert("Failed to load export modal. Please try again.")})}function Gr(a){const e=Y(),t=fr();if(!e){t.innerHTML="<p>Error: Template Manager not found.</p>";return}const o=e.getTemplateNames().map(n=>`<option value="${n}">${n}</option>`).join("");t.innerHTML=`
        <h2>Create New Project</h2>
        <div class="form-group" style="margin-bottom: 1.5rem;">
            <label for="project-title-input">Project Title</label>
            <input type="text" id="project-title-input" placeholder="e.g., 'My Sci-Fi Epic'">
        </div>
        <div class="form-group" style="margin-bottom: 1.5rem;">
            <label for="project-template-select">Project Template</label>
            <select id="project-template-select">
                ${o}
            </select>
        </div>
        <div class="button-group" style="display: flex; justify-content: flex-end; gap: 1rem;">
            <button id="cancel-create-project-btn" class="button button-secondary">Cancel</button>
            <button id="confirm-create-project-btn" class="button button-primary">Create</button>
        </div>
    `,x("confirm-create-project-btn").addEventListener("click",()=>{const n=x("project-title-input").value,i=x("project-template-select").value,s=e.getTemplate(i);if(!n.trim()||!s){alert("Project Title and a valid template are required.");return}a(n,s)}),x("cancel-create-project-btn").addEventListener("click",Re)}function Fr(a,e){D(()=>h(null,null,function*(){const{showGenericModal:t}=yield import("./index-BTgsZSUm.js");return{showGenericModal:t}}),__vite__mapDeps([2,0,1,3])).then(({showGenericModal:t})=>{const r=t({content:`
                    <style>
                        .modal-content { max-width: 700px; }
                        .extract-section { margin-bottom: 1.5rem; }
                        .extract-section label { display: block; font-weight: bold; margin-bottom: 0.5rem; }
                        .extract-section input, .extract-section select, .extract-section textarea { 
                            width: 100%; 
                            padding: 0.75rem; 
                            border: 1px solid var(--border-color); 
                            border-radius: 8px;
                            box-sizing: border-box;
                        }
                        .extract-section textarea { 
                            resize: vertical; 
                            min-height: 120px; 
                            font-family: inherit; 
                        }
                        .depth-controls { display: flex; align-items: center; gap: 1rem; margin-top: 0.5rem; }
                        .depth-controls label { margin: 0; font-weight: normal; font-size: 0.9rem; }
                        .depth-controls input { width: 80px; }
                        .preview-section { 
                            background-color: #f8f9fa; 
                            border: 1px solid #e9ecef; 
                            border-radius: 8px; 
                            padding: 1rem; 
                            margin-top: 1rem;
                        }
                        .button-row { display: flex; gap: 1rem; justify-content: flex-end; margin-top: 1.5rem; }
                        .button { padding: 0.75rem 1.5rem; border: none; border-radius: 8px; cursor: pointer; }
                        .button-primary { background-color: #007bff; color: white; }
                        .button-secondary { background-color: #6c757d; color: white; }
                        .button:disabled { opacity: 0.6; cursor: not-allowed; }
                    </style>
                    
                    <div class="extract-section">
                        <label for="extract-prompt">What to extract:</label>
                        <input type="text" id="extract-prompt" placeholder="e.g., characters, places, themes, plot points, conflicts..." />
                        <small style="color: #6c757d; font-size: 0.9rem; margin-top: 0.25rem; display: block;">
                            Describe what specific information you want to extract from the content.
                        </small>
                    </div>
                    
                    <div class="extract-section">
                        <label for="extract-depth">Analysis Depth:</label>
                        <select id="extract-depth">
                            <option value="0">This node only</option>
                            <option value="1">Include direct children</option>
                            <option value="2">Include grandchildren (2 levels)</option>
                            <option value="3">Include 3 levels deep</option>
                            <option value="4">Include 4 levels deep</option>
                            <option value="5">Include 5 levels deep</option>
                        </select>
                        <small style="color: #6c757d; font-size: 0.9rem; margin-top: 0.25rem; display: block;">
                            Choose how deep in the hierarchy to analyze content.
                        </small>
                    </div>
                    
                    <div class="extract-section">
                        <button id="preview-btn" class="button button-secondary" style="width: auto;">Preview Content Scope</button>
                        <div id="preview-container" class="preview-section" style="display: none;">
                            <h4 style="margin: 0 0 0.5rem 0;">Content Analysis Preview:</h4>
                            <div id="preview-content" style="font-size: 0.9rem; color: #495057; white-space: pre-line;"></div>
                        </div>
                    </div>
                    
                    <div id="loading-section" class="extract-section" style="display: none;">
                        <div style="text-align: center; padding: 2rem;">
                            <div style="font-size: 2rem; margin-bottom: 1rem;">⏳</div>
                            <div style="font-weight: bold; margin-bottom: 0.5rem;">Extracting Context...</div>
                            <div style="color: #6c757d; font-size: 0.9rem;">This may take a moment depending on content size</div>
                        </div>
                    </div>
                    
                    <div id="result-section" class="extract-section" style="display: none;">
                        <label for="extract-result">Extracted Information:</label>
                        <textarea id="extract-result" readonly></textarea>
                        <div style="margin-top: 0.5rem;">
                            <button id="copy-result-btn" class="button button-secondary">Copy to Clipboard</button>
                            <button id="add-to-context-btn" class="button button-primary">Add to Node Context</button>
                        </div>
                    </div>
                `,actions:[{id:"cancel",label:"Cancel",type:"secondary",handler:()=>h(null,null,function*(){yield r.close()})},{id:"extract",label:"Extract Context",type:"primary",handler:()=>h(null,null,function*(){var w;const o=document.getElementById("extract-prompt"),n=document.getElementById("extract-depth"),i=(w=o==null?void 0:o.value)==null?void 0:w.trim(),s=parseInt((n==null?void 0:n.value)||"0");if(!i)throw alert("Please enter what you want to extract."),o==null||o.focus(),new Error("Missing prompt");const l=a.getContextExtractionService(),c=l.validateExtractionParameters(e,i,s);if(c.errors.length>0)throw alert(`Validation errors:

`+c.errors.join(`
`)),new Error("Validation failed");if(c.warnings.length>0){const y=`Warnings:

`+c.warnings.join(`
`)+`

Do you want to proceed anyway?`;if(!confirm(y))throw new Error("User cancelled")}const d=document.querySelector('[data-action-id="extract"]'),u=document.getElementById("loading-section"),g=document.getElementById("result-section"),f=(d==null?void 0:d.textContent)||"Extract Context";d&&(d.disabled=!0,d.textContent="⏳ Extracting..."),u&&(u.style.display="block"),g&&(g.style.display="none");try{const y=yield l.extractContext(e,i,s);u&&(u.style.display="none");const S=document.getElementById("extract-result");throw S&&g&&(S.value=y,g.style.display="block"),d&&(d.disabled=!1,d.textContent="🔄 Extract Again"),new Error("__KEEP_MODAL_OPEN__")}catch(y){throw u&&(u.style.display="none"),d&&(d.disabled=!1,d.textContent=f),y.message==="__KEEP_MODAL_OPEN__"||alert(`Error during extraction:

`+y.message),y}})}]},{title:"Extract Context",maxWidth:"700px"},{onOpen:()=>{zr(a,e)},onClose:()=>{}})})}function zr(a,e){const t=x("extract-prompt"),r=x("extract-depth"),o=x("preview-btn"),n=x("preview-container"),i=x("preview-content");x("result-section");const s=x("extract-result"),l=x("copy-result-btn"),c=x("add-to-context-btn");t==null||t.focus(),o==null||o.addEventListener("click",()=>{const d=parseInt((r==null?void 0:r.value)||"0"),g=a.getContextExtractionService().getContentPreview(e,d);i&&(i.textContent=g.summary),n&&(n.style.display="block")}),l==null||l.addEventListener("click",()=>h(null,null,function*(){try{s&&(yield navigator.clipboard.writeText(s.value),l.textContent="Copied!",setTimeout(()=>{l.textContent="Copy to Clipboard"},2e3))}catch(d){alert("Failed to copy to clipboard")}})),c==null||c.addEventListener("click",()=>{if(s){const d=e.context||"",u=d+(d?`

`:"")+s.value;e.context=u;const g=document.getElementById("node-context");g&&(g.value=u),a.saveToStorage(),c.textContent="Added!",setTimeout(()=>{c.textContent="Add to Node Context"},1e3)}}),t==null||t.addEventListener("keydown",d=>{if(d.key==="Enter"){const u=document.querySelector('[data-action-id="extract"]');u==null||u.click()}})}function Hr(a,e){let t=null;t=Rt({content:`
            <style>
                .modal-content { max-width: 800px; }
                .chat-section { margin-bottom: 1.5rem; }
                .chat-section label { display: block; font-weight: bold; margin-bottom: 0.5rem; }
                .chat-section select, .chat-section textarea { 
                    width: 100%; 
                    padding: 0.75rem; 
                    border: 1px solid var(--border-color); 
                    border-radius: 8px;
                    box-sizing: border-box;
                }
                .preview-section { 
                    background-color: #f8f9fa; 
                    border: 1px solid #e9ecef; 
                    border-radius: 8px; 
                    padding: 1rem; 
                    margin-top: 1rem;
                }
                .button { padding: 0.75rem 1.5rem; border: none; border-radius: 8px; cursor: pointer; }
                .button-primary { background-color: #007bff; color: white; }
                .button-secondary { background-color: #6c757d; color: white; }
                .button:disabled { opacity: 0.6; cursor: not-allowed; }
            </style>
            <div class="modal-header" style="margin-bottom: 1.5rem; border-bottom: 1px solid #e5e7eb; padding-bottom: 1rem;">
                <h2 style="margin: 0;">Chat with Node</h2>
            </div>
            
            <div class="chat-section">
                <label for="chat-depth">Scope Depth:</label>
                <select id="chat-depth">
                    <option value="0">This node only</option>
                    <option value="1">Include direct children</option>
                    <option value="2">Include grandchildren (2 levels)</option>
                    <option value="3">Include 3 levels deep</option>
                    <option value="4">Include 4 levels deep</option>
                    <option value="5">Include 5 levels deep</option>
                </select>
                <small style="color: #6c757d; font-size: 0.9rem; margin-top: 0.25rem; display: block;">
                    Choose how deep in the hierarchy to include in the chat context.
                </small>
            </div>
            
            <div class="chat-section">
                <button id="preview-content-btn" class="button button-secondary" style="width: auto;">Preview Content Size</button>
                <div id="content-preview-container" class="preview-section" style="display: none;">
                    <h4 style="margin: 0 0 0.5rem 0;">Content Size Analysis:</h4>
                    <div id="content-preview-content" style="font-size: 0.9rem; color: #495057; white-space: pre-line;"></div>
                </div>
            </div>
        `,actions:[{id:"cancel",label:"Cancel",type:"secondary",handler:()=>h(null,null,function*(){t&&t.close()})},{id:"start-chat",label:"Start Chat",type:"primary",handler:()=>h(null,null,function*(){const o=document.getElementById("chat-depth");if(o){const n=parseInt(o.value);try{const i=a.getContextExtractionService(),s=i.validateChatContextParameters(e,n);if(s.errors.length>0){alert(`Validation errors:

`+s.errors.join(`
`));return}if(s.warnings.length>0){const u=`Content Size Warnings:

`+s.warnings.join(`
`)+`

Do you want to proceed anyway?

Note: Large contexts may result in higher costs and slower responses.`;if(!confirm(u))return}const l=i.createNodeTreeData(e,a.rootNode,n),d=a.getSettingsManager().getPrompts().node_chat_system.replace("{{node_data}}",l);t&&t.close(),Ur(a,d,e.title)}catch(i){throw alert(`Error preparing chat:

`+i.message),i}}})}]},{},{onOpen:()=>{const o=document.getElementById("chat-depth");o&&o.focus();const n=document.getElementById("preview-content-btn"),i=document.getElementById("content-preview-container"),s=document.getElementById("content-preview-content");n&&i&&s&&n.addEventListener("click",()=>{try{const l=parseInt(o.value),d=a.getContextExtractionService().getChatContentPreview(e,l);s.textContent=d.summary,i.style.display="block"}catch(l){console.error("Error in content preview:",l),alert("Error generating content preview: "+l.message)}})}})}function Ur(a,e,t){return h(this,null,function*(){try{const{ChatInterface:r}=yield D(()=>h(null,null,function*(){const{ChatInterface:y}=yield import("./chat-interface-DhcuQd-H.js");return{ChatInterface:y}}),__vite__mapDeps([4,1])),{OpenRouterClient:o}=yield D(()=>h(null,null,function*(){const{OpenRouterClient:y}=yield Promise.resolve().then(()=>Jr);return{OpenRouterClient:y}}),void 0),n=yield D(()=>Promise.resolve().then(()=>Cr),void 0),i=n.getSettingsManager(),s=n.getModelSelector();if(!i||!s){alert("Settings or model selector not available.");return}const l=s.getApiKey();if(!l){alert("OpenRouter API key not configured. Please set it in the settings first.");return}const c=s.getSelectedModels();if(!s.areAllModelsSelected()){alert("Please configure all required models in the settings first.");return}const d=new o(l,c);d.setSettingsManager(i);const u=document.createElement("div");u.style.cssText=`
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: center;
        `;const g=document.createElement("div");g.style.cssText=`
            width: 90%;
            height: 90%;
            max-width: 1200px;
            max-height: 800px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        `,u.appendChild(g),document.body.appendChild(u),yield new r(d,i,e,t).initialize(g);const w=()=>{document.body.removeChild(u)};u.addEventListener("click",y=>{y.target===u&&w()}),document.addEventListener("keydown",function y(S){S.key==="Escape"&&(w(),document.removeEventListener("keydown",y))})}catch(r){console.error("Error opening chat interface:",r),alert("Failed to open chat interface. Please try again.")}})}const Fe=Object.freeze(Object.defineProperty({__proto__:null,closeNewProjectModal:Re,closeTestModal:Gt,openExportModal:jr,openExtractContextModal:Fr,openNewProjectModal:Ke,openNodeChatModal:Hr,openTestModal:fe},Symbol.toStringTag,{value:"Module"}));class pe{constructor(e,t,r=null,o=[]){p(this,"id");p(this,"level");p(this,"title");p(this,"parentId");p(this,"children",[]);p(this,"_content","");p(this,"_isSettingContentFromGeneration",!1);p(this,"context","");p(this,"template");p(this,"generationPrompt",null);p(this,"isPromptGenerating",!1);p(this,"generationChildrenCount",5);p(this,"generationHistory",[]);p(this,"isGenerating",!1);p(this,"generationSessions",[]);p(this,"currentGenerationSession",null);this.id=ot(),this.level=e,this.title=t,this.parentId=r,this.template=o,this.generationPrompt=null,this.isPromptGenerating=!1,this.generationHistory=[],this.isGenerating=!1,this.content="",this.context="",this.generationSessions=[],this.currentGenerationSession=null,this.generationChildrenCount=this.parseGenerationCountFromTemplate()}parseGenerationCountFromTemplate(){if(!this.template||this.isLeaf)return 5;const e=this.level+1;if(e>=this.template.length)return 5;const t=this.template[e];if(!t)return 5;const r=t.match(/(\w+)\s+(\d+)/);if(r&&r[2]){const o=parseInt(r[2],10);if(!isNaN(o)&&o>0&&o<=20)return o}return 5}get content(){return this._content}set content(e){this._content=e,this._isSettingContentFromGeneration||(this.generationHistory=[],this.generationSessions=[],this.currentGenerationSession=null)}setContentFromGeneration(e){this._isSettingContentFromGeneration=!0,this.content=e,this._isSettingContentFromGeneration=!1}startGenerationSession(e){const t=ot();return this.currentGenerationSession={sessionId:t,startTime:new Date,originalPrompt:e,iterations:[],finalIterationNumber:0,success:!1,totalIterationsAttempted:0},t}addGenerationIteration(e,t,r){if(!this.currentGenerationSession)throw new Error("No active generation session. Call startGenerationSession first.");const o={iteration:e,content:t,ratings:r.map(n=>T({},n)),wasChosen:!1,timestamp:new Date};this.currentGenerationSession.iterations.push(o),this.currentGenerationSession.totalIterationsAttempted=Math.max(this.currentGenerationSession.totalIterationsAttempted,e)}endGenerationSession(e,t){if(!this.currentGenerationSession)throw new Error("No active generation session to end.");this.currentGenerationSession.endTime=new Date,this.currentGenerationSession.success=e;const r=this.currentGenerationSession.iterations.find(o=>o.content===t);if(r)r.wasChosen=!0,this.currentGenerationSession.finalIterationNumber=r.iteration;else{const o=this.currentGenerationSession.iterations[this.currentGenerationSession.iterations.length-1];o&&(o.wasChosen=!0,this.currentGenerationSession.finalIterationNumber=o.iteration)}this.generationSessions.push(this.currentGenerationSession),this.currentGenerationSession=null}getLatestGenerationSession(){return this.generationSessions.length>0?this.generationSessions[this.generationSessions.length-1]:null}getRejectedIterations(){const e=this.getLatestGenerationSession();return e?e.iterations.filter(t=>!t.wasChosen):[]}getChosenIteration(){const e=this.getLatestGenerationSession();return e&&e.iterations.find(t=>t.wasChosen)||null}get isLeaf(){return this.level>=this.template.length-1}get childLevelName(){if(this.isLeaf)return null;const e=this.template[this.level+1]||null;if(!e)return null;const t=e.match(/^(\w+)(?:\s+\d+)?$/);return t?t[1]:e}getState(){return!this.content||this.content.trim()===""?"Empty":this.content.trim().startsWith("Draft:")?"Draft":"Final"}toJSON(){return{id:this.id,level:this.level,title:this.title,parentId:this.parentId,children:this.children,content:this._content,context:this.context,template:this.template,generationPrompt:this.generationPrompt,isPromptGenerating:this.isPromptGenerating,generationHistory:this.generationHistory,isGenerating:this.isGenerating,generationSessions:this.generationSessions,generationChildrenCount:this.generationChildrenCount}}}class Ft{constructor(){p(this,"listeners",{})}on(e,t){this.listeners[e]||(this.listeners[e]=[]),this.listeners[e].push(t)}off(e,t){this.listeners[e]&&(this.listeners[e]=this.listeners[e].filter(r=>r!==t))}emit(e,...t){this.listeners[e]&&this.listeners[e].forEach(r=>r(...t))}}class zt{findNodeById(e,t){if(t.id===e)return t;for(const r of t.children){const o=this.findNodeById(e,r);if(o)return o}return null}addNode(e,t,r){const o=t?this.findNodeById(t,r):r;if(!o)throw new Error(`Parent node with ID "${t}" not found.`);const n=o.level+1,i=new pe(n,e,o.id,o.template);return o.children.push(i),i}removeNode(e,t){const r=this.findNodeById(e,t);if(!r||!r.parentId)return!1;const o=this.findNodeById(r.parentId,t);if(!o)return!1;const n=o.children.findIndex(i=>i.id===e);return n>-1?(o.children.splice(n,1),!0):!1}getNodePath(e,t){const r=[];let o=this.findNodeById(e,t);for(;o;){const n=o.template[o.level]||`Level ${o.level}`,i=n.match(/^(\w+)(?:\s+\d+)?$/),s=i?i[1]:n;r.unshift(`${s}: ${o.title}`),o=o.parentId?this.findNodeById(o.parentId,t):null}return r.join(" => ")}traverseNodes(e,t){t(e);for(const r of e.children)this.traverseNodes(r,t)}findParentNode(e,t){const r=this.findNodeById(e,t);return!r||!r.parentId?null:this.findNodeById(r.parentId,t)}getNodeDepth(e,t){const r=this.findNodeById(e,t);return r?r.level:-1}getSiblings(e,t){const r=this.findNodeById(e,t);if(!r||!r.parentId)return[];const o=this.findNodeById(r.parentId,t);return o?o.children.filter(n=>n.id!==e):[]}isAnyNodeGenerating(e){const t=r=>r.isGenerating?!0:r.children.some(o=>t(o));return t(e)}clearAllGeneratingFlags(e){const t=r=>{r.isGenerating=!1,r.children.forEach(o=>t(o))};t(e)}getNodesAtLevel(e,t){const r=[];return this.traverseNodes(t,o=>{o.level===e&&r.push(o)}),r}getLeafNodes(e){const t=[];return this.traverseNodes(e,r=>{r.children.length===0&&t.push(r)}),t}}class Ht{constructor(e,t,r){this.treeService=e,this.openRouterClient=t,this.settingsManager=r}compileNodeContext(e,t){const r=this.treeService.findNodeById(e,t);if(!r)return"";const o=[];if(r.context&&r.context.trim()){const s=r.template[r.level]||`Level ${r.level}`;o.push(`CURRENT NODE CONTEXT (${s}: "${r.title}"):
---
${r.context}
---`)}if(!r.parentId)return o.join(`

====================

`);const n=this.treeService.findNodeById(r.parentId,t);if(!n)return o.join(`

====================

`);if(n.context&&n.context.trim()){const s=n.template[n.level]||`Level ${n.level}`;o.push(`PARENT CONTEXT (${s}: "${n.title}"):
---
${n.context}
---`)}if(n.content){const s=n.template[n.level]||`Level ${n.level}`;o.push(`STRUCTURAL CONTEXT FROM PARENT (${s}: "${n.title}"):
---
${n.content}
---`)}if(n.children.length>1){const s=r.template[r.level]||`Level ${r.level}`,l=n.children.map(c=>`- ${c.title} ${c.id===e?"(This node)":""}`).join(`
`);o.push(`SIBLING SCOPE (${s} nodes at this level):
${l}`)}const i=this.buildPrecedingSiblingContext(r,n);return i&&o.push(i),o.join(`

====================

`)}collectParentContextForSummary(e,t){const r=[];if(!e.parentId)return r;const o=this.treeService.findNodeById(e.parentId,t);if(o&&o.context&&o.context.trim()){const n=o.template[o.level]||`Level ${o.level}`;r.push(`PARENT (${n}: "${o.title}"):
---
${o.context}
---`)}return r}buildSiblingContext(e,t){if(!e.parentId)return"";const r=this.treeService.findNodeById(e.parentId,t);return r?this.buildPrecedingSiblingContext(e,r):""}buildParentContext(e,t){if(!e.parentId)return"";const r=this.treeService.findNodeById(e.parentId,t);return!r||!r.content?"":`STRUCTURAL CONTEXT FROM PARENT (${r.template[r.level]||`Level ${r.level}`}: "${r.title}"):
---
${r.content}
---`}buildPrecedingSiblingContext(e,t){const r=[],o=t.children.findIndex(n=>n.id===e.id);if(o>0){r.push("CONTENT FROM PRECEDING SIBLINGS:");for(let n=0;n<o;n++){const i=t.children[n];i.content&&r.push(`Content for "${i.title}":
---
${i.content}
---`)}}return r.length>1?r.join(`

`):""}getContextSummary(e,t){const r=this.treeService.findNodeById(e,t);if(!r)return"Node not found";const o=[];if(r.context&&r.context.trim()&&o.push(`Own context: ${r.context.length} chars`),this.collectParentContextForSummary(r,t).length>0&&o.push("Inherited from parent"),r.parentId){const i=this.treeService.findNodeById(r.parentId,t);i&&i.content&&o.push(`Parent content: ${i.content.length} chars`)}return o.length>0?o.join(", "):"No context available"}hasMinimalContext(e,t){return this.compileNodeContext(e,t).trim().length>0}synthesizeContext(e,t){return h(this,null,function*(){if(!this.openRouterClient||!this.settingsManager)throw new Error("ContextService: OpenRouterClient or SettingsManager not available for context synthesis");const r=this.treeService.findNodeById(e,t);if(!r)throw new Error(`ContextService: Node ${e} not found`);let o="";if(r.parentId){const n=this.treeService.findNodeById(r.parentId,t);n&&n.context&&(o=n.context)}if(!r.content||r.content.trim()==="")return console.warn(`ContextService: Node ${e} has no content for synthesis`),null;try{const{cleanedContext:n,persistData:i}=this.extractPersistTags(o),l=this.settingsManager.getPrompts().context_synthesis_user.replace(/{{parent_context}}/g,n||"No parent context available.").replace(/{{node_content}}/g,r.content),c=yield this.openRouterClient.chat("editor",l);return c&&c.trim()!==""?this.appendPersistData(c.trim(),i):(console.warn(`ContextService: Empty response from context synthesis for node ${e}`),null)}catch(n){return console.error(`ContextService: Failed to synthesize context for node ${e}:`,n),null}})}extractPersistTags(e){const t=[],r=/<persist>([\s\S]*?)<\/persist>/g;let o;for(;(o=r.exec(e))!==null;)t.push(o[1]);return{cleanedContext:e.replace(r,"").trim(),persistData:t}}appendPersistData(e,t){if(t.length===0)return e;const r=t.map(o=>`<persist>${o}</persist>`);return e+`

`+r.join(`

`)}}class qr{constructor(e){this.settingsManager=e}getRawGenerationPrompt(e){const t=this.settingsManager.getPrompts();return e.parentId?e.isLeaf?t.content_generation_user:t.branch_content_generation_user:t.expand_text_user}fillGenerationPrompt(e,t,r,o,n){let i="";t.content?t.content.startsWith("Draft:")?i=`You have this existing draft to build upon:
---
${t.content}
---

Please expand this draft into full, detailed content. Use the draft as a guide for what should be covered, but write complete, polished content that goes well beyond the brief draft description.`:i=`You have this existing content to revise or expand:
---
${t.content}
---

Please improve and expand this content.`:i="Now, write the full content for this node.";let s=e.replace(/\{\{path\}\}/g,o).replace(/\{\{context\}\}/g,r).replace(/\{\{title\}\}/g,t.title).replace(/\{\{child_level_name\}\}/g,t.childLevelName||"").replace(/\{\{content\}\}/g,t.content||"").replace(/\{\{draftorfresh\}\}/g,i);return t.parentId,!t.isLeaf&&n&&(s=s.replace(/\{\{count\}\}/g,String(n))),s}parseBulletedList(e){return e.split(`
`).map(t=>t.trim()).filter(t=>t.startsWith("*")||t.startsWith("-")).map(t=>t.substring(1).trim()).filter(t=>t.length>0)}filterCriteriaForNodeType(e,t){return e.filter(r=>r.outline===void 0&&r.leaf===void 0?!0:t?r.leaf===!0:r.outline===!0)}getAvailablePrompts(e,t){const r=this.settingsManager.getPrompts();return e?{expand_text:r.expand_text_user}:t?{content_generation:r.content_generation_user}:{branch_content_generation:r.branch_content_generation_user}}validatePromptTemplate(e,t,r){const o=[];if(!t){const n=["{{path}}","{{context}}","{{title}}"];for(const i of n)e.includes(i)||o.push(`Missing required placeholder: ${i}`);r||e.includes("{{child_level_name}}")||o.push("Missing required placeholder for branch nodes: {{child_level_name}}")}return o}getPlaceholderDescriptions(){return{"{{path}}":"The hierarchical path from root to this node","{{context}}":"Compiled contextual information from ancestors, siblings, and parent","{{title}}":"The title of the current node","{{content}}":"The current content of the node (if any)","{{child_level_name}}":"The name of the child level (for branch nodes)","{{count}}":"The number of items to generate (for list generation)"}}estimateTokenCount(e){return Math.ceil(e.length/4)}exceedsContextLimit(e,t=32e3){return this.estimateTokenCount(e)>t}truncateContextIfNeeded(e,t=2e4){if(this.estimateTokenCount(e)<=t)return e;const o=t*4;return e.substring(0,o)+`

[... context truncated due to length ...]`}}class Vr{constructor(e,t){p(this,"currentGenerationContext",null);p(this,"abortRequested",!1);p(this,"isGeneratingAllChildren",!1);this.loopOrchestrator=e,this.treeService=t}startGeneration(e){this.currentGenerationContext=e,this.abortRequested=!1,e.type==="bulk"&&(this.isGeneratingAllChildren=!0)}abortCurrentGeneration(e){var r;this.abortRequested=!0,this.currentGenerationContext&&this.currentGenerationContext.abortController.abort(),this.loopOrchestrator.requestStop(),this.treeService.clearAllGeneratingFlags(e);const t=((r=this.currentGenerationContext)==null?void 0:r.nodeIds)||[];return this.currentGenerationContext=null,this.isGeneratingAllChildren=!1,t}canAbortGeneration(e){return this.currentGenerationContext!==null||this.treeService.isAnyNodeGenerating(e)}getCurrentGenerationInfo(){return this.currentGenerationContext?{type:this.currentGenerationContext.type,nodeCount:this.currentGenerationContext.nodeIds.length,canAbort:!0}:null}isAbortRequested(){return this.abortRequested}isBulkGenerationActive(){return this.isGeneratingAllChildren}getCurrentContext(){return this.currentGenerationContext}clearGenerationContext(){this.currentGenerationContext=null,this.isGeneratingAllChildren=!1,this.abortRequested=!1}setupSingleNodeGeneration(e){const t={type:"single",nodeIds:[e],abortController:new AbortController};return this.startGeneration(t),t}setupBulkGeneration(e){const t={type:"bulk",nodeIds:e,abortController:new AbortController};return this.startGeneration(t),t}validateGenerationCanProceed(e,t){if(!e&&this.canAbortGeneration(t))throw new Error("Another generation operation is already in progress. Please abort it first or wait for completion.")}}class dt{constructor(e){p(this,"deps");p(this,"isGeneratingAllChildren",!1);p(this,"abortRequested",!1);this.deps=e}cleanupGenerationState(e,t,r=!1){t.isGenerating=!1,r||this.deps.generationController.clearGenerationContext()}isAbortRequested(){return this.abortRequested||this.deps.generationController.isAbortRequested()}rateNodeContent(e){return h(this,null,function*(){const t=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!t)throw new Error(`Node not found: ${e}`);if(!t.content||t.content.trim()==="")throw new Error(`Node "${t.title}" has no content to rate`);if(this.deps.generationController.canAbortGeneration(this.deps.rootNode))throw new Error("Another generation operation is already in progress. Please abort it first or wait for completion.");const r=this.deps.settingsManager.getLastUsedProfile();if(!r||!r.criteria||r.criteria.length===0)throw new Error(`Cannot rate content for node "${t.title}" (ID: ${e}). The active profile is either missing, has no criteria defined, or could not be loaded.`);this.abortRequested=!1,this.deps.generationController.setupSingleNodeGeneration(e);const o=t.generationPrompt||this.deps.promptService.getRawGenerationPrompt(t),n=this.deps.contextService.compileNodeContext(e,this.deps.rootNode),i=this.deps.treeService.getNodePath(e,this.deps.rootNode),s=this.deps.promptService.fillGenerationPrompt(o,t,n,i),l=this.filterCriteriaForNodeType(r.criteria,t.isLeaf);try{t.isGenerating=!0,this.deps.eventEmitter.emit("nodeGenerationStarted",{nodeId:e,node:t}),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:`Rating content for "${t.title}"...`,current:0,total:1});const c=yield this.deps.loopOrchestrator.rateContent(s,t.content,l);t.startGenerationSession(s),t.addGenerationIteration(1,t.content,c),t.endGenerationSession(!0,t.content),yield this.deps.saveToStorage(),this.cleanupGenerationState(e,t,!1),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:1,total:1}),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!0,node:t})}catch(c){throw this.cleanupGenerationState(e,t,!1),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!1,error:c,node:t}),c}})}generateNodeContent(e,t=5,r=!1){return h(this,null,function*(){const o=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!o)throw new Error(`Node not found: ${e}`);if(!r&&this.deps.generationController.canAbortGeneration(this.deps.rootNode))throw new Error("Another generation operation is already in progress. Please abort it first or wait for completion.");r||(this.abortRequested=!1,this.deps.generationController.setupSingleNodeGeneration(e));const n=this.extractSettingsOverride(o),i=n?this.deps.settingsManager.getLastUsedProfileName():null;n&&(this.deps.settingsManager.getProfile(n)?(console.log(`🔧 Using settings override "${n}" for node "${o.title}"`),yield this.deps.settingsManager.setLastUsedProfile(n)):console.warn(`⚠️ Settings override "${n}" not found for node "${o.title}". Using current settings.`));const s=this.deps.settingsManager.getLastUsedProfile();if(!s||!s.criteria||s.criteria.length===0)throw this.deps.generationController.clearGenerationContext(),new Error(`Cannot generate content for node "${o.title}" (ID: ${e}). The active profile is either missing, has no criteria defined, or could not be loaded.`);const l=o.generationPrompt||this.deps.promptService.getRawGenerationPrompt(o),c=this.deps.contextService.compileNodeContext(e,this.deps.rootNode),d=this.deps.treeService.getNodePath(e,this.deps.rootNode),g={prompt:this.deps.promptService.fillGenerationPrompt(l,o,c,d,r?void 0:t),criteria:this.filterCriteriaForNodeType(s.criteria,o.isLeaf),maxIterations:s.maxIterations,response:""},f=r?o.parentId:e;try{yield this.runContentLoop(e,g,f||void 0,r)}catch(w){throw r||this.deps.generationController.clearGenerationContext(),w}finally{n&&i&&(console.log(`🔄 Restoring original settings profile "${i}" after generation`),yield this.deps.settingsManager.setLastUsedProfile(i))}})}runContentLoop(e,t,r,o=!1){return h(this,null,function*(){var g;const n=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!n){console.error(`Node not found in runContentLoop: ${e}`);return}const i=this.deps.settingsManager.getLastUsedProfile();if(i&&i.selectedModels)this.deps.openRouterClient.setSelectedModels(i.selectedModels);else{const f=`Could not find a valid active profile with models for node ${n.title}. Cannot run content loop.`;this.deps.eventEmitter.emit("error",f),console.error(f);return}n.isGenerating=!0,console.log(`🚀 Starting generation for: "${n.title}" (${e})`),this.deps.eventEmitter.emit("nodeGenerationStarted",{nodeId:e,node:n}),o||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:`Generating content for "${n.title}"...`,current:0,total:1}),n.startGenerationSession(t.prompt);let s=null,l=[];const c=f=>{if(!this.isAbortRequested()){if(f.type==="creator"){const w=f.payload;if(w.response.includes("is working")){if(!this.isGeneratingAllChildren){const y=document.getElementById("generation-status");y&&(y.textContent=w.response,y.style.display="block")}}else if(s=w.response,!this.isGeneratingAllChildren){const y=document.getElementById("node-content");y&&document.activeElement!==y&&(y.value=w.response)}}else if(f.type==="rater"){const w=f.payload;if(w.rating&&w.rating.criterion){const y=l.findIndex(S=>S.criterion===w.rating.criterion);y>=0?l[y]=w.rating:l.push(w.rating),l.length===t.criteria.length&&s&&(n.addGenerationIteration(f.iteration,s,[...l]),l=[])}}this.deps.eventEmitter.emit("loop-progress",{nodeId:r||e,progress:f})}},d=f=>{},u=f=>{this.deps.eventEmitter.emit("loop-progress",{nodeId:r||e,progress:{type:"creator",payload:{prompt:"Initializing generation...",response:""},iteration:0,maxIterations:f.maxIterations,step:0,totalStepsInIteration:3}})};this.deps.loopOrchestrator.on("started",u),this.deps.loopOrchestrator.on("progress",c),this.deps.loopOrchestrator.on("aborted",d);try{const f=yield this.deps.loopOrchestrator.runLoop(t);f.aborted||this.isAbortRequested()?(n.endGenerationSession(!1,s||""),s&&n.setContentFromGeneration(s),this.cleanupGenerationState(e,n,o),this.deps.eventEmitter.emit("nodeGenerationAborted",{nodeId:e,node:n}),o||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1})):(n.endGenerationSession(f.success,f.finalResponse),n.setContentFromGeneration(f.finalResponse),n.generationHistory=f.history,yield this.synthesizeNodeContext(e,o),this.cleanupGenerationState(e,n,o),console.log(`✅ Node generation completed: "${n.title}" (${e}) - Content length: ${((g=n.content)==null?void 0:g.length)||0} characters`),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!0,node:n}),o||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:1,total:1}))}catch(f){if(console.error(`Error running content loop for node ${e}:`,f),n.currentGenerationSession&&n.endGenerationSession(!1,s||""),this.cleanupGenerationState(e,n,o),f.message==="Generation aborted by user"||this.isAbortRequested())this.deps.eventEmitter.emit("nodeGenerationAborted",{nodeId:e,node:n});else{const w=f.message||"An unexpected error occurred during content generation.";this.deps.eventEmitter.emit("error",w),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!1,error:f,node:n})}o||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1})}finally{if(this.deps.loopOrchestrator.off("started",u),this.deps.loopOrchestrator.off("progress",c),this.deps.loopOrchestrator.off("aborted",d),!o){const f=document.getElementById("generation-status");f&&(f.style.display="none",f.textContent="")}o||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1}),yield this.deps.saveToStorage()}})}createChildrenFromOutline(e){return h(this,null,function*(){const t=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!t||!t.content){this.deps.eventEmitter.emit("error",`Cannot create children for node ${e}: No content found.`);return}const r=this.extractSettingsOverrideFromNode(t),o=r?this.deps.settingsManager.getLastUsedProfileName():null;r&&(this.deps.settingsManager.getProfile(r)?(console.log(`🔧 Using settings override "${r}" for creating children of "${t.title}"`),yield this.deps.settingsManager.setLastUsedProfile(r)):console.warn(`⚠️ Settings override "${r}" not found for creating children of "${t.title}". Using current settings.`)),t.isGenerating=!0,this.deps.eventEmitter.emit("nodeGenerationStarted",{nodeId:e,node:t}),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"Reading outline and generating titles...",current:0,total:1}),t.children=[];const n=this.deps.settingsManager.getPrompts(),i=this.deps.contextService.compileNodeContext(e,this.deps.rootNode),s=t.childLevelName||"item",l=n.create_children_from_outline_user.replace(/{{outline_content}}/g,t.content).replace(/{{child_level_name}}/g,s).replace(/{{context}}/g,i).replace(/{{count}}/g,String(t.generationChildrenCount));try{const c=yield this.deps.openRouterClient.chat("creator",l),d=this.parseChildrenFromJSON(c);if(d.length===0){t.isGenerating=!1;const u=`The AI did not return a valid list of titles from the outline.

AI Response:
"${c}"`;this.deps.eventEmitter.emit("error",u),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1});return}d.forEach(u=>{const g=this.deps.treeService.addNode(u.title,e,this.deps.rootNode);u.description&&u.description.trim()&&(g.content=`Draft: ${u.description}`)}),yield this.deps.saveToStorage(),t.isGenerating=!1,this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!0,node:t}),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:1,total:1})}catch(c){console.error("Failed to create children from outline via LLM:",c),t.isGenerating=!1,this.deps.eventEmitter.emit("error","The AI failed to process the outline. Please try again."),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!1,error:c,node:t}),this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1})}finally{r&&o&&(console.log(`🔄 Restoring original settings profile "${o}" after creating children`),yield this.deps.settingsManager.setLastUsedProfile(o))}})}generateAllChildrenContent(e,t=!0,r=!1){return h(this,null,function*(){var i,s,l;let o=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!o){this.deps.eventEmitter.emit("error",`Could not find node with ID ${e} to generate children content for.`);return}if(this.deps.generationController.canAbortGeneration(this.deps.rootNode)&&!this.isGeneratingAllChildren)throw new Error("Another generation operation is already in progress. Please abort it first or wait for completion.");if(o.children.length===0&&o.getState()==="Empty")if(t){this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:`Generating content for "${o.title}" first...`,current:0,total:1});try{yield this.generateNodeContent(e,o.generationChildrenCount,!1);const c=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!c||!c.content||c.content.trim()==="")throw this.deps.eventEmitter.emit("error",`Failed to generate content for "${o.title}". Cannot proceed with creating children.`),this.isGeneratingAllChildren&&(this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext()),new Error(`Failed to generate content for "${o.title}". Cannot proceed with creating children.`);o=c}catch(c){if(c.message==="Generation aborted by user")return;throw this.deps.eventEmitter.emit("error",`Failed to generate content for "${o.title}": ${c.message}`),this.isGeneratingAllChildren&&(this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext()),new Error(`Failed to generate content for "${o.title}": ${c.message}`)}}else throw this.deps.eventEmitter.emit("error",`Cannot generate children for node "${o.title}": No content found. Please write or generate content for this node first, or enable "Include content" to auto-generate it.`),this.isGeneratingAllChildren&&(this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext()),new Error(`Cannot generate children for node "${o.title}": No content found. Please write or generate content for this node first, or enable "Include content" to auto-generate it.`);if(!this.isGeneratingAllChildren){this.abortRequested=!1,this.isGeneratingAllChildren=!0;const c=u=>{const g=[];for(const f of u.children)g.push(f),r&&g.push(...c(f));return g},d=c(o);this.deps.generationController.setupBulkGeneration(d.map(u=>u.id))}if(o.children.length===0){this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"Reading outline and generating child titles...",current:0,total:1});const c=this.extractSettingsOverrideFromNode(o),d=c?this.deps.settingsManager.getLastUsedProfileName():null;c&&(this.deps.settingsManager.getProfile(c)?(console.log(`🔧 Using settings override "${c}" for creating children titles of "${o.title}"`),yield this.deps.settingsManager.setLastUsedProfile(c)):console.warn(`⚠️ Settings override "${c}" not found for creating children titles of "${o.title}". Using current settings.`));try{const u=this.deps.settingsManager.getPrompts(),g=this.deps.contextService.compileNodeContext(e,this.deps.rootNode),f=o.childLevelName||"item",w=u.create_children_from_outline_user.replace(/{{outline_content}}/g,o.content).replace(/{{child_level_name}}/g,f).replace(/{{context}}/g,g).replace(/{{count}}/g,String(o.generationChildrenCount)),y=yield this.deps.openRouterClient.chat("creator",w),S=this.parseChildrenFromJSON(y);if(S.length===0){const b=`The AI did not return a valid list of titles from the outline.

AI Response:
"${y}"`;throw this.deps.eventEmitter.emit("error",b),this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext(),new Error(b)}S.forEach(b=>{const P=this.deps.treeService.addNode(b.title,e,this.deps.rootNode);b.description&&b.description.trim()&&(P.content=`Draft: ${b.description}`)}),yield this.deps.saveToStorage()}catch(u){throw console.error("Failed to create children from outline via LLM:",u),this.deps.eventEmitter.emit("error","The AI failed to process the outline. Please try again."),this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext(),new Error(`The AI failed to process the outline: ${u.message||u}`)}finally{c&&d&&(console.log(`🔄 Restoring original settings profile "${d}" after creating children titles`),yield this.deps.settingsManager.setLastUsedProfile(d))}}else this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"Child nodes already exist, skipping creation",current:1,total:1});if(t){const d=o.children.filter(g=>g.getState()!=="Final"),u=d.length;if(u>0)for(let g=0;g<u;g++){const f=d[g];if(this.isAbortRequested())break;this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:`Generating content for: ${f.title}`,current:g+1,total:u});try{const w=(s=(i=this.deps).getGenerationCoordinator)==null?void 0:s.call(i);let y=null;if(w&&(y=w.startOperation("child-content",f.id,[f.id]),!y)){console.warn(`Skipping child "${f.title}" - conflicts with existing operation`);continue}try{yield this.generateNodeContent(f.id,f.generationChildrenCount,!0);const S=this.deps.treeService.findNodeById(f.id,this.deps.rootNode);S&&S.content&&S.content.trim()!==""||console.error(`✗ Content generation failed for "${f.title}": No content found after generation`),w&&y&&w.completeOperation(y,!0)}catch(S){throw w&&y&&w.completeOperation(y,!1,S),S}if(this.isAbortRequested())break}catch(w){if(w.message==="Generation aborted by user"||this.isAbortRequested())break;console.error(`Failed to generate content for child "${f.title}" (${f.id}):`,w),this.deps.eventEmitter.emit("error",`Failed to generate content for "${f.title}": ${w.message}`)}}else this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"All children already have content",current:1,total:1})}if(r){const c=o.children,d=o.template.length-1,u=c.filter(g=>g.level<d);for(let g=0;g<u.length;g++){const f=u[g];if(this.isAbortRequested())break;this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:`Recursively generating children for: ${f.title}`,current:g+1,total:u.length});try{yield this.generateAllChildrenContent(f.id,t,r)}catch(w){if(w.message==="Generation aborted by user"||this.isAbortRequested())break;console.error(`Failed to recursively generate children for ${f.title}:`,w)}}}if(this.isGeneratingAllChildren&&((l=this.deps.generationController.getCurrentGenerationInfo())==null?void 0:l.type)==="bulk")try{this.isAbortRequested()?this.deps.eventEmitter.emit("nodeGenerationAborted",{nodeId:e,node:o}):(this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1}),this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!0,node:o}),setTimeout(()=>{this.deps.eventEmitter.emit("project-loaded")},100))}finally{this.isGeneratingAllChildren=!1,this.deps.generationController.clearGenerationContext()}this.isGeneratingAllChildren&&!this.deps.generationController.getCurrentGenerationInfo()&&(console.warn("State inconsistency detected - cleaning up: isGeneratingAllChildren=true but no generation context exists."),console.warn("Debug info:",{nodeId:e,isGeneratingAllChildren:this.isGeneratingAllChildren,generationInfo:this.deps.generationController.getCurrentGenerationInfo(),abortRequested:this.isAbortRequested()}),this.isGeneratingAllChildren=!1,this.abortRequested=!1)})}summarizeNodeContent(e,t=!1){return h(this,null,function*(){var i;const r=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!r){this.deps.eventEmitter.emit("error",`Could not find node with ID ${e} to summarize.`);return}if(!r.content||r.content.trim()===""){this.deps.eventEmitter.emit("error","There is no content to summarize. Please generate or write content first.");return}if(!t&&this.deps.generationController.canAbortGeneration(this.deps.rootNode))throw new Error("Another generation operation is already in progress. Please abort it first or wait for completion.");t||(this.abortRequested=!1,this.deps.generationController.setupSingleNodeGeneration(e)),t||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"Summarizing content...",current:0,total:1});const n=this.deps.settingsManager.getPrompts().summarize_system.replace(/{{content}}/g,r.content);try{if(r.isGenerating=!0,t||this.deps.eventEmitter.emit("nodeGenerationStarted",{nodeId:e,node:r}),this.isAbortRequested())throw new Error("Generation aborted by user");const s=(i=this.deps.generationController.getCurrentGenerationInfo())!=null&&i.canAbort?new AbortController().signal:void 0,l=yield this.deps.openRouterClient.chat("editor",n,s);if(this.isAbortRequested())throw new Error("Generation aborted by user");r.context=l,this.deps.eventEmitter.emit("nodeSummaryGenerated",{nodeId:e,summary:l}),yield this.deps.saveToStorage(),this.cleanupGenerationState(e,r,t),t||this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!0,node:r}),t||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1})}catch(s){console.error(`Failed to summarize node ${e}:`,s),this.cleanupGenerationState(e,r,t),s.message==="Request was aborted"||s.message==="Generation aborted by user"||this.isAbortRequested()?t||this.deps.eventEmitter.emit("nodeGenerationAborted",{nodeId:e,node:r}):(this.deps.eventEmitter.emit("error","An error occurred while summarizing. Please check the console for details."),t||this.deps.eventEmitter.emit("nodeGenerationComplete",{nodeId:e,success:!1,error:s,node:r})),t||this.deps.eventEmitter.emit("high-level-progress",{nodeId:e,message:"",current:0,total:1})}finally{}})}abortCurrentGeneration(){this.abortRequested=!0,this.deps.generationController.abortCurrentGeneration(this.deps.rootNode)}canAbortGeneration(){return this.deps.generationController.canAbortGeneration(this.deps.rootNode)}getCurrentGenerationInfo(){return this.deps.generationController.getCurrentGenerationInfo()}extractSettingsOverride(e){if(!e.parentId)return null;const t=this.deps.treeService.findNodeById(e.parentId,this.deps.rootNode);if(!t||!t.context)return null;const r=t.context.split(`
`);for(const o of r){const i=o.trim().match(/^settingsoverride:\s*(.+)$/i);if(i)return i[1].trim()}return null}extractSettingsOverrideFromNode(e){if(!e.context)return null;const t=e.context.split(`
`);for(const r of t){const n=r.trim().match(/^settingsoverride:\s*(.+)$/i);if(n)return n[1].trim()}return null}filterCriteriaForNodeType(e,t){return e.filter(r=>r.outline===void 0&&r.leaf===void 0?!0:t?r.leaf===!0:r.outline===!0)}synthesizeNodeContext(e,t){return h(this,null,function*(){if(this.isAbortRequested())return;const r=this.deps.treeService.findNodeById(e,this.deps.rootNode);if(!r){console.warn(`Node ${e} not found for context synthesis`);return}try{const o=yield this.deps.contextService.synthesizeContext(e,this.deps.rootNode);if(o&&o.trim()!==""){const n=this.cleanSynthesizedContext(o);n&&n.trim()!==""&&(r.context=n)}}catch(o){console.error(`Context synthesis failed for node "${r.title}" (${e}):`,o),t||this.deps.eventEmitter.emit("error",`Warning: Context synthesis failed for "${r.title}" but content generation completed successfully.`)}})}cleanSynthesizedContext(e){const t=e.split(`
`);let r=0;for(let o=0;o<t.length;o++){const n=t[o].trim();if(n===""){r=o+1;continue}const i=n.toLowerCase();if(i.includes("context")&&i.includes(":")){r=o+1;continue}break}return t.slice(r).join(`
`).trim()}parseChildrenFromJSON(e){try{const t=e.trim();let r=t;const o=t.indexOf("["),n=t.lastIndexOf("]");o!==-1&&n!==-1&&n>o&&(r=t.substring(o,n+1));const i=JSON.parse(r);return Array.isArray(i)?i.map((s,l)=>{if(typeof s!="object"||s===null)return console.warn(`Item ${l} is not an object, skipping`),null;const c=typeof s.title=="string"?s.title.trim():"",d=typeof s.description=="string"?s.description.trim():"";return c?{title:c,description:d}:(console.warn(`Item ${l} has no valid title, skipping`),null)}).filter(s=>s!==null):(console.warn("Response is not a JSON array, falling back to bulleted list parsing. Response:",e),this.parseEnhancedBulletedList(e))}catch(t){return console.warn("Failed to parse as JSON, falling back to bulleted list parsing. Error:",t,"Response:",e),this.parseEnhancedBulletedList(e)}}parseEnhancedBulletedList(e){return e.split(`
`).map(t=>t.trim()).filter(t=>t.startsWith("*")||t.startsWith("-")).map(t=>{const r=t.substring(1).trim(),o=r.match(/^Title:\s*([^,]+),\s*Content:\s*(.*)$/i);return o?{title:o[1].trim(),description:o[2].trim()}:{title:r,description:""}}).filter(t=>t.title.length>0)}}class Wr{constructor(e){p(this,"operations",new Map);p(this,"operationCounter",1)}startOperation(e,t,r=[t]){if(this.hasConflictingOperation(t,r))return null;const o=`gen-${this.operationCounter++}`,n={id:o,type:e,primaryNodeId:t,involvedNodeIds:new Set(r),startTime:Date.now(),isComplete:!1};return this.operations.set(o,n),this.updateUIForOperationStart(n),o}completeOperation(e,t,r){const o=this.operations.get(e);o&&(o.isComplete=!0,this.operations.delete(e),this.updateUIForOperationComplete(o,t,r))}hasActiveOperations(){return this.operations.size>0}isNodeGenerating(e){for(const t of this.operations.values())if(t.involvedNodeIds.has(e))return!0;return!1}getActiveOperations(){return Array.from(this.operations.values())}abortAllOperations(){const e=Array.from(this.operations.keys());for(const t of e)this.completeOperation(t,!1,new Error("Operation aborted"))}hasConflictingOperation(e,t){for(const r of this.operations.values()){if(r.involvedNodeIds.has(e))return!0;for(const o of t)if(r.involvedNodeIds.has(o))return!0}return!1}updateUIForOperationStart(e){const t=document.getElementById("node-generate-btn"),r=document.getElementById("node-generate-all-btn");t&&(t.disabled=!0,e.type==="single-content"&&(t.innerHTML='<span class="spinner" style="width: 12px; height: 12px; border-width: 2px; margin-right: 8px;"></span>Generating...')),r&&(r.disabled=!0,e.type==="bulk-children"&&(r.innerHTML='<span class="spinner" style="width: 12px; height: 12px; border-width: 2px; margin-right: 8px;"></span>Generating Children...')),e.type==="single-content"?(this.showGenerationOverlay(),this.updateProgressUI({operations:{message:"Preparing content generation...",current:0,total:1}})):e.type==="bulk-children"?this.updateProgressUI({operations:{message:"Preparing to generate children...",current:0,total:1}}):e.type==="child-content"&&this.updateProgressUI({operations:{message:"Generating content for child node...",current:0,total:1},iterations:{message:"Iteration: 0 / 1",current:0,total:1},stages:{message:"Stage: Initializing...",current:0,total:3},detail:"Preparing to generate content..."}),this.showGlobalAbortButton()}updateUIForOperationComplete(e,t,r){if(!this.hasActiveOperations()){const o=document.getElementById("node-generate-btn"),n=document.getElementById("node-generate-all-btn");o&&(o.disabled=!1,o.innerHTML="Generate Content"),n&&(n.disabled=!1,n.innerHTML="Generate All Children"),this.updateProgressUI(),this.hideGenerationOverlay(),this.hideGlobalAbortButton(),!t&&r&&(console.error("Generation operation failed:",r),console.error("Full error details:",r),alert(`Generation failed: ${r.message||r}`))}}updateProgressUI(e){typeof window.updateProgressUI=="function"&&window.updateProgressUI(e)}showGenerationOverlay(){typeof window.showGenerationOverlay=="function"&&window.showGenerationOverlay()}hideGenerationOverlay(){typeof window.hideGenerationOverlay=="function"&&window.hideGenerationOverlay()}showGlobalAbortButton(){typeof window.showGlobalAbortButton=="function"&&window.showGlobalAbortButton()}hideGlobalAbortButton(){typeof window.hideGlobalAbortButton=="function"&&window.hideGlobalAbortButton()}}class Kr{constructor(e,t){this.openRouterClient=e,this.settingsManager=t}extractContext(e,t,r=0){return h(this,null,function*(){const o=this.collectContentAtDepth(e,r);if(!o.trim())throw new Error("No content found to extract from at the specified depth.");const n=this.createExtractionPrompt(t,o,e.title);return(yield this.openRouterClient.chat("editor",n)).trim()})}collectContentAtDepth(e,t,r=0){const o=[];if(e.content&&e.content.trim()){const n=e.template[e.level]||`Level ${e.level}`;o.push(`${n}: "${e.title}"
---
${e.content}
---
`)}if(r<t&&e.children.length>0)for(const n of e.children){const i=this.collectContentAtDepth(n,t,r+1);i.trim()&&o.push(i)}return o.join(`
`)}createExtractionPrompt(e,t,r){return this.settingsManager.getPrompts().context_extraction_user.replace(/\{\{extraction_request\}\}/g,e).replace(/\{\{node_title\}\}/g,r).replace(/\{\{content\}\}/g,t)}getContentPreview(e,t=0){const o=this.collectNodesAtDepth(e,t).filter(s=>s.content&&s.content.trim()),n=o.reduce((s,l)=>{var c;return s+(((c=l.content)==null?void 0:c.length)||0)},0);let i=`Analysis would include:
`;return i+=`- ${o.length} nodes with content
`,i+=`- Total content length: ${n} characters
`,i+=`- Depth: ${t} levels

`,o.length>0?(i+=`Nodes to be analyzed:
`,o.forEach(s=>{var c;const l=s.template[s.level]||`Level ${s.level}`;i+=`- ${l}: "${s.title}" (${((c=s.content)==null?void 0:c.length)||0} chars)
`})):i+=`No nodes with content found at depth ${t}.`,{nodeCount:o.length,contentLength:n,summary:i}}collectNodesAtDepth(e,t,r=0){const o=[e];if(r<t&&e.children.length>0)for(const n of e.children)o.push(...this.collectNodesAtDepth(n,t,r+1));return o}validateExtractionParameters(e,t,r){const o=[],n=[];(!t||t.trim().length===0)&&o.push("Extraction prompt cannot be empty"),r<0&&o.push("Depth cannot be negative"),r>10&&o.push("Depth cannot exceed 10 levels (performance limitation)");const i=this.getContentPreview(e,r);return i.nodeCount===0&&o.push("No content found to extract from at the specified depth"),i.contentLength>5e4&&n.push(`Large content size (${i.contentLength.toLocaleString()} characters). This may exceed some model context limits. Consider reducing depth if you encounter errors.`),i.contentLength>2e5&&n.push("Very large content size may cause performance issues or timeouts."),{errors:o,warnings:n}}createNodeTreeData(e,t,r){const o=this.collectTreeDataAtDepth(e,r,0,"",!0);let n=`Node Hierarchy (${r+1} levels deep):

`;return n+=o,n}collectTreeDataAtDepth(e,t,r=0,o="",n=!0){const i=[],s=e.template[e.level]||`Level ${e.level}`;let l=`${o}${s}: "${e.title}"`;if(n&&r===0?(e.context&&e.context.trim()&&(l+=`
${o}  Context: ${e.context}`),e.content&&e.content.trim()?l+=`
${o}  Content: ${e.content}`:(!e.context||!e.context.trim())&&(l+=`
${o}  [No content or context]`)):e.content&&e.content.trim()?l+=`
${o}  Content: ${e.content}`:l+=`
${o}  [No content]`,i.push(l),r<t&&e.children.length>0)for(const c of e.children){const d=this.collectTreeDataAtDepth(c,t,r+1,o+"  ",!1);i.push(d)}return i.join(`
`)}getChatTreePreview(e,t){const r=this.collectNodesAtDepth(e,t),o=r.filter(i=>i.content&&i.content.trim());let n=`Tree Structure Preview:

`;return n+=`Starting from: "${e.title}"
`,n+=`Depth: ${t} levels
`,n+=`Total nodes: ${r.length}
`,n+=`Nodes with content: ${o.length}

`,n+=this.createSimpleTreePreview(e,t),{nodeCount:r.length,summary:n}}getChatContentPreview(e,t){const r=this.collectNodesAtDepth(e,t);let o=0;e.context&&e.context.trim()&&(o+=e.context.length),e.content&&e.content.trim()&&(o+=e.content.length);const i=r.slice(1).filter(d=>d.content&&d.content.trim());o+=i.reduce((d,u)=>{var g;return d+(((g=u.content)==null?void 0:g.length)||0)},0);const s=e.context&&e.context.trim()||e.content&&e.content.trim(),l=(s?1:0)+i.length;let c=`Chat Context Analysis:

`;return c+=`Starting from: "${e.title}"
`,c+=`Depth: ${t} levels
`,c+=`Total nodes: ${r.length}
`,c+=`Nodes with content/context: ${l}
`,c+=`Total content length: ${o.toLocaleString()} characters

`,s&&(c+=`Root node "${e.title}":
`,e.context&&e.context.trim()&&(c+=`- Context: ${e.context.length.toLocaleString()} chars
`),e.content&&e.content.trim()&&(c+=`- Content: ${e.content.length.toLocaleString()} chars
`),c+=`
`),i.length>0&&(c+=`Child nodes content:
`,i.forEach(d=>{var g,f;const u=d.template[d.level]||`Level ${d.level}`;c+=`- ${u}: "${d.title}" (${((f=(g=d.content)==null?void 0:g.length)==null?void 0:f.toLocaleString())||0} chars)
`})),{nodeCount:l,contentLength:o,summary:c}}validateChatContextParameters(e,t){const r=[],o=[];t<0&&r.push("Depth cannot be negative"),t>10&&r.push("Depth cannot exceed 10 levels (performance limitation)");const n=this.getChatContentPreview(e,t);return n.nodeCount===0&&o.push("No content or context found at the specified depth. The chat will have minimal context."),n.contentLength>5e4&&o.push(`Large content size (${n.contentLength.toLocaleString()} characters). This may exceed some model context limits and could result in higher costs. Consider reducing depth if you encounter errors.`),n.contentLength>1e5&&o.push("Very large content size may cause performance issues, longer response times, or significantly higher costs."),n.contentLength>2e5&&o.push("Extremely large content size. Many models have context limits around 200K tokens (~800K characters). This request may fail or be very expensive."),{errors:r,warnings:o}}createSimpleTreePreview(e,t,r=0,o=""){const n=[],i=e.content&&e.content.trim(),s=e.template[e.level]||`Level ${e.level}`;if(n.push(`${o}${s}: "${e.title}" ${i?"✓":"○"}`),r<t&&e.children.length>0)for(const l of e.children){const c=this.createSimpleTreePreview(l,t,r+1,o+"  ");n.push(c)}return n.join(`
`)}}const j=class j extends Ft{constructor(t,r,o,n,i){super();p(this,"projectTitle");p(this,"template");p(this,"rootNode");p(this,"loopOrchestrator");p(this,"settingsManager");p(this,"openRouterClient");p(this,"selectedNodeId",null);p(this,"_listenersSetup",!1);p(this,"treeService");p(this,"contextService");p(this,"promptService");p(this,"generationController");p(this,"generationService");p(this,"contextExtractionService");p(this,"generationCoordinator");if(this.projectTitle=t,this.template=r,this.loopOrchestrator=o,this.settingsManager=n,this.openRouterClient=i,!this.template.hierarchyLevels||this.template.hierarchyLevels.length===0)throw new Error(`Invalid template: "${this.template.name}" has no hierarchy levels defined.`);this.rootNode=new pe(0,this.projectTitle,null,this.template.hierarchyLevels),this.treeService=new zt,this.contextService=new Ht(this.treeService,this.openRouterClient,this.settingsManager),this.promptService=new qr(this.settingsManager),this.generationController=new Vr(this.loopOrchestrator,this.treeService),this.contextExtractionService=new Kr(this.openRouterClient,this.settingsManager),this.generationCoordinator=new Wr(this),this.generationService=new dt({treeService:this.treeService,contextService:this.contextService,promptService:this.promptService,generationController:this.generationController,loopOrchestrator:this.loopOrchestrator,settingsManager:this.settingsManager,openRouterClient:this.openRouterClient,eventEmitter:this,saveToStorage:()=>this.saveToStorage(),rootNode:this.rootNode,getGenerationCoordinator:()=>this.generationCoordinator});const s=this.settingsManager.getLastUsedProfileName(),l=s?this.settingsManager.getProfile(s):null;if(!l||!l.criteria||l.criteria.length===0){const d=this.settingsManager.getProfileNames().find(u=>{const g=this.settingsManager.getProfile(u);return g&&g.criteria&&g.criteria.length>0});d&&this.settingsManager.setLastUsedProfile(d)}}getGenerationService(){return this.generationService}getTreeService(){return this.treeService}getContextService(){return this.contextService}getPromptService(){return this.promptService}getGenerationController(){return this.generationController}getContextExtractionService(){return this.contextExtractionService}getGenerationCoordinator(){return this.generationCoordinator}getSettingsManager(){return this.settingsManager}static getStorageService(){return h(this,null,function*(){return j.storageService||(j.storageService=$.getInstance()),j.storageService})}static getIndexedDBService(){return h(this,null,function*(){if((yield j.getStorageService()).isIndexedDB()){const r=yield $.getInstance();if(r.isIndexedDB())return r.indexedDBService}return null})}findNodeById(t,r=this.rootNode){return this.treeService.findNodeById(t,r)}addNode(t,r=null){return this.treeService.addNode(t,r,this.rootNode)}removeNode(t){return this.treeService.removeNode(t,this.rootNode)}getNodePath(t){return this.treeService.getNodePath(t,this.rootNode)}getRawGenerationPrompt(t){const r=this.settingsManager.getPrompts();return t.parentId?t.isLeaf?r.content_generation_user:r.branch_content_generation_user:r.expand_text_user}save(){const t={projectTitle:this.projectTitle,template:{name:this.template.name,hierarchyLevels:this.template.hierarchyLevels,scaffoldingDocuments:this.template.scaffoldingDocuments},rootNode:this.rootNode,selectedNodeId:this.selectedNodeId};return JSON.stringify(t,null,2)}saveToStorage(){return h(this,null,function*(){try{yield this.saveAllProjectsToStorage()}catch(t){console.error("Failed to save project to storage:",t),this.emit("error","Failed to save project to storage. Some changes may not be persisted.")}})}clearAllProjectsFromStorage(){return h(this,null,function*(){try{const t=yield j.getStorageService(),r=yield j.getIndexedDBService();if(r)yield r.clear("projects");else throw new Error("IndexedDB service is not available but was expected");yield t.delete(j.ACTIVE_PROJECT_STORAGE_KEY)}catch(t){throw console.error("Failed to clear projects from storage:",t),t}})}saveAllProjectsToStorage(){return h(this,null,function*(){const t=ve(),r=se();try{const o=yield j.getStorageService(),n=yield j.getIndexedDBService();if(n)for(const i of t){const s={id:i.rootNode.id,title:i.projectTitle,templateName:i.template.name,createdAt:new Date,lastModified:new Date,data:i.save()};yield n.set("projects",i.rootNode.id,s)}else throw new Error("IndexedDB service is not available but was expected");r&&(yield o.set(j.ACTIVE_PROJECT_STORAGE_KEY,r.rootNode.id))}catch(o){throw console.error("Failed to save projects to storage:",o),o}})}static loadAllProjectsFromStorage(t,r,o){return h(this,null,function*(){try{const n=yield j.getStorageService(),i=yield j.getIndexedDBService();if(i){const s=yield i.getAll("projects"),l=yield n.get(j.ACTIVE_PROJECT_STORAGE_KEY);if(s&&Object.keys(s).length>0)return{projects:Object.values(s).map(d=>j.load(d.data,t,r,o)),activeProjectId:l||null}}else throw new Error("IndexedDB service is not available but was expected");return{projects:[],activeProjectId:null}}catch(n){return console.error("Failed to load projects from storage:",n),{projects:[],activeProjectId:null}}})}static load(t,r,o,n){const i=JSON.parse(t),s=new C(i.template.name,i.template.hierarchyLevels,i.template.scaffoldingDocuments),l=new j(i.projectTitle,s,r,o,n);return l.rootNode=this.rehydrateNode(i.rootNode),l.generationService=new dt({treeService:l.treeService,contextService:l.contextService,promptService:l.promptService,generationController:l.generationController,loopOrchestrator:l.loopOrchestrator,settingsManager:l.settingsManager,openRouterClient:l.openRouterClient,eventEmitter:l,saveToStorage:()=>l.saveToStorage(),rootNode:l.rootNode}),i.selectedNodeId&&(l.selectedNodeId=i.selectedNodeId),l}static rehydrateNode(t){const r=new pe(t.level,t.title,t.parentId,t.template);return r._content=t.content||"",Object.assign(r,{id:t.id,context:t.context||t.summary||"",generationPrompt:t.generationPrompt||null,generationHistory:t.generationHistory||[],generationSessions:t.generationSessions||[],children:[]}),t.children&&t.children.length>0&&(r.children=t.children.map(o=>this.rehydrateNode(o))),r}selectNode(t){this.selectedNodeId=t;const r=t?this.findNodeById(t):null;this.emit("node-selected",r)}isAnyNodeGenerating(){return this.generationCoordinator.hasActiveOperations()}};p(j,"ACTIVE_PROJECT_STORAGE_KEY","expert_app_active_project"),p(j,"storageService",null);let N=j;class Ut extends Ft{constructor(t,r){super();p(this,"client");p(this,"prompts");p(this,"stopRequested",!1);p(this,"abortController",null);p(this,"currentIteration",0);p(this,"isRunning",!1);this.client=t,this.prompts=r||T({},ce)}requestStop(){this.stopRequested=!0,this.abortController&&this.abortController.abort(),this.client.abort()}isLoopRunning(){return this.isRunning}getCurrentIteration(){return this.currentIteration}rateContent(t,r,o){return h(this,null,function*(){if(!r||r.trim()==="")throw new Error("No content provided for rating");if(!o||o.length===0)throw new Error("No criteria provided for rating");this.abortController=new AbortController;const n=3;let i=null,s="";for(let l=0;l<n;l++){if(this.stopRequested)throw new Error("Rating aborted by user");const c=this.createAllCriteriaRaterPrompt(t,r,o);try{if(s=yield this.client.chat("rater",c,this.abortController.signal),i=this.parseAllRatings(s,o),i)break;console.warn(`Rater response parsing failed on attempt ${l+1}. Retrying...`)}catch(d){if(d.message==="Request was aborted"||this.stopRequested)throw new Error("Rating aborted by user");console.warn(`Rater API call failed on attempt ${l+1}. Retrying...`,d)}}if(!i)throw new Error(`The AI Rater failed to provide a valid response after ${n} retries.

Last AI Response:
"${s}"`);return this.abortController=null,i})}runLoop(t){return h(this,null,function*(){this.stopRequested=!1,this.abortController=new AbortController,this.isRunning=!0,this.currentIteration=0,this.emit("started",t);const{prompt:r,criteria:o,maxIterations:n}=t,i=[];let s="",l=!1,c=!1;const d=3;try{let u;if(t.initialContent){s=t.initialContent,u=t.prompt;const g={prompt:u,response:s};i.push({iteration:0,type:"creator",payload:g}),this.emit("progress",{type:"creator",payload:g,iteration:0,maxIterations:n,step:1,totalStepsInIteration:d})}else{if(u=this.prompts.content_generation_initial.replace(/{{prompt}}/g,t.prompt).replace(/{{criteria}}/g,this.formatCriteriaAsJson(t.criteria)),this.stopRequested)throw c=!0,new Error("Generation aborted by user");this.emit("progress",{type:"creator",payload:{prompt:u,response:"Creator is working..."},iteration:0,maxIterations:n,step:1,totalStepsInIteration:d});try{s=yield this.client.chat("creator",u,this.abortController.signal)}catch(f){throw f.message==="Request was aborted"||this.stopRequested?(c=!0,new Error("Generation aborted by user")):new Error("The AI Creator failed to respond. Please check your API key and network connection.")}const g={prompt:u,response:s};i.push({iteration:0,type:"creator",payload:g}),this.emit("progress",{type:"creator",payload:g,iteration:0,maxIterations:n,step:1,totalStepsInIteration:d})}for(let g=1;g<=n;g++){if(this.currentIteration=g,this.stopRequested){c=!0;break}this.emit("progress",{type:"rater",payload:{criterion:"Starting evaluation...",rating:{criterion:"",score:0,justification:"",goal:0}},iteration:g,maxIterations:n,step:2,totalStepsInIteration:d});let f=null,w="";const y=3;for(let P=0;P<y;P++){if(this.stopRequested){c=!0;break}const I=this.createAllCriteriaRaterPrompt(r,s,o);try{if(w=yield this.client.chat("rater",I,this.abortController.signal),f=this.parseAllRatings(w,o),f)break;console.warn(`Rater response parsing failed on attempt ${P+1}. Retrying...`)}catch(k){if(k.message==="Request was aborted"||this.stopRequested){c=!0;break}console.warn(`Rater API call failed on attempt ${P+1}. Retrying...`,k)}}if(c)break;if(!f)throw new Error(`The AI Rater failed to provide a valid response after ${y} retries.

Last AI Response:
"${w}"`);let S=!0;const b=[];for(const P of f){if(this.stopRequested){c=!0;break}const I={criterion:P.criterion,rating:P};this.emit("progress",{type:"rater",payload:I,iteration:g,maxIterations:n,step:2,totalStepsInIteration:d});const k=o.find(L=>L.name===P.criterion);k&&P.score<k.goal?(S=!1,b.push(`${P.criterion}: ${P.score}/${k.goal} (FAILED)`)):k&&b.push(`${P.criterion}: ${P.score}/${k.goal} (PASSED)`)}if(c)break;if(!S&&g<n){const P=f.filter(A=>A.score<A.goal),I=this.createEditorPrompt(s,P);let k;try{k=yield this.client.chat("editor",I,this.abortController.signal)}catch(A){if(A.message==="Request was aborted"||this.stopRequested){c=!0;break}throw new Error("The AI Editor failed to provide feedback.")}const L={prompt:I,advice:k};if(i.push({iteration:g,type:"editor",payload:L}),this.emit("progress",{type:"editor",payload:L,iteration:g,maxIterations:n,step:3,totalStepsInIteration:d}),this.stopRequested){c=!0;break}const M=this.createCreatorPrompt(r,o,i);this.emit("progress",{type:"creator",payload:{prompt:M,response:"Creator is working on revision..."},iteration:g,maxIterations:n,step:1,totalStepsInIteration:d});try{s=yield this.client.chat("creator",M,this.abortController.signal)}catch(A){if(A.message==="Request was aborted"||this.stopRequested){c=!0;break}throw new Error("The AI Creator failed to respond during revision. Please check your API key and network connection.")}const G={prompt:M,response:s};i.push({iteration:g,type:"creator",payload:G}),this.emit("progress",{type:"creator",payload:G,iteration:g,maxIterations:n,step:1,totalStepsInIteration:d})}else{l=S;break}}}catch(u){if(u.message==="Generation aborted by user"||this.stopRequested)c=!0,this.emit("aborted","Generation was aborted by user");else throw u}finally{this.isRunning=!1,this.abortController=null,this.currentIteration=0}return{finalResponse:s,history:i,iterations:i.filter(u=>u.type==="creator").length,success:l,aborted:c}})}formatCriteriaAsJson(t){const r=t.map(o=>{const n=o.name.indexOf(".")>0?o.name.substring(0,o.name.indexOf(".")):o.name;return{name:n,description:o.description||n}});return JSON.stringify(r,null,2)}createCreatorPrompt(t,r,o){var d,u;const n=this.formatCriteriaAsJson(r);if(!o)return this.prompts.content_generation_initial.replace(/{{prompt}}/g,t).replace(/{{criteria}}/g,n);const i=o.filter(g=>g.type==="editor").pop(),s=o.filter(g=>g.type==="creator").pop(),l=((d=i==null?void 0:i.payload)==null?void 0:d.advice)||"No advice was given.",c=(u=s==null?void 0:s.payload)==null?void 0:u.response;return this.prompts.content_generation_iterative.replace(/{{prompt}}/g,t).replace(/{{lastResponse}}/g,c||"").replace(/{{editorAdvice}}/g,l).replace(/{{criteria}}/g,n)}createAllCriteriaRaterPrompt(t,r,o){const n=this.formatCriteriaAsJson(o);return this.prompts.rater.replace(/{{originalPrompt}}/g,t).replace(/{{response}}/g,r).replace(/{{criteria}}/g,n)}parseAllRatings(t,r){try{let o=null;const n=t.match(new RegExp("```json\\s*(\\[[\\s\\S]*?\\])\\s*```","s"));if(n&&n[1])o=n[1];else{const i=t.indexOf("["),s=t.lastIndexOf("]");i!==-1&&s!==-1&&s>i&&(o=t.substring(i,s+1))}if(o){const i=JSON.parse(o);if(Array.isArray(i)){const s=[],l=new Map(r.map(c=>[c.name,c]));for(const c of i){const d=l.get(c.criterion);if(d&&typeof c.score=="number"&&typeof c.justification=="string")s.push({criterion:c.criterion,score:c.score,justification:c.justification,goal:d.goal});else return console.warn("Parsed rating item is invalid or does not match an original criterion.",{item:c}),null}return s.length===r.length?s:(console.warn("The number of returned ratings does not match the number of original criteria."),null)}}return console.warn("Could not parse rating response as a valid JSON array.",{response:t}),null}catch(o){return console.warn("Could not parse rating response as JSON, exception thrown.",{response:t,error:o}),null}}createEditorPrompt(t,r){return this.prompts.editor.replace(/{{response}}/g,t).replace(/{{ratings}}/g,JSON.stringify(r,null,2))}}const ht="expert_app_project_templates",ke={"Standard Novel":new C("Standard Novel",["Book","Part 3","Chapter 8","Scene"],["Main Outline","Character Profiles","Setting Guide","Timeline"]),"Hero's Journey Novel":new C("Hero's Journey Novel",["Book","Journey Stage 17","Chapter 5","Scene"],["Hero's Journey Outline","Character Archetypes","World Building","Theme Notes"]),"Save the Cat Novel":new C("Save the Cat Novel",["Book","Beat Sheet 15","Chapter 6","Scene"],["15-Beat Structure","Character Arcs","Genre Requirements","Logline"]),"Three-Act Novel":new C("Three-Act Novel",["Book","Act 3","Chapter 10","Scene"],["Plot Structure","Character Development","Setting Details","Themes"]),"Romance Novel":new C("Romance Novel",["Book","Relationship Arc 8","Chapter 12","Scene"],["Romance Plot","Character Chemistry","Emotional Beats","Trope Guide"]),"Mystery Novel":new C("Mystery Novel",["Book","Investigation Phase 6","Chapter 15","Scene"],["Plot Outline","Clue Tracker","Character Suspects","Red Herrings"]),"Fantasy Epic":new C("Fantasy Epic",["Series","Book 5","Part 4","Chapter 12"],["World Bible","Magic System","Character Lineages","Political Map","Timeline"]),"Sci-Fi Novel":new C("Sci-Fi Novel",["Book","Part 3","Chapter 10","Scene"],["Technology Guide","World Building","Character Profiles","Scientific Concepts"]),"Short Story":new C("Short Story",["Story","Act 3","Scene"],["Character Sketch","Theme Notes","Setting Details"]),"Flash Fiction":new C("Flash Fiction",["Story","Beat 5","Moment"],["Concept","Character Note","Twist Ending"]),Novella:new C("Novella",["Novella","Part 3","Chapter 5","Scene"],["Plot Outline","Character Development","Theme Exploration"]),"Short Story Collection":new C("Short Story Collection",["Collection","Theme 5","Story 8","Scene"],["Collection Theme","Story Summaries","Author Bio","Publication Notes"]),"Memoir Chapter":new C("Memoir Chapter",["Memoir","Life Phase 6","Chapter 8","Memory"],["Timeline","Photo References","Reflection Notes","Family Tree"]),"Personal Essay":new C("Personal Essay",["Essay","Section 4","Point"],["Thesis Statement","Personal Examples","Research Notes"]),"Feature Screenplay":new C("Feature Screenplay",["Screenplay","Act 3","Sequence 8","Scene"],["Treatment","Character Breakdowns","Location List","Beat Sheet"]),"TV Series":new C("TV Series",["Series","Season 5","Episode 22","Act 4"],["Series Bible","Character Arcs","Season Outlines","Episode Templates"]),"Short Film":new C("Short Film",["Film","Act 3","Scene"],["Concept","Character Notes","Visual Style","Production Notes"]),"Technical Manual":new C("Technical Manual",["Manual","Section 8","Topic 5","Procedure"],["Table of Contents","Glossary","Index","Troubleshooting Guide"]),"Business Presentation":new C("Business Presentation",["Presentation","Section 7","Slide 10"],["Executive Summary","Data Sources","Appendices","Speaker Notes"]),"Academic Paper":new C("Academic Paper",["Paper","Chapter 6","Section 4","Subsection"],["Abstract","Literature Review","Methodology","Bibliography"]),"Research Report":new C("Research Report",["Report","Phase 4","Finding 8","Detail"],["Executive Summary","Data Analysis","Recommendations","Appendices"]),"User Guide":new C("User Guide",["Guide","Section 6","Task 8","Step"],["Quick Start","FAQ","Troubleshooting","Glossary"]),"Training Manual":new C("Training Manual",["Manual","Module 8","Lesson 5","Exercise"],["Learning Objectives","Assessment Criteria","Resources","Answer Key"]),"White Paper":new C("White Paper",["Paper","Section 5","Topic 3","Point"],["Executive Summary","Problem Statement","Solution Analysis","References"]),"Blog Series":new C("Blog Series",["Series","Category 5","Post 10","Section"],["Content Calendar","SEO Keywords","Style Guide","Resource Links"]),"Marketing Plan":new C("Marketing Plan",["Plan","Quarter 4","Campaign 6","Activity"],["Market Analysis","Target Personas","Budget Breakdown","KPI Tracker"]),"Product Documentation":new C("Product Documentation",["Documentation","Feature Set 8","Feature 12","Detail"],["API Reference","Examples","Integration Guide","Changelog"]),"Course Curriculum":new C("Course Curriculum",["Course","Unit 8","Lesson 5","Activity"],["Learning Objectives","Assessment Rubrics","Resource Materials","Standards Alignment"]),Thesis:new C("Thesis",["Thesis","Chapter 6","Section 4","Subsection"],["Literature Review","Methodology","Data Analysis","Bibliography"]),"Poetry Collection":new C("Poetry Collection",["Collection","Section 5","Poem"],["Theme Guide","Style Notes","Publication History","Author Bio"]),"Game Design Document":new C("Game Design Document",["Game","System 8","Feature 10","Detail"],["Core Mechanics","Art Bible","Audio Guide","Technical Specs"]),Cookbook:new C("Cookbook",["Cookbook","Category 8","Recipe 15","Step"],["Ingredient Glossary","Technique Guide","Equipment List","Nutritional Info"])};function Yr(a){return typeof a!="object"||a===null?!1:Object.values(a).every(e=>e&&typeof e.name=="string"&&Array.isArray(e.hierarchyLevels)&&Array.isArray(e.scaffoldingDocuments))}class qt{constructor(){p(this,"templates");p(this,"storageService");this.storageService=$.getInstance(),this.templates={},this.loadTemplates()}loadTemplates(){return h(this,null,function*(){try{const t=yield(yield this.storageService).get(ht);t&&Yr(t)?this.templates=t:(console.warn("Invalid templates found in storage. Reverting to defaults."),this.templates=T({},ke),yield this.saveAllTemplates())}catch(e){console.error("Failed to load templates from storage",e),this.templates=T({},ke)}})}saveAllTemplates(){return h(this,null,function*(){try{yield(yield this.storageService).set(ht,this.templates)}catch(e){console.error("Failed to save templates to storage",e)}})}getTemplate(e){return this.templates[e]}getTemplateNames(){return Object.keys(this.templates)}saveTemplate(e,t){return h(this,null,function*(){if(!e.trim())throw new Error("Template name cannot be empty.");t.name=e,this.templates[e]=t,yield this.saveAllTemplates()})}deleteTemplate(e){return h(this,null,function*(){if(Object.keys(this.templates).length<=1)throw new Error("Cannot delete the last remaining template.");delete this.templates[e],yield this.saveAllTemplates()})}restoreDefaults(){return h(this,null,function*(){this.templates=T({},ke),yield this.saveAllTemplates()})}getDefaultTemplateNames(){return Object.keys(ke)}}class we{constructor(e,t){p(this,"apiKey");p(this,"apiUrl","https://openrouter.ai/api/v1/chat/completions");p(this,"modelPurposeMap",{});p(this,"aiLogService");p(this,"settingsManager",null);p(this,"forceStreamingMode",!0);p(this,"currentAbortController",null);this.apiKey=e,t&&(this.modelPurposeMap=t),this.aiLogService=Ue.getInstance()}setSettingsManager(e){this.settingsManager=e}setModelPurpose(e,t){this.modelPurposeMap[e]=t}getModelForPurpose(e){return this.modelPurposeMap[e]}setSelectedModels(e){this.modelPurposeMap=e}getApiKey(){return this.apiKey}setForceStreamingMode(e){this.forceStreamingMode=e,console.log(`🌊 Streaming mode ${e?"ENABLED":"DISABLED"}`)}isForceStreamingMode(){return this.forceStreamingMode}abort(){this.currentAbortController&&(this.currentAbortController.abort(),this.currentAbortController=null)}canAbort(){return this.currentAbortController!==null}chat(e,t,r){return h(this,null,function*(){var s,l,c,d,u,g,f,w,y,S;const o=this.getModelForPurpose(e);if(!o)throw new Error(`No model configured for purpose: ${e}`);if(console.log(`🚀 Starting AI generation for purpose: ${e}, model: ${o}`),this.forceStreamingMode)return yield this.chatWithStreamingFallback(e,t,r);const n=Date.now(),i={model:o,messages:[{role:"user",content:t}]};try{console.log("📤 Sending request to OpenRouter:",{model:o,messageLength:t.length});const b=yield this.sendMessage(i,r);console.log("📨 Received response from OpenRouter:",{hasChoices:!!b.choices,choicesLength:((s=b.choices)==null?void 0:s.length)||0,hasContent:!!((d=(c=(l=b.choices)==null?void 0:l[0])==null?void 0:c.message)!=null&&d.content)});const P=(w=(f=(g=(u=b.choices)==null?void 0:u[0])==null?void 0:g.message)==null?void 0:f.content)!=null?w:"",I=Date.now()-n;if(console.log(`✅ AI generation completed successfully in ${I}ms, response length: ${P.length}`),(y=this.settingsManager)!=null&&y.isAILoggingEnabled())try{yield this.aiLogService.addLogEntry({timestamp:new Date,purpose:e,prompt:t,response:P,model:o,requestDuration:I})}catch(k){console.error("Failed to log AI interaction:",k)}return P}catch(b){const P=Date.now()-n;console.error(`❌ AI generation failed for purpose: ${e}`,{error:b instanceof Error?b.message:b,duration:P,model:o,messageLength:t.length,errorType:b instanceof Error?b.name:typeof b,stack:b instanceof Error?b.stack:void 0});try{return yield this.chatWithStreamingFallback(e,t,r)}catch(I){if(console.error("❌ Streaming also failed:",I),(S=this.settingsManager)!=null&&S.isAILoggingEnabled())try{yield this.aiLogService.addLogEntry({timestamp:new Date,purpose:e,prompt:t,response:`ERROR: ${b instanceof Error?b.message:"Unknown error"}`,model:o,requestDuration:P})}catch(k){console.error("Failed to log AI interaction error:",k)}throw b}}})}chatWithStreamingFallback(e,t,r){return h(this,null,function*(){return new Promise((o,n)=>{const i={onStart:()=>{},onChunk:s=>{},onComplete:s=>{o(s)},onError:s=>{n(s)}};this.streamingChat(e,[{role:"user",content:t}],i,r).catch(n)})})}sendMessage(e,t){return h(this,null,function*(){var r;this.currentAbortController=new AbortController,t&&t.addEventListener("abort",()=>{this.currentAbortController&&this.currentAbortController.abort()}),console.log("🌐 Initiating HTTP request to OpenRouter API",{url:this.apiUrl,model:e.model,messageCount:e.messages.length,hasStream:!!e.stream,hasAbortSignal:!!t});try{const o=yield fetch(this.apiUrl,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${this.apiKey}`},body:JSON.stringify(e),signal:this.currentAbortController.signal});if(console.log("📡 HTTP response received",{status:o.status,statusText:o.statusText,ok:o.ok,headers:{"content-type":o.headers.get("content-type"),"content-length":o.headers.get("content-length")}}),!o.ok){console.error("🚨 HTTP error response:",{status:o.status,statusText:o.statusText,url:this.apiUrl});const i=yield o.text();throw console.error("🚨 Error response body:",i),new Error(`OpenRouter API error: ${o.status} ${o.statusText} - ${i}`)}console.log("🔄 Parsing JSON response...");const n=yield o.json();return console.log("✅ JSON parsed successfully",{hasChoices:!!n.choices,choicesCount:((r=n.choices)==null?void 0:r.length)||0}),n}catch(o){throw console.error("💥 Request failed:",{errorName:o.name,errorMessage:o.message,isAbortError:o.name==="AbortError",isNetworkError:o instanceof TypeError,url:this.apiUrl}),o.name==="AbortError"?new Error("Request was aborted"):o}finally{console.log("🧹 Cleaning up abort controller"),this.currentAbortController=null}})}fetchModels(){return h(this,null,function*(){const e=yield fetch("https://openrouter.ai/api/v1/models",{headers:{Authorization:`Bearer ${this.apiKey}`}});if(!e.ok)throw new Error(`OpenRouter API error: ${e.status} ${e.statusText}`);return(yield e.json()).data})}streamingChat(e,t,r,o){return h(this,null,function*(){var l,c,d,u,g,f,w,y,S,b,P,I;const n=this.getModelForPurpose(e);if(!n){const k=new Error(`No model configured for purpose: ${e}`);throw(l=r.onError)==null||l.call(r,k),k}const i=Date.now(),s={model:n,messages:t,stream:!0};try{this.currentAbortController=new AbortController,o&&o.addEventListener("abort",()=>{this.currentAbortController&&this.currentAbortController.abort()});const k=yield fetch(this.apiUrl,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${this.apiKey}`},body:JSON.stringify(s),signal:this.currentAbortController.signal});if(!k.ok){const A=yield k.text(),z=new Error(`OpenRouter API error: ${k.status} ${k.statusText} - ${A}`);throw(c=r.onError)==null||c.call(r,z),z}if(!k.body){const A=new Error("Response body is null");throw(d=r.onError)==null||d.call(r,A),A}const L=k.body.getReader(),M=new TextDecoder;let G="";try{for(;;){const{done:z,value:ae}=yield L.read();if(z)break;const ir=M.decode(ae,{stream:!0}).split(`
`);for(const et of ir)if(et.startsWith("data: ")){const tt=et.slice(6);if(tt==="[DONE]")continue;try{const _e=(f=(g=(u=JSON.parse(tt).choices)==null?void 0:u[0])==null?void 0:g.delta)==null?void 0:f.content;_e&&(G+=_e,(w=r.onChunk)==null||w.call(r,_e))}catch(sr){continue}}}const A=Date.now()-i;if((y=this.settingsManager)!=null&&y.isAILoggingEnabled())try{yield this.aiLogService.addLogEntry({timestamp:new Date,purpose:e,prompt:t.map(z=>`${z.role}: ${z.content}`).join(`
`),response:G,model:n,requestDuration:A})}catch(z){console.error("Failed to log AI interaction:",z)}(S=r.onComplete)==null||S.call(r,G)}finally{L.releaseLock()}}catch(k){if(k.name==="AbortError"){const L=new Error("Request was aborted");throw(b=r.onError)==null||b.call(r,L),L}if((P=this.settingsManager)!=null&&P.isAILoggingEnabled())try{const L=Date.now()-i;yield this.aiLogService.addLogEntry({timestamp:new Date,purpose:e,prompt:t.map(M=>`${M.role}: ${M.content}`).join(`
`),response:`ERROR: ${k instanceof Error?k.message:"Unknown error"}`,model:n,requestDuration:L})}catch(L){console.error("Failed to log AI interaction error:",L)}throw(I=r.onError)==null||I.call(r,k),k}finally{this.currentAbortController=null}})}chatStreamConversation(e,t,r,o){return h(this,null,function*(){var n;return(n=r.onStart)==null||n.call(r),this.streamingChat(e,t,r,o)})}static checkBrowserCompatibility(){const e=[];typeof fetch=="undefined"&&e.push("Fetch API not supported"),typeof AbortController=="undefined"&&e.push("AbortController not supported"),(typeof JSON=="undefined"||!JSON.parse||!JSON.stringify)&&e.push("JSON API not fully supported"),typeof ReadableStream=="undefined"&&e.push("ReadableStream not supported (streaming may fail)"),typeof TextDecoder=="undefined"&&e.push("TextDecoder not supported (streaming may fail)");try{const t=new Response("test");(!t.body||typeof t.body.getReader!="function")&&e.push("Response.body.getReader not supported (streaming may fail)")}catch(t){e.push("Unable to test streaming capabilities")}return console.log("🔍 Browser compatibility check:",{compatible:e.length===0,issues:e.length>0?e:["All features supported"],userAgent:navigator.userAgent}),{compatible:e.length===0,issues:e}}}const Jr=Object.freeze(Object.defineProperty({__proto__:null,OpenRouterClient:we},Symbol.toStringTag,{value:"Module"}));function Xr(){return h(this,null,function*(){console.log("🧪 Testing Persist Tag Functionality...");const a=new zt,e=new de,t={chat:(u,g)=>h(null,null,function*(){return`This is synthesized context based on: ${g.substring(0,100)}...`})},r=new Ht(a,t,e);console.log("📝 Testing persist tag extraction...");const o=`
This is regular context content.

<persist>
Important data that should persist: API key = abc123
Character names: Alice, Bob, Charlie
</persist>

More regular context here.

<persist>
Another persist block with settings:
Theme: Dark fantasy
Style: Third person narrative
</persist>

Final context content.
    `.trim(),n=r.extractPersistTags(o);console.log("✓ Extracted persist data:"),console.log("  - Number of persist blocks:",n.persistData.length),console.log("  - Cleaned context length:",n.cleanedContext.length),console.log("  - Persist data:",n.persistData);const s=r.appendPersistData("This is new synthesized context content.",n.persistData);console.log("✓ Final result with persist data appended:"),console.log("  - Length:",s.length),console.log("  - Contains original persist blocks:",s.includes("<persist>"));const l=2,c=(s.match(/<persist>/g)||[]).length;console.log(c===l?"✅ Persist blocks correctly preserved!":`❌ Expected ${l} persist blocks, found ${c}`);const d=r.appendPersistData("Clean content",[]);console.log(d==="Clean content"?"✅ Correctly handles empty persist data":"❌ Failed to handle empty persist data correctly"),console.log("🎉 Persist Tag Functionality Test Complete!")})}class ze{constructor(e){p(this,"openRouterClient");p(this,"mockSettingsManager");p(this,"mockLoopOrchestrator");this.openRouterClient=e,this.mockSettingsManager=new de;try{const t={prompt:"Test generation prompt",criteria:[{name:"Test Criterion",description:"A test criterion for testing",goal:7,weight:1}],maxIterations:5,selectedModels:{creator:"test-model",rater:"test-model",editor:"test-model"},contextExtractionPrompt:`Extract relevant context from the following content for use in generating new content:

{{content}}

Provide a clear, structured summary of the key information that would be useful for content generation.`};this.mockSettingsManager.saveProfile("default",t),this.mockSettingsManager.setLastUsedProfile("default")}catch(t){}this.mockLoopOrchestrator=new Ut(this.openRouterClient,this.mockSettingsManager.getPrompts())}runPhase1Tests(){return h(this,null,function*(){const e=[];return e.push(this.testDocumentNodeCreation()),e.push(this.testProjectTemplateCreation()),e.push(this.testProjectManagerCreation()),e.push(this.testTreeManipulation()),e.push(this.testPersistence()),e.push(yield this.testApiConnection()),e.push(this.testEmptyHierarchyTemplate()),e.push(this.testNodePathGeneration()),e.push(this.testDeepTreeStructure()),e.push(this.testNodeContentManagement()),e.push(this.testInvalidNodeOperations()),e.push(this.testTemplateValidation()),e.push(this.testErrorMessages()),e.push(this.testGenerationChildrenCount()),e.push(yield this.testPersistTagFunctionality()),this.formatResultsAsHtml(e,"Phase 1: Core Functionality Tests")})}runStorageTests(){return h(this,null,function*(){const e=[];return e.push(yield this.testStorageServiceInitialization()),e.push(yield this.testStorageServiceBasicOperations()),e.push(yield this.testStorageServiceBulkOperations()),e.push(yield this.testStorageServiceMetadata()),e.push(yield this.testIndexedDBServiceInitialization()),e.push(yield this.testIndexedDBServiceOperations()),e.push(yield this.testIndexedDBServiceTransactions()),e.push(yield this.testTemplateManagerStorage()),e.push(yield this.testSettingsManagerStorage()),e.push(yield this.testProjectManagerStorage()),e.push(yield this.testSettingsExportImport()),e.push(yield this.testStorageCapacity()),e.push(yield this.testStoragePerformance()),this.formatResultsAsHtml(e,"Storage System Tests")})}testPersistTagFunctionality(){return h(this,null,function*(){try{return yield Xr(),{success:!0,message:"Persist Tag Functionality: Context persistence through hierarchy works correctly."}}catch(e){return{success:!1,message:`Persist Tag Functionality Failed: ${e.message}`}}})}formatResultsAsHtml(e,t="Test Results"){let r=`<h2>${t}</h2>`;const o=e.filter(i=>i.success).length,n=e.length;return r+=`<p><strong>Results: ${o}/${n} tests passed</strong></p>`,r+='<ul style="list-style-type: none; padding: 0;">',e.forEach(i=>{const s=i.success?'<span style="color: green; font-weight: bold;">✔ SUCCESS</span>':'<span style="color: red; font-weight: bold;">✖ FAILED</span>';r+=`<li style="margin-bottom: 0.75rem; border-bottom: 1px solid #eee; padding-bottom: 0.75rem;">${s}: ${i.message}</li>`}),r+="</ul>",r}testApiConnection(){return h(this,null,function*(){if(!this.openRouterClient.apiKey)return{success:!1,message:"API Test Aborted: OpenRouterClient was not initialized with an API key."};try{const e=yield this.openRouterClient.fetchModels();return e.length>0?{success:!0,message:`API Connection Test: Successfully fetched ${e.length} models from OpenRouter.`}:{success:!1,message:"API Connection Test: Fetched 0 models. Check API key and network."}}catch(e){return{success:!1,message:`API Connection Test Failed: ${e.message}`}}})}testDocumentNodeCreation(){try{const e=new pe(0,"My Awesome Book",null,["Book","Chapter"]);if(!e.id||e.level!==0||e.title!=="My Awesome Book")throw new Error("Node properties are not set correctly in the constructor.");const t=new pe(1,"Act 1: The Beginning",e.id);if(t.parentId!==e.id)throw new Error("Parent ID is not set correctly.");if(e.children.push(t),e.children.length!==1||e.children[0]!==t)throw new Error("Child node was not added correctly.");return{success:!0,message:"Step 1.1: DocumentNode class created and linked successfully."}}catch(e){return{success:!1,message:`Step 1.1 Failed: ${e.message}`}}}testProjectTemplateCreation(){try{const e=new C("Standard Novel",["Book","Act","Chapter"],["Main Outline","Character Bios"]);if(e.name!=="Standard Novel"||e.hierarchyLevels.length!==3)throw new Error("Novel template properties not set correctly.");const t=new C("Technical Manual",["Manual","Section","Topic"],["Glossary"]);if(t.name!=="Technical Manual"||t.scaffoldingDocuments.length!==1)throw new Error("Manual template properties not set correctly.");return{success:!0,message:"Step 1.2: ProjectTemplate class created successfully."}}catch(e){return{success:!1,message:`Step 1.2 Failed: ${e.message}`}}}testProjectManagerCreation(){try{const e=new C("Standard Novel",["Book","Act","Chapter"],["Main Outline","Character Bios"]),t=new N("My Sci-Fi Novel",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(t.projectTitle!=="My Sci-Fi Novel")throw new Error("Project title not set correctly.");if(t.rootNode.level!==0||t.rootNode.title!=="My Sci-Fi Novel")throw new Error("Root node not initialized correctly - should use project title.");if(t.findNodeById(t.rootNode.id)!==t.rootNode)throw new Error("findNodeById failed to find the root node.");if(t.findNodeById("non-existent-id")!==null)throw new Error("findNodeById returned a node for a non-existent ID.");return{success:!0,message:"Step 1.3: ProjectManager class created and findNodeById works."}}catch(e){return{success:!1,message:`Step 1.3 Failed: ${e.message}`}}}testTreeManipulation(){try{const e=new C("Novel",["Book","Act","Chapter"],[]),t=new N("Test Project",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient),r=t.addNode("Act 1",t.rootNode.id);if(t.rootNode.children[0]!==r)throw new Error("addNode failed to add a child to the root.");const o=t.addNode("Chapter 1",r.id);if(r.children[0]!==o)throw new Error("addNode failed to add a grandchild.");if(o.level!==2||o.parentId!==r.id)throw new Error("Grandchild node has incorrect properties.");if(!t.removeNode(o.id)||r.children.length!==0)throw new Error("removeNode failed to remove a child node.");if(t.removeNode(t.rootNode.id))throw new Error("Should not be able to remove the root node.");return{success:!0,message:"Step 1.4: Tree manipulation (add/remove) works correctly."}}catch(e){return{success:!1,message:`Step 1.4 Failed: ${e.message}`}}}testPersistence(){try{const e=new C("Novel",["Part","Chapter","Scene"],[]),t=new N("My Novel",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);t.addNode("Chapter 1",t.rootNode.id);const r=t.save(),o=N.load(r,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(t.projectTitle!==o.projectTitle)throw new Error("projectTitle mismatch");if(t.template.name!==o.template.name)throw new Error("template.name mismatch");const n=c=>{if(!(c instanceof pe))return console.error("Node is not an instance of DocumentNode",c),!1;for(const d of c.children)if(!n(d))return!1;return!0};if(!n(o.rootNode))throw new Error("Node rehydration failed; object is not an instance of DocumentNode.");const i=o.save(),s=JSON.parse(r),l=JSON.parse(i);if(JSON.stringify(s)!==JSON.stringify(l))throw console.error("Re-saved JSON does not match original."),new Error("Project state is not the same after saving and loading.");return{success:!0,message:"Step 1.5: ProjectManager persistence (save/load) works correctly."}}catch(e){return{success:!1,message:`Step 1.5 Failed: ${e.message}`}}}testEmptyHierarchyTemplate(){try{const e=new C("Empty Template",[],[]);try{throw new N("Test Project",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient),new Error("ProjectManager should have thrown an error for empty hierarchy template")}catch(t){if(t.message.includes("no hierarchy levels defined"))return{success:!0,message:"Step 2.1: Empty hierarchy template properly rejected."};throw t}}catch(e){return{success:!1,message:`Step 2.1 Failed: ${e.message}`}}}testNodePathGeneration(){try{const e=new C("Novel",["Book","Act","Chapter"],[]),t=new N("Test Novel",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient),r=t.addNode("Act 1",t.rootNode.id),o=t.addNode("Chapter 1",r.id),n=t.getNodePath(t.rootNode.id);if(!n.includes("Book: Test Novel"))throw new Error(`Root path incorrect: ${n}`);const i=t.getNodePath(o.id);if(!i.includes("Book: Test Novel")||!i.includes("Act: Act 1")||!i.includes("Chapter: Chapter 1"))throw new Error(`Deep path incorrect: ${i}`);return{success:!0,message:"Step 2.2: Node path generation works correctly."}}catch(e){return{success:!1,message:`Step 2.2 Failed: ${e.message}`}}}testDeepTreeStructure(){try{const e=new C("Manual",["Manual","Section","Topic","Subtopic"],[]),t=new N("Test Manual",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient),r=t.addNode("Section 1",t.rootNode.id),o=t.addNode("Topic 1",r.id),n=t.addNode("Subtopic 1",o.id);if(t.rootNode.level!==0)throw new Error("Root level should be 0");if(r.level!==1)throw new Error("Section level should be 1");if(o.level!==2)throw new Error("Topic level should be 2");if(n.level!==3)throw new Error("Subtopic level should be 3");if(r.parentId!==t.rootNode.id)throw new Error("Section parent incorrect");if(o.parentId!==r.id)throw new Error("Topic parent incorrect");if(n.parentId!==o.id)throw new Error("Subtopic parent incorrect");if(n.template[3]!=="Subtopic")throw new Error("Template access incorrect");return{success:!0,message:"Step 2.3: Deep tree structure and levels work correctly."}}catch(e){return{success:!1,message:`Step 2.3 Failed: ${e.message}`}}}testNodeContentManagement(){try{const e=new C("Story",["Story","Chapter"],[]),t=new N("Test Story",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient),r=t.addNode("Chapter 1",t.rootNode.id);if(r.content!=="")throw new Error("Initial content should be empty");if(r.context!=="")throw new Error("Initial context should be empty");if(r.content="This is test content for chapter 1.",r.content!=="This is test content for chapter 1.")throw new Error("Content setting failed");if(r.context="A brief context for chapter 1.",r.context!=="A brief context for chapter 1.")throw new Error("Context setting failed");if(!r.isLeaf)throw new Error("Chapter should be detected as leaf node");if(t.rootNode.isLeaf)throw new Error("Root with children should not be leaf");return{success:!0,message:"Step 2.4: Node content management works correctly."}}catch(e){return{success:!1,message:`Step 2.4 Failed: ${e.message}`}}}testInvalidNodeOperations(){try{const e=new C("Test",["Root","Child"],[]),t=new N("Test Project",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);try{throw t.addNode("Invalid Child","non-existent-id"),new Error("Should have thrown error for non-existent parent")}catch(i){if(!i.message.includes("not found"))throw new Error("Wrong error message for non-existent parent")}if(t.removeNode("non-existent-id")!==!1)throw new Error("Removing non-existent node should return false");if(t.removeNode(t.rootNode.id)!==!1)throw new Error("Removing root node should return false");if(t.findNodeById("non-existent-id")!==null)throw new Error("Finding non-existent node should return null");return{success:!0,message:"Step 2.5: Invalid node operations handled correctly."}}catch(e){return{success:!1,message:`Step 2.5 Failed: ${e.message}`}}}testTemplateValidation(){try{try{const r=["Book",void 0,"Chapter"];new C("Bad",r,[]).hierarchyLevels.includes(void 0)}catch(r){}const e=new C("Test",["Book","","Chapter"],[]);if(e.hierarchyLevels[1]===""){const r=new N("Test",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);r.addNode("Test Child",r.rootNode.id)}const t=new C("Novel",["Book","Chapter"],["Outline","Characters"]);if(t.name!=="Novel")throw new Error("Template name not set correctly");if(t.hierarchyLevels.length!==2)throw new Error("Hierarchy levels not set correctly");if(t.scaffoldingDocuments.length!==2)throw new Error("Scaffolding documents not set correctly");return{success:!0,message:"Step 2.6: Template validation works correctly."}}catch(e){return{success:!1,message:`Step 2.6 Failed: ${e.message}`}}}testErrorMessages(){try{const e=new C("Test",["Root","Child"],[]),t=new N("Test",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);try{t.addNode("Test","invalid-parent-id")}catch(r){if(!r.message.includes("invalid-parent-id"))throw new Error("Error message should include the invalid parent ID");if(!r.message.includes("not found"))throw new Error("Error message should indicate the parent was not found")}try{const r=new C("Empty",[],[]);new N("Test",r,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient)}catch(r){if(!r.message.includes("Empty"))throw new Error("Error message should include template name");if(!r.message.includes("hierarchy levels"))throw new Error("Error message should mention hierarchy levels")}return{success:!0,message:"Step 2.7: Error messages are helpful and informative."}}catch(e){return{success:!1,message:`Step 2.7 Failed: ${e.message}`}}}testGenerationChildrenCount(){try{const e=new C("Default",["Book","Chapter"],[]),t=new N("Test",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(t.rootNode.generationChildrenCount!==5)throw new Error(`Expected default count of 5, got ${t.rootNode.generationChildrenCount}`);const r=new C("Numbered",["Book","Chapter 3","Scene"],[]),o=new N("Test",r,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(o.rootNode.generationChildrenCount!==3)throw new Error(`Expected parsed count of 3 from "Chapter 3", got ${o.rootNode.generationChildrenCount}`);const n=new C("Various",["Book","Act 7","Scene"],[]),i=new N("Test",n,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(i.rootNode.generationChildrenCount!==7)throw new Error(`Expected parsed count of 7 from "Act 7", got ${i.rootNode.generationChildrenCount}`);const s=new C("NoNumber",["Book","Chapter","Scene"],[]),l=new N("Test",s,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(l.rootNode.generationChildrenCount!==5)throw new Error(`Expected default count of 5 for template without number, got ${l.rootNode.generationChildrenCount}`);const c=new C("HighNumber",["Book","Chapter 999","Scene"],[]),d=new N("Test",c,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(d.rootNode.generationChildrenCount!==5)throw new Error(`Expected default count of 5 for invalid high number, got ${d.rootNode.generationChildrenCount}`);return{success:!0,message:"Step 2.8: GenerationChildrenCount parsing from templates works correctly."}}catch(e){return{success:!1,message:`Step 2.8 Failed: ${e.message}`}}}testStorageServiceInitialization(){return h(this,null,function*(){try{if(!(yield $.getInstance()))throw new Error("Storage service not initialized");const t=yield $.getStorageInfo();if(!t.available)throw new Error("Storage not available");if(t.type!=="indexedDB")throw new Error(`Unknown storage type: ${t.type}`);return{success:!0,message:`Storage Test 1: StorageService initialized successfully (${t.type})`}}catch(e){return{success:!1,message:`Storage Test 1 Failed: ${e.message}`}}})}testStorageServiceBasicOperations(){return h(this,null,function*(){try{const e=yield $.getInstance(),t="test_storage_key_"+Date.now(),r={message:"test value",timestamp:Date.now()};yield e.set(t,r);const o=yield e.get(t);if(!o||o.message!==r.message)throw new Error("Storage set/get failed");if(yield e.delete(t),(yield e.get(t))!==void 0)throw new Error("Storage delete failed");return{success:!0,message:"Storage Test 2: Basic storage operations work correctly"}}catch(e){return{success:!1,message:`Storage Test 2 Failed: ${e.message}`}}})}testStorageServiceBulkOperations(){return h(this,null,function*(){try{const e=yield $.getInstance(),t="bulk_test_"+Date.now()+"_",r={[t+"1"]:{value:"first"},[t+"2"]:{value:"second"},[t+"3"]:{value:"third"}};for(const[i,s]of Object.entries(r))yield e.set(i,s);const o=yield e.getAll(t),n=Object.keys(o);if(n.length<3)throw new Error(`Expected 3 items with prefix, got ${n.length}`);for(const i of n)yield e.delete(i);return{success:!0,message:"Storage Test 3: Bulk operations work correctly"}}catch(e){return{success:!1,message:`Storage Test 3 Failed: ${e.message}`}}})}testStorageServiceMetadata(){return h(this,null,function*(){try{const e=yield $.getInstance(),t=yield $.getStorageInfo();if(typeof t.available!="boolean")throw new Error("Storage availability not reported correctly");if(t.type!=="indexedDB")throw new Error("Expected IndexedDB storage type");const r=yield e.getUsage();if(typeof r.quota!="number"||typeof r.usage!="number")throw new Error("Storage usage information not provided correctly");if(!e.isIndexedDB())throw new Error("Expected IndexedDB but got other storage type");return{success:!0,message:"Storage Test 4: Storage metadata and type detection work correctly"}}catch(e){return{success:!1,message:`Storage Test 4 Failed: ${e.message}`}}})}testIndexedDBServiceInitialization(){return h(this,null,function*(){try{if(!window.indexedDB)return{success:!0,message:"IndexedDB Test 1: Skipped (IndexedDB not supported in this browser)"};if(!(yield $.getInstance()).isIndexedDB())return{success:!1,message:"IndexedDB Test 1: Failed - IndexedDB is required but not available"};const t={name:"TestDB_"+Date.now(),version:1,stores:[{name:"testStore",keyPath:"id"}]},r=new ye(t);if(yield r.initialize(),!r.isInitialized())throw new Error("IndexedDB service not initialized");return r.close(),{success:!0,message:"IndexedDB Test 1: IndexedDB service initializes correctly"}}catch(e){return{success:!1,message:`IndexedDB Test 1 Failed: ${e.message}`}}})}testIndexedDBServiceOperations(){return h(this,null,function*(){try{if(!window.indexedDB)return{success:!0,message:"IndexedDB Test 2: Skipped (IndexedDB not supported)"};if(!(yield $.getInstance()).isIndexedDB())return{success:!1,message:"IndexedDB Test 2: Failed - IndexedDB is required but not available"};const t={name:"TestDBOps_"+Date.now(),version:1,stores:[{name:"testStore",keyPath:"id"}]},r=new ye(t);yield r.initialize();const o={id:"test1",value:"test value",timestamp:Date.now()};yield r.set("testStore","test1",o);const n=yield r.get("testStore","test1");if(!n||n.value!==o.value)throw new Error("IndexedDB set/get failed");if(yield r.delete("testStore","test1"),(yield r.get("testStore","test1"))!==void 0)throw new Error("IndexedDB delete failed");return r.close(),{success:!0,message:"IndexedDB Test 2: IndexedDB operations work correctly"}}catch(e){return{success:!1,message:`IndexedDB Test 2 Failed: ${e.message}`}}})}testIndexedDBServiceTransactions(){return h(this,null,function*(){try{if(!window.indexedDB)return{success:!0,message:"IndexedDB Test 3: Skipped (IndexedDB not supported)"};if(!(yield $.getInstance()).isIndexedDB())return{success:!1,message:"IndexedDB Test 3: Failed - IndexedDB is required but not available"};const t={name:"TestDBTrans_"+Date.now(),version:1,stores:[{name:"testStore",keyPath:"id"}]},r=new ye(t);yield r.initialize();const o=[{key:"bulk1",value:{id:"bulk1",data:"first"}},{key:"bulk2",value:{id:"bulk2",data:"second"}},{key:"bulk3",value:{id:"bulk3",data:"third"}}];yield r.bulkSet("testStore",o);const n=yield r.getAll("testStore");if(n.length<3)throw new Error(`Expected 3 items, got ${n.length}`);if(yield r.clear("testStore"),(yield r.getAll("testStore")).length!==0)throw new Error("Clear operation failed");return r.close(),{success:!0,message:"IndexedDB Test 3: IndexedDB transactions work correctly"}}catch(e){return{success:!1,message:`IndexedDB Test 3 Failed: ${e.message}`}}})}testTemplateManagerStorage(){return h(this,null,function*(){try{const e=new qt;let t=0;for(;e.getTemplateNames().length===0&&t<20;)yield new Promise(l=>setTimeout(l,100)),t++;if(e.getTemplateNames().length===0)throw new Error("No templates loaded - storage initialization failed after 2 seconds");const o="test_template_"+Date.now(),n=new C("Test Template",["Level1","Level2"],["Doc1"]);yield e.saveTemplate(o,n);const i=e.getTemplate(o);if(!i)throw new Error("Template save/get failed - retrieved template is null");if(i.name!==o)throw new Error(`Template save/get failed - expected name '${o}', got '${i.name}'`);if(yield e.deleteTemplate(o),e.getTemplate(o))throw new Error("Template delete failed - template still exists after deletion");return{success:!0,message:"Service Test 1: TemplateManager storage works correctly"}}catch(e){return{success:!1,message:`Service Test 1 Failed: ${e.message}`}}})}testSettingsManagerStorage(){return h(this,null,function*(){try{const e=new de;yield new Promise(n=>setTimeout(n,100));const t={prompt:"Test prompt",criteria:[{name:"Test",description:"Test criterion",goal:8,weight:1}],maxIterations:5,selectedModels:{creator:"test",rater:"test",editor:"test"},contextExtractionPrompt:"Test extraction prompt"};yield e.saveProfile("test_profile",t);const r=e.getProfile("test_profile");if(!r||r.prompt!=="Test prompt")throw new Error("Profile save/get failed");if(yield e.deleteProfile("test_profile"),e.getProfile("test_profile"))throw new Error("Profile delete failed");return{success:!0,message:"Service Test 2: SettingsManager storage works correctly"}}catch(e){return{success:!1,message:`Service Test 2 Failed: ${e.message}`}}})}testProjectManagerStorage(){return h(this,null,function*(){try{const e=new C("Test Project Template",["Root","Child"],[]),t=new N("Test Project",e,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);t.addNode("Test Child",t.rootNode.id),t.rootNode.content="Test root content",yield t.saveToStorage();const r=t.save(),o=N.load(r,this.mockLoopOrchestrator,this.mockSettingsManager,this.openRouterClient);if(o.projectTitle!==t.projectTitle)throw new Error("Project title not preserved");if(o.rootNode.content!==t.rootNode.content)throw new Error("Project content not preserved");if(o.rootNode.children.length!==t.rootNode.children.length)throw new Error("Project structure not preserved");return{success:!0,message:"Service Test 3: ProjectManager storage works correctly"}}catch(e){return{success:!1,message:`Service Test 3 Failed: ${e.message}`}}})}testStorageCapacity(){return h(this,null,function*(){try{const e=yield $.getInstance();yield e.getUsage();const t="capacity_test_"+Date.now(),r={content:"x".repeat(1024*10),metadata:{size:"10KB",timestamp:Date.now()}};yield e.set(t,r);const o=yield e.get(t);if(!o||o.content.length!==r.content.length)throw new Error("Large data storage failed");yield e.delete(t);const n=yield e.getUsage();return e.isIndexedDB()&&n.quota<1024*1024*50&&console.warn(`IndexedDB quota seems low: ${n.quota} bytes`),{success:!0,message:"Performance Test 1: Storage capacity adequate (IndexedDB)"}}catch(e){return{success:!1,message:`Performance Test 1 Failed: ${e.message}`}}})}testStoragePerformance(){return h(this,null,function*(){try{const e=yield $.getInstance(),t=performance.now(),r=10,o="perf_test_"+Date.now()+"_";for(let s=0;s<r;s++)yield e.set(o+s,{index:s,data:"test data for performance test",timestamp:Date.now()});for(let s=0;s<r;s++)if(!(yield e.get(o+s)))throw new Error(`Failed to retrieve item ${s}`);for(let s=0;s<r;s++)yield e.delete(o+s);const i=performance.now()-t;return i>1e3&&console.warn(`Storage operations took ${i}ms, which seems slow`),{success:!0,message:`Performance Test 2: Storage operations completed in ${Math.round(i)}ms (IndexedDB)`}}catch(e){return{success:!1,message:`Performance Test 2 Failed: ${e.message}`}}})}testSettingsExportImport(){return h(this,null,function*(){const e="export_test_profile_"+Date.now();try{const t=new de;yield new Promise(c=>setTimeout(c,100));const r={prompt:"Test export/import prompt",criteria:[{name:"Export Test",description:"Test criterion for export",goal:9,weight:1.5},{name:"Import Test",description:"Test criterion for import",goal:7,weight:.8}],maxIterations:8,selectedModels:{creator:"export-test",rater:"import-test",editor:"roundtrip-test"},contextExtractionPrompt:"Test context extraction prompt"};yield t.saveProfile(e,r);const o=t.exportProfile(e);if(!o)throw new Error("Export returned null for existing profile");if(!o.profileName||!o.profile||!o.prompts)throw new Error("Export data missing required fields");if(o.profileName!==e)throw new Error("Exported profile name doesn't match");if(o.profile.prompt!==r.prompt)throw new Error("Exported profile prompt doesn't match");if(o.profile.criteria.length!==r.criteria.length)throw new Error("Exported criteria count doesn't match");yield t.deleteProfile(e);const n=yield t.importProfile(o,!1);if(!n.success)throw new Error(`Import failed: ${n.message}`);const i=t.getProfile(e);if(!i)throw new Error("Imported profile not found");if(i.prompt!==r.prompt)throw new Error("Imported profile prompt doesn't match original");if(i.maxIterations!==r.maxIterations)throw new Error("Imported profile maxIterations doesn't match original");if(i.criteria.length!==r.criteria.length)throw new Error("Imported profile criteria count doesn't match original");const s=yield t.importProfile(o,!1);if(s.success||!s.message.includes("already exists"))throw new Error("Import should have failed due to existing profile");const l=yield t.importProfile(o,!0);if(!l.success)throw new Error(`Forced import failed: ${l.message}`);return yield t.deleteProfile(e),{success:!0,message:"Export/Import Test: Settings profile export/import works correctly with overwrite protection"}}catch(t){try{const r=new de;yield new Promise(o=>setTimeout(o,100)),yield r.deleteProfile(e)}catch(r){}return{success:!1,message:`Export/Import Test Failed: ${t.message}`}}})}}const be=class be{constructor(e){p(this,"projectManager");p(this,"config");this.projectManager=e,this.config=this.getDefaultConfig()}initialize(){return h(this,null,function*(){yield this.loadConfig()})}getDefaultConfig(){return{version:3,actions:[{id:"expand-details",title:"More Details",prompt:`Expand the following text with more details and examples. Return ONLY the expanded version without any introductory text or explanations:

{{selected}}

Context: {{content}}
Node: {{title}}

Expanded text:`,model:"creator",enabled:!0,order:1,description:"Add more details and examples to the selected text"},{id:"simplify",title:"Simplify",prompt:`Take the following text and make it shorter and simpler. Use fewer words and simpler language. Remove unnecessary details. Return ONLY the simplified version, nothing else:

{{selected}}

Simplified version:`,model:"editor",enabled:!0,order:2,description:"Make the selected text simpler and clearer"},{id:"improve-clarity",title:"Improve Clarity",prompt:`Rewrite the following text for better clarity and readability while maintaining its meaning. Return ONLY the improved version without any introductory text:

{{selected}}

Full context: {{content}}

Improved text:`,model:"editor",enabled:!0,order:3,description:"Improve clarity and readability"},{id:"add-examples",title:"Add Examples",prompt:`Add relevant examples to the following text. Return ONLY the text with examples integrated, without any introductory phrases:

{{selected}}

Node context: {{content}}
Project: {{project_title}}

Text with examples:`,model:"creator",enabled:!0,order:4,description:"Add practical examples to the content"},{id:"change",title:"Change",prompt:`Full context for reference:
Node: {{title}}
Content: {{content}}

An instruction follows that should be applied to a text.
Only return the result of that instruction, nothing more.
Instruction: {{input "How should the text be changed?"}}
Text:
{{selected}}`,model:"creator",enabled:!0,order:5,description:"Change selected text according to custom instructions"}]}}loadConfig(){return h(this,null,function*(){try{const t=yield(yield D(()=>Promise.resolve().then(()=>Q),void 0).then(o=>o.StorageService.getInstance())).get(be.CONFIG_STORAGE_KEY),r=3;t&&t.version===r?(this.config=t,console.log("✅ Reader edit actions config loaded from storage",{actionCount:this.config.actions.length,version:this.config.version})):(console.log("📝 Using default reader edit actions config",{reason:t?"version mismatch":"no saved config",savedVersion:t==null?void 0:t.version,currentVersion:r}),this.config.version=r,yield this.saveConfig())}catch(e){console.error("❌ Failed to load reader edit actions config:",e)}})}saveConfig(){return h(this,null,function*(){try{yield(yield D(()=>Promise.resolve().then(()=>Q),void 0).then(t=>t.StorageService.getInstance())).set(be.CONFIG_STORAGE_KEY,this.config),console.log("✅ Reader edit actions config saved successfully",{actionCount:this.config.actions.length,version:this.config.version})}catch(e){throw console.error("❌ Failed to save reader edit actions config:",e),e}})}getEnabledActions(){return this.config.actions.filter(e=>e.enabled).sort((e,t)=>e.order-t.order)}getAllActions(){return[...this.config.actions].sort((e,t)=>e.order-t.order)}addAction(e){return h(this,null,function*(){const t=`custom-${Date.now()}`,r=ee(T({},e),{id:t});return this.config.actions.push(r),yield this.saveConfig(),t})}updateAction(e,t){return h(this,null,function*(){const r=this.config.actions.findIndex(o=>o.id===e);return r===-1?!1:(this.config.actions[r]=T(T({},this.config.actions[r]),t),yield this.saveConfig(),!0)})}deleteAction(e){return h(this,null,function*(){const t=this.config.actions.findIndex(r=>r.id===e);return t===-1?!1:(this.config.actions.splice(t,1),yield this.saveConfig(),!0)})}executeAction(e,t){return h(this,null,function*(){const r=this.config.actions.find(l=>l.id===e);if(!r)throw new Error(`Action not found: ${e}`);const o=yield this.fillPrompt(r.prompt,t);if(o==="__CANCELED__")return"";const i=yield this.getOpenRouterClient().chat(r.model,o);return this.cleanAIResponse(i)})}fillPrompt(e,t){return h(this,null,function*(){var s;let r=e;const o=r.match(/\{\{input\s+"([^"]+)"\}\}/g);if(o)for(const l of o){const c=l.match(/\{\{input\s+"([^"]+)"\}\}/);if(c){const d=c[1],u=yield this.showInputModal(d);if(u==="__CANCELED__")return"__CANCELED__";r=r.replace(l,u)}}const n=((s=t.selection)==null?void 0:s.text)||"";r=r.replace(/\{\{selected\}\}/g,n);const i=yield this.buildPlaceholders(t.node);for(const[l,c]of Object.entries(i)){const d=new RegExp(`\\{\\{${l}\\}\\}`,"g");r=r.replace(d,c)}return r})}showInputModal(e){return h(this,null,function*(){return new Promise(t=>{D(()=>h(null,null,function*(){const{showGenericModal:r}=yield import("./index-BTgsZSUm.js");return{showGenericModal:r}}),__vite__mapDeps([2,0,1,3])).then(({showGenericModal:r})=>{let o=!1;const n=s=>{o||(o=!0,t(s))},i=r({content:`
                            <div style="margin-bottom: 1.5rem;">
                                <label style="display: block; font-weight: 500; color: #374151; margin-bottom: 0.5rem;">
                                    Please provide your input:
                                </label>
                                <input type="text" id="user-input" 
                                       style="width: 100%; padding: 0.75rem; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.875rem; transition: border-color 0.2s; box-sizing: border-box;" 
                                       placeholder="Enter your instruction..." autofocus>
                            </div>
                        `,actions:[{id:"cancel",label:"Cancel",type:"secondary",handler:()=>h(null,null,function*(){n("__CANCELED__"),i.close()})},{id:"submit",label:"OK",type:"primary",handler:()=>h(null,null,function*(){var c;const s=document.getElementById("user-input"),l=((c=s==null?void 0:s.value)==null?void 0:c.trim())||"";l?(n(l),i.close()):s==null||s.focus()})}]},{title:e,maxWidth:"400px"},{onOpen:()=>{setTimeout(()=>{const s=document.getElementById("user-input");s&&(s.addEventListener("keydown",l=>{if(l.key==="Enter"){l.preventDefault();const c=s.value.trim();c?(n(c),i.close()):s.focus()}else l.key==="Escape"&&(l.preventDefault(),n("__CANCELED__"),i.close())}),s.focus())},100)},onClose:()=>{o||n("__CANCELED__")}})})})})}getOpenRouterClient(){return this.projectManager.getGenerationService().deps.openRouterClient}buildPlaceholders(e){return h(this,null,function*(){var i;const t=this.projectManager.getTreeService(),o=this.projectManager.getContextService().compileNodeContext(e.id,this.projectManager.rootNode),n=t.getNodePath(e.id,this.projectManager.rootNode);return{content:e.content||"",title:e.title,path:n,context:o,project_title:this.projectManager.projectTitle,parent_content:e.parentId&&((i=this.projectManager.findNodeById(e.parentId))==null?void 0:i.content)||"",child_level_name:e.childLevelName||""}})}getAvailablePlaceholders(e){return h(this,null,function*(){const t={selected:"[Selected text in the reader]"};if(e){const r=yield this.buildPlaceholders(e);Object.assign(t,r)}else t.content="[Current node content]",t.title="[Current node title]",t.project_title="[Project title]",t.parent_content="[Parent node content]",t.context="[Node context and hierarchy]";return t})}validatePrompt(e){const t=[];e.trim()||t.push("Prompt cannot be empty"),e.includes("{{selected}}")||t.push("Prompt should include {{selected}} placeholder to use selected text");const r=(e.match(/\{\{/g)||[]).length,o=(e.match(/\}\}/g)||[]).length;return r!==o&&t.push("Unmatched placeholder braces - ensure all {{placeholder}} tags are properly closed"),{isValid:t.length===0,errors:t}}cleanAIResponse(e){let t=e.trim();const r=[/^Here'?s?\s+(an?\s+)?(expanded|improved|simplified|rewritten|clarified|shorter|concise)[^:]*:\s*/i,/^I'?ve\s+(expanded|improved|simplified|rewritten|clarified|made\s+it)[^:]*:\s*/i,/^The\s+(expanded|improved|simplified|rewritten|clarified|shorter)\s+(version|text)[^:]*:\s*/i,/^(Expanded|Improved|Simplified|Rewritten|Clarified|Shorter)\s+(text|version)[^:]*:\s*/i,/^(Here|Below)\s+is\s+(the\s+)?(simplified|shorter|improved)[^:]*:\s*/i,/^As\s+requested[^:]*:\s*/i,/^(Certainly|Sure|Of\s+course)[^:]*:\s*/i,/^Let\s+me\s+(simplify|improve|rewrite)[^:]*:\s*/i,/^I\s+can\s+(simplify|improve|rewrite)[^:]*:\s*/i,/^To\s+(simplify|improve|make\s+it\s+clearer)[^:]*:\s*/i,/^A\s+(simplified|shorter|improved)\s+version[^:]*:\s*/i,/^(Making\s+it\s+simpler|Simplifying)[^:]*:\s*/i];for(const n of r)t=t.replace(n,"");const o=[/\n\n(This\s+(expanded|improved|simplified|rewritten|clarified)\s+version|I\s+hope\s+this\s+helps|Let\s+me\s+know)[^]*$/i,/\n\n(This\s+is\s+(now\s+)?(simpler|shorter|clearer)|The\s+simplified\s+version)[^]*$/i,/\n\n(Is\s+this\s+what\s+you\s+were\s+looking\s+for|Does\s+this\s+work)[^]*$/i];for(const n of o)t=t.replace(n,"");return t=t.replace(/^:\s*/,""),t=t.replace(/^\s+|\s+$/g,""),t=t.replace(/\n\s*\n\s*\n/g,`

`),t}resetToDefaults(){return h(this,null,function*(){this.config=this.getDefaultConfig(),yield this.saveConfig()})}};p(be,"CONFIG_STORAGE_KEY","reader_edit_actions");let Ye=be;class Qr{constructor(e){p(this,"container");p(this,"editableDiv");p(this,"highlights",new Map);p(this,"plainTextContent","");p(this,"selectionMode","sentences");p(this,"changeCallback");p(this,"focusCallback");p(this,"blurCallback");p(this,"lastReplacement",null);p(this,"highlightTimeouts",new Map);this.container=e,this.createEditor(),this.setupEventListeners(),this.plainTextContent=""}createEditor(){this.editableDiv=document.createElement("div"),this.editableDiv.contentEditable="true",this.editableDiv.className="text-editor-with-highlighting",this.editableDiv.style.cssText=`
            width: 100%;
            min-height: 80px;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-family: inherit;
            font-size: inherit;
            line-height: inherit;
            white-space: pre-wrap;
            word-wrap: break-word;
            outline: none;
            background: transparent;
            overflow-y: auto;
            resize: vertical;
        `,this.container.appendChild(this.editableDiv)}setupEventListeners(){this.editableDiv.addEventListener("input",()=>{this.plainTextContent=this.editableDiv.textContent||"",this.clearAllHighlights(),this.changeCallback&&this.changeCallback(this.getText())}),this.editableDiv.addEventListener("focus",()=>{this.focusCallback&&this.focusCallback()}),this.editableDiv.addEventListener("blur",()=>{this.blurCallback&&this.blurCallback()}),this.editableDiv.addEventListener("paste",e=>{var r;e.preventDefault();const t=((r=e.clipboardData)==null?void 0:r.getData("text/plain"))||"";document.execCommand("insertText",!1,t)})}getText(){return this.plainTextContent}setText(e){this.plainTextContent=e,this.editableDiv.textContent=e,this.highlights.clear()}addHighlight(e,t,r,o="highlight-ai-replacement"){const n=this.getText();if(t<0||r>n.length||t>=r){console.warn("Invalid highlight range:",{startPos:t,endPos:r,textLength:n.length});return}const i=this.highlightTimeouts.get(e);if(i&&clearTimeout(i),this.highlights.set(e,{startPos:t,endPos:r,className:o}),this.renderWithHighlights(),o.includes("highlight-ai-replacement")||o.includes("ai-result")){const s=setTimeout(()=>{this.removeHighlight(e),this.highlightTimeouts.delete(e)},5e3);this.highlightTimeouts.set(e,s)}}removeHighlight(e){const t=this.highlightTimeouts.get(e);t&&(clearTimeout(t),this.highlightTimeouts.delete(e)),this.highlights.delete(e),this.renderWithHighlights()}clearAllHighlights(){this.highlightTimeouts.forEach(e=>clearTimeout(e)),this.highlightTimeouts.clear(),this.highlights.clear(),this.renderWithHighlights()}expandToWordBoundaries(e,t){return this.selectionMode==="sentences"?this.expandToSentenceBoundaries(e,t):this.selectionMode==="paragraphs"?this.expandToParagraphBoundaries(e,t):this.expandToWordBoundariesOnly(e,t)}expandToWordBoundariesOnly(e,t){const r=this.getText();let o=e,n=t;for(;o>0;){const i=r[o-1];if(/\s/.test(i)||/[.!?]/.test(i))break;if(/[\w'-]/.test(i))o--;else break}for(;n<r.length;){const i=r[n];if(/\s/.test(i)||/[.!?]/.test(i))break;if(/[\w'-]/.test(i))n++;else break}for(;o<n&&/\s/.test(r[o]);)o++;for(;n>o&&/\s/.test(r[n-1]);)n--;return{startPos:o,endPos:n}}expandToSentenceBoundaries(e,t){const r=this.getText();let o=e,n=t;for(;o>0;){const i=r[o-1];if(/[.!?]/.test(i)&&(o===r.length||/\s/.test(r[o])))break;o--}for(;n<r.length;){const i=r[n];if(/[.!?]/.test(i)){n++;break}n++}for(;o<n&&/\s/.test(r[o]);)o++;return{startPos:o,endPos:n}}expandToParagraphBoundaries(e,t){const r=this.getText();let o=e,n=t;for(;o>0&&!(r[o-1]===`
`&&(o>1&&r[o-2]===`
`||o===1||r[o-2]===`
`));)o--;for(;n<r.length;){if(r[n]===`
`){if(n+1<r.length&&r[n+1]===`
`)break;if(n+1===r.length||r[n+1]===`
`){n++;break}}n++}for(;o<n&&/\s/.test(r[o]);)o++;for(;n>o&&/\s/.test(r[n-1]);)n--;return{startPos:o,endPos:n}}addPreviewHighlight(e,t){this.clearAllHighlights(),this.addHighlight("preview",e,t,"highlight-ai-preview")}hasPreviewHighlight(){return this.highlights.has("preview")}setSelectionMode(e){this.selectionMode=e}getSelectionMode(){return this.selectionMode}convertPreviewToResult(e){const t=this.highlights.get("preview");if(!t)return;const r=t.startPos,o=t.endPos;this.replaceTextWithHighlight(r,o,e,"ai-result")}replaceTextWithHighlight(e,t,r,o="ai-replacement"){const n=this.getText(),i=n.substring(0,e),s=n.substring(t),l=n.substring(e,t);this.lastReplacement={startPos:e,endPos:t,originalText:l,replacedText:r};const c=i+r+s,d=e+r.length;this.setText(c),this.addHighlight(o,e,d)}canUndo(){if(!this.lastReplacement)return!1;const e=this.getText(),{startPos:t,replacedText:r}=this.lastReplacement,o=t+r.length;return o>e.length?!1:e.substring(t,o)===r}undoLastReplacement(){if(!this.canUndo()||!this.lastReplacement)return!1;const{startPos:e,originalText:t,replacedText:r}=this.lastReplacement,o=e+r.length,n=this.getText(),i=n.substring(0,e),s=n.substring(o),l=i+t+s;return this.lastReplacement=null,this.setText(l),!0}clearUndo(){this.lastReplacement=null}getUndoState(){return this.lastReplacement}setSelection(e,t){const r=document.createRange(),o=window.getSelection();if(!o)return;const n=this.editableDiv.firstChild;if(!(!n||n.nodeType!==Node.TEXT_NODE))try{r.setStart(n,e),r.setEnd(n,t),o.removeAllRanges(),o.addRange(r)}catch(i){console.warn("Failed to set selection:",i)}}getSelection(){const e=window.getSelection();if(!e||e.rangeCount===0)return null;const t=e.getRangeAt(0),r=this.getText(),o=this.getTextOffset(t.startContainer,t.startOffset),n=this.getTextOffset(t.endContainer,t.endOffset);return o===-1||n===-1?null:{startPos:o,endPos:n,text:r.substring(o,n)}}focus(){this.editableDiv.focus()}onTextChange(e){this.changeCallback=e}onFocus(e){this.focusCallback=e}onBlur(e){this.blurCallback=e}renderWithHighlights(){const e=this.plainTextContent;if(this.highlights.size===0){this.editableDiv.textContent=e;return}const t=Array.from(this.highlights.entries()).sort(([,n],[,i])=>n.startPos-i.startPos);let r="",o=0;for(const[n,i]of t){i.startPos>o&&(r+=this.escapeHtml(e.substring(o,i.startPos)));const s=e.substring(i.startPos,i.endPos);r+=`<span class="${i.className}" data-highlight-id="${n}">${this.escapeHtml(s)}</span>`,o=i.endPos}o<e.length&&(r+=this.escapeHtml(e.substring(o))),this.editableDiv.innerHTML=r}getTextOffset(e,t){var i;const r=document.createTreeWalker(this.editableDiv,NodeFilter.SHOW_TEXT,null);let o=0,n;for(;n=r.nextNode();){if(n===e)return o+t;o+=((i=n.textContent)==null?void 0:i.length)||0}return-1}escapeHtml(e){const t=document.createElement("div");return t.textContent=e,t.innerHTML}destroy(){this.highlightTimeouts.forEach(e=>clearTimeout(e)),this.highlightTimeouts.clear(),this.editableDiv.remove(),this.highlights.clear()}}class Zr{constructor(e,t){p(this,"readerGUI");p(this,"projectManager");p(this,"editManager");p(this,"editState");p(this,"nodeEditors",new Map);p(this,"currentActiveEditor",null);p(this,"autoSaveTimer",null);p(this,"configLoadedPromise");p(this,"boundHandleKeyDown");this.readerGUI=e,this.projectManager=t,this.editManager=new Ye(t),this.boundHandleKeyDown=this.handleKeyDown.bind(this),this.editState={isEditMode:!0,isDirty:!1,lastSaved:null,editableNodes:new Map},this.configLoadedPromise=this.editManager.initialize().then(()=>{this.readerGUI.updateActionButtons()})}initialize(e){return h(this,null,function*(){yield this.configLoadedPromise,e&&e.size>0&&this.removeEditorOverlays(),this.createEditorOverlays(e),this.setupEventListeners(),this.updateEditModeUI(),this.readerGUI.updateActionButtons()})}getEditState(){return T({},this.editState)}getCurrentSelection(){if(!this.currentActiveEditor||!this.currentActiveEditor.editor)return null;const e=this.currentActiveEditor.editor.getSelection();return!e||!e.text?null:{text:e.text,startOffset:e.startPos,endOffset:e.endPos,nodeId:this.currentActiveEditor.nodeId,element:this.currentActiveEditor.element}}getCurrentEditContext(){if(!this.currentActiveEditor)return null;const e=this.projectManager.findNodeById(this.currentActiveEditor.nodeId);if(!e)return null;const t=this.getCurrentSelection(),r=t?t.startOffset:0;return{selection:t,cursorPosition:r,nodeId:this.currentActiveEditor.nodeId,node:e}}executeAction(e){return h(this,null,function*(){const t=this.getCurrentEditContext();if(!t||!this.currentActiveEditor){console.warn("No edit context available for action execution");return}try{this.showActionLoadingState(e);let r=t;if(t.selection&&t.selection.text){const n=this.currentActiveEditor.editor.expandToWordBoundaries(t.selection.startOffset,t.selection.endOffset);this.currentActiveEditor.editor.addPreviewHighlight(n.startPos,n.endPos);const i=this.currentActiveEditor.editor.getText().substring(n.startPos,n.endPos);r=ee(T({},t),{selection:ee(T({},t.selection),{text:i,startOffset:n.startPos,endOffset:n.endPos})})}const o=yield this.editManager.executeAction(e,r);this.applyAIResult(this.currentActiveEditor,r,o)}catch(r){console.error("Failed to execute action:",r),alert(`Action failed: ${r instanceof Error?r.message:"Unknown error"}`)}finally{this.hideActionLoadingState(e)}})}applyAIResult(e,t,r){const o=t.selection;if(o&&o.text)e.editor.hasPreviewHighlight()?e.editor.convertPreviewToResult(r):e.editor.replaceTextWithHighlight(o.startOffset,o.endOffset,r,"highlight-ai-replacement");else{const n=e.editor.getSelection(),i=n?n.startPos:0;e.editor.replaceTextWithHighlight(i,i,r,"highlight-ai-replacement")}this.markDirty(e)}createEditorOverlays(e){this.readerGUI.getContainer().querySelectorAll(".node-content[data-node-id]").forEach(o=>{var c,d,u;const n=o,i=n.getAttribute("data-node-id");if(!i)return;const s=this.projectManager.findNodeById(i);if(!s)return;const l=(d=(c=e==null?void 0:e.get(i))!=null?c:s.content)!=null?d:"";this.createNodeEditor(i,n,l,(u=e==null?void 0:e.has(i))!=null?u:!1)})}createNodeEditor(e,t,r,o=!1){if(this.nodeEditors.has(e))return;t.innerHTML="",t.style.position="relative",t.style.minHeight="80px";const n=new Qr(t);n.setText(r);const i={nodeId:e,element:t,editor:n,originalContent:o?r:r||"",isDirty:!1};this.nodeEditors.set(e,i),this.editState.editableNodes.set(e,t),n.onTextChange(s=>{this.markDirty(i),this.readerGUI.updateUndoButtonState()}),n.onFocus(()=>{this.handleEditorFocus(i)}),n.onBlur(()=>{this.handleEditorBlur(i)})}removeEditorOverlays(){this.nodeEditors.forEach(e=>{e.editor.destroy(),e.element.style.position="",e.element.style.minHeight=""}),this.nodeEditors.clear(),this.editState.editableNodes.clear(),this.currentActiveEditor=null}handleEditorFocus(e){this.currentActiveEditor=e,this.readerGUI.updateActionButtons(),this.readerGUI.updateUndoButtonState()}handleEditorBlur(e){e.isDirty&&this.scheduleAutoSave()}markDirty(e){e.isDirty=!0,this.editState.isDirty=!0,this.scheduleAutoSave()}scheduleAutoSave(){this.autoSaveTimer&&clearTimeout(this.autoSaveTimer),this.autoSaveTimer=setTimeout(()=>{this.saveAllChanges()},2e3)}saveAllChanges(){return h(this,null,function*(){if(!this.editState.isDirty)return;const e=[];this.nodeEditors.forEach(t=>{t.isDirty&&e.push(this.saveNodeChanges(t))}),yield Promise.all(e),this.editState.isDirty=!1,this.editState.lastSaved=new Date})}saveNodeChanges(e){return h(this,null,function*(){const t=this.projectManager.findNodeById(e.nodeId);if(!t){console.error("Node not found for saving:",e.nodeId);return}t.content=e.editor.getText(),e.originalContent=e.editor.getText(),e.isDirty=!1,yield this.projectManager.saveToStorage()})}setupEventListeners(){document.addEventListener("keydown",this.boundHandleKeyDown)}removeEventListeners(){document.removeEventListener("keydown",this.boundHandleKeyDown)}handleKeyDown(e){if(this.currentActiveEditor&&(e.ctrlKey||e.metaKey)&&e.key==="s"){e.preventDefault(),this.saveAllChanges();return}}showActionLoadingState(e){const t=document.querySelector(`[data-action-id="${e}"]`);t&&(t.disabled=!0,t.textContent="⏳ Processing...")}hideActionLoadingState(e){const t=document.querySelector(`[data-action-id="${e}"]`);if(t){t.disabled=!1;const r=t.getAttribute("data-original-text");r&&(t.textContent=r)}}getEnabledActions(){return this.editManager.getEnabledActions()}getAllActions(){return this.editManager.getAllActions()}updateAction(e,t){return h(this,null,function*(){return this.editManager.updateAction(e,t)})}deleteAction(e){return h(this,null,function*(){return this.editManager.deleteAction(e)})}addAction(e){return h(this,null,function*(){return this.editManager.addAction(e)})}resetToDefaults(){return h(this,null,function*(){return this.editManager.resetToDefaults()})}setSelectionMode(e){this.nodeEditors.forEach(t=>{t.editor.setSelectionMode(e)})}getCurrentSelectionMode(){return this.currentActiveEditor?this.currentActiveEditor.editor.getSelectionMode():"sentences"}canUndo(){return this.currentActiveEditor?this.currentActiveEditor.editor.canUndo():!1}undoLastReplacement(){if(!this.currentActiveEditor)return!1;const e=this.currentActiveEditor.editor.undoLastReplacement();return e&&this.markDirty(this.currentActiveEditor),e}onDOMRecreated(){}updateEditModeUI(){const e=this.readerGUI.getContainer();e.classList.add("reader-edit-mode");const t=e.querySelector("#reader-edit-mode");t&&(t.style.display="none")}destroy(){this.removeEventListeners(),this.removeEditorOverlays(),this.autoSaveTimer&&clearTimeout(this.autoSaveTimer)}preserveAllContent(){const e=new Map;return this.nodeEditors.forEach((t,r)=>{const o=t.editor.getText();e.set(r,o)}),e}restoreAllContent(e){e.forEach((t,r)=>{const o=this.nodeEditors.get(r);o&&(o.editor.setText(t),o.originalContent=t,o.isDirty=!1)})}}const pt="expert_app_reader_config";class eo{constructor(e,t,r){p(this,"projectManager");p(this,"container");p(this,"contentNodes",[]);p(this,"clickMappings",[]);p(this,"config");p(this,"onNavigateToNode");p(this,"isListeningForUpdates",!1);p(this,"isSettingsPanelOpen",!1);p(this,"readerEditor");p(this,"hasBeenRendered",!1);p(this,"boundHandleClick");p(this,"boundHandleDoubleClick");p(this,"boundHandleNodeGenerationComplete");p(this,"boundHandleNodeSummaryGenerated");p(this,"boundHandleProjectUpdate");this.projectManager=e,this.container=t,this.onNavigateToNode=r,this.boundHandleClick=this.handleClick.bind(this),this.boundHandleDoubleClick=this.handleDoubleClick.bind(this),this.boundHandleNodeGenerationComplete=this.handleNodeGenerationComplete.bind(this),this.boundHandleNodeSummaryGenerated=this.handleNodeSummaryGenerated.bind(this),this.boundHandleProjectUpdate=this.handleProjectUpdate.bind(this),this.readerEditor=new Zr(this,e),this.config={showTOC:!0,showAllLevels:!1,fontSize:16,lineHeight:1.6,maxWidth:800,theme:"light",separatorStyle:"standard"},this.setupEventListeners(),this.loadReaderConfig()}render(){this.contentNodes=this.analyzeProjectContent(),this.container.innerHTML=this.generateReaderHTML(),this.applyStyles(),this.buildClickMappings(),this.setupAllEventListeners(),this.readerEditor.initialize(),this.hasBeenRendered=!0}setupAllEventListeners(){this.setupEventListeners(),this.isSettingsPanelOpen&&this.restoreSettingsPanel()}restoreSettingsPanel(){const e=this.container.querySelector("#reader-settings-panel");e&&(e.style.display="block",this.setupSettingsEventListeners())}refresh(){this.render()}loadReaderConfig(){return h(this,null,function*(){try{const t=yield(yield $.getInstance()).get(pt);t&&(this.config=T(T({},this.config),t))}catch(e){console.warn("Failed to load reader configuration:",e)}})}saveReaderConfig(){return h(this,null,function*(){try{yield(yield $.getInstance()).set(pt,this.config)}catch(e){console.warn("Failed to save reader configuration:",e)}})}scrollToNode(e){const t=this.container.querySelector(`#node-${e}`);t&&(t.scrollIntoView({behavior:"smooth",block:"start"}),t.style.transition="box-shadow 0.3s ease",t.style.boxShadow="0 0 20px rgba(66, 153, 225, 0.6)",setTimeout(()=>{t.style.boxShadow=""},1500))}handleTOCNavigation(e){if(this.config.showAllLevels){this.scrollToNode(e);return}if(this.contentNodes.some(r=>r.id===e))this.scrollToNode(e);else{const r=this.findFirstDisplayableDescendant(e);r&&this.scrollToNode(r)}}findFirstDisplayableDescendant(e){const t=this.projectManager.findNodeById(e);if(!t)return null;if(this.isDeepestAvailableContent(t))return t.id;for(const r of t.children){const o=this.findFirstDisplayableDescendant(r.id);if(o)return o}return null}analyzeProjectContent(){const e=[];let t=0;const r=o=>{const n=this.shouldDisplayNode(o);if(n){const i=this.calculateWordCount(o.content),s=Math.ceil(i/200);e.push({id:o.id,title:o.title,content:"",level:o.level,isLeaf:o.children.length===0,hasContent:!!(o.content&&o.content.trim()),position:t++,wordCount:i,estimatedReadingTime:s})}(!n||this.shouldProcessChildren(o))&&o.children.forEach(i=>r(i))};return r(this.projectManager.rootNode),e}shouldDisplayNode(e){return this.config.showAllLevels?e.content&&e.content.trim()?!0:e.children.length===0:this.isDeepestAvailableContent(e)}shouldProcessChildren(e){return this.config.showAllLevels?e.children.length>0:e.children.length>0&&(!e.content||!e.content.trim()||this.hasDeepContentInChildren(e))}isDeepestAvailableContent(e){return e.content&&e.content.trim()?!e.children.some(r=>this.hasAnyContentInSubtree(r)):e.children.length===0}hasAnyContentInSubtree(e){return e.content&&e.content.trim()?!0:e.children.some(t=>this.hasAnyContentInSubtree(t))}hasDeepContentInChildren(e){return e.children.some(t=>this.hasAnyContentInSubtree(t))}calculateWordCount(e){return!e||!e.trim()?0:e.trim().split(/\s+/).length}generateReaderHTML(){return this.contentNodes.length===0?`
                <div class="reader-container">
                    <div class="reader-header">
                        <h1>Reader View</h1>
                        <button id="close-reader-btn" class="close-btn">&times;</button>
                    </div>
                    <div class="reader-content">
                        <div class="no-content">
                            <h2>No Content Available</h2>
                            <p>This project doesn't have any readable content yet. Add some content to nodes and try again.</p>
                        </div>
                    </div>
                </div>
            `:`
            <div class="reader-container">
                <div class="reader-header">
                    <h1>${this.projectManager.projectTitle} - Reader View</h1>
                    <div class="reader-controls">
                        <button id="reader-actions-config" class="control-btn">🔧 Configure Actions</button>
                        <button id="reader-toc-btn" class="control-btn">📋 TOC</button>
                        <button id="reader-settings-btn" class="control-btn">⚙️ Settings</button>
                        <button id="close-reader-btn" class="close-btn">&times;</button>
                    </div>
                </div>
                <div class="reader-body">
                    ${this.config.showTOC?this.generateTOC():""}
                    <div class="reader-content-area">
                        ${this.generateContent()}
                    </div>
                    <div id="reader-action-buttons" class="reader-action-buttons" style="display: none;">
                        <div class="action-buttons-header">AI Actions</div>
                        <div id="action-buttons-container" class="action-buttons-container">
                            <!-- Action buttons will be dynamically inserted here -->
                        </div>
                    </div>
                    ${this.generateSettingsPanel()}
                </div>
            </div>
        `}generateTOC(){return`
            <div class="reader-toc">
                ${this.generateTOCContent()}
            </div>
        `}generateTOCContent(){const e=this.analyzeTOCContent();let t=`
            <h3>Table of Contents</h3>
            <ul class="toc-list">
        `;return e.forEach(r=>{const o=r.level*20;t+=`
                <li class="toc-item" style="margin-left: ${o}px;">
                    <a href="#node-${r.id}" class="toc-link" data-node-id="${r.id}">
                        ${r.title}
                    </a>
                    <span class="toc-info">${r.wordCount} words</span>
                </li>
            `}),t+=`
            </ul>
        `,t}analyzeTOCContent(){const e=[];let t=0;const r=o=>{const n=!!(o.content&&o.content.trim()),i=o.children.length===0;if(n||i){const s=this.calculateWordCount(o.content),l=Math.ceil(s/200);e.push({id:o.id,title:o.title,content:"",level:o.level,isLeaf:i,hasContent:n,position:t++,wordCount:s,estimatedReadingTime:l})}o.children.forEach(s=>r(s))};return r(this.projectManager.rootNode),e}generateContent(){let e='<div class="reader-content reader-content-minimal">';return this.contentNodes.forEach(t=>{e+=this.generateNodeHTML(t)}),e+="</div>",e}generateNodeHTML(e){const t=this.calculateDepthFromLeaf(e);let r=`
            <div class="reader-node reader-node-minimal" id="node-${e.id}" data-node-id="${e.id}" data-level="${e.level}" data-depth-from-leaf="${t}">
                <div class="node-minimal-title">${e.title}</div>
        `;return e.hasContent&&(r+=`
                <div class="node-content node-content-minimal" data-node-id="${e.id}">
                    <!-- Content will be rendered by editor textareas -->
                </div>
            `),r+="</div>",r}calculateDepthFromLeaf(e){const t=this.projectManager.findNodeById(e.id);return t?this.getDepthFromTemplateLeaf(t):0}getDepthFromTemplateLeaf(e){const r=this.projectManager.template.hierarchyLevels.length-1,o=e.level;return Math.max(0,r-o)}applyStyles(){if(document.getElementById("reader-styles"))return;const e=document.createElement("style");e.id="reader-styles",e.textContent=this.generateCSS(),document.head.appendChild(e)}refreshStyles(){const e=document.getElementById("reader-styles");e&&e.remove(),this.applyStyles()}generateCSS(){return`
            .reader-container {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: white;
                z-index: 10000;
                display: flex;
                flex-direction: column;
                font-family: Georgia, 'Times New Roman', serif;
            }

            .reader-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 1rem 2rem;
                border-bottom: 1px solid #e5e7eb;
                background: #fafafa;
                flex-shrink: 0;
            }

            .reader-header h1 {
                margin: 0;
                font-size: 1.5rem;
                color: #374151;
            }

            .reader-controls {
                display: flex;
                gap: 1rem;
                align-items: center;
            }

            .control-btn {
                padding: 0.5rem 1rem;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                background: white;
                cursor: pointer;
                font-size: 0.9rem;
            }

            .control-btn:hover {
                background: #f3f4f6;
            }

            .close-btn {
                width: 32px;
                height: 32px;
                border: none;
                border-radius: 50%;
                background: #ef4444;
                color: white;
                cursor: pointer;
                font-size: 1.2rem;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .close-btn:hover {
                background: #dc2626;
            }

            .reader-body {
                display: flex;
                flex: 1;
                overflow: hidden;
            }

            .reader-toc {
                width: 300px;
                border-right: 1px solid #e5e7eb;
                background: #f9fafb;
                padding: 1.5rem;
                overflow-y: auto;
                flex-shrink: 0;
            }

            .reader-toc h3 {
                margin: 0 0 1rem 0;
                font-size: 1.1rem;
                color: #374151;
            }

            .toc-list {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            .toc-item {
                margin-bottom: 0.5rem;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .toc-link {
                color: #4338ca;
                text-decoration: none;
                font-size: 0.9rem;
                flex: 1;
            }

            .toc-link:hover {
                text-decoration: underline;
            }

            .toc-info {
                font-size: 0.75rem;
                color: #6b7280;
                margin-left: 0.5rem;
            }

            .reader-content-area {
                flex: 1;
                overflow-y: auto;
                padding: 0;
            }

            .reader-content {
                max-width: ${this.config.maxWidth}px;
                margin: 0;
                padding: 2rem;
                line-height: ${this.config.lineHeight};
                font-size: ${this.config.fontSize}px;
            }

            .reader-node {
                margin-bottom: 2rem;
                padding: 2rem;
                border-radius: 8px;
                transition: background-color 0.2s ease;
                cursor: text;
            }

            .reader-node:hover {
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }

            /* Hierarchy background colors based on depth from leaf when showing all levels */
            ${this.config.showAllLevels?`
            /* Leafs (deepest content) - White background */
            .reader-node[data-depth-from-leaf="0"] {
                background-color: #ffffff;
                border-left: 4px solid #e5e7eb;
            }
            /* 1 level above leafs - Light green */
            .reader-node[data-depth-from-leaf="1"] {
                background-color: #f0fdf4;
                border-left: 4px solid #22c55e;
            }
            /* 2 levels above leafs - Light blue */
            .reader-node[data-depth-from-leaf="2"] {
                background-color: #eff6ff;
                border-left: 4px solid #3b82f6;
            }
            /* 3 levels above leafs - Light red */
            .reader-node[data-depth-from-leaf="3"] {
                background-color: #fef2f2;
                border-left: 4px solid #ef4444;
            }
            /* 4 levels above leafs - Light gray */
            .reader-node[data-depth-from-leaf="4"] {
                background-color: #f9fafb;
                border-left: 4px solid #9ca3af;
            }
            /* 5+ levels above leafs - Darker gray */
            .reader-node[data-depth-from-leaf="5"], 
            .reader-node[data-depth-from-leaf="6"], 
            .reader-node[data-depth-from-leaf="7"], 
            .reader-node[data-depth-from-leaf="8"], 
            .reader-node[data-depth-from-leaf="9"] {
                background-color: #f3f4f6;
                border-left: 4px solid #6b7280;
            }
            `:""}

            .node-header {
                margin-bottom: 1.5rem;
            }

            .node-title {
                color: #1f2937;
                line-height: 1.2;
            }

            .node-meta {
                display: flex;
                gap: 1rem;
                margin-top: 0.5rem;
                font-size: 0.8rem;
                color: #6b7280;
            }

            .node-content {
                color: #374151;
                line-height: inherit;
            }

            .node-content p {
                margin-bottom: 1rem;
                text-align: justify;
            }

            .node-content p:last-child {
                margin-bottom: 0;
            }

            .reader-separator.major {
                border-top: 3px solid #d1d5db;
                margin: 4rem 0;
                position: relative;
            }

            .reader-separator.minor {
                border-top: 1px solid #e5e7eb;
                margin: 2rem 0;
            }

            .reader-separator.section {
                margin: 1.5rem 0;
                height: 1px;
                background: transparent;
            }

            .no-content {
                text-align: center;
                padding: 4rem 2rem;
                color: #6b7280;
            }

            .no-content h2 {
                color: #374151;
                margin-bottom: 1rem;
            }

            /* Responsive design */
            @media (max-width: 768px) {
                .reader-toc {
                    display: none;
                }
                
                .reader-header {
                    padding: 1rem;
                }
                
                .reader-header h1 {
                    font-size: 1.2rem;
                }
                
                .reader-content {
                    padding: 1rem;
                    max-width: none;
                }
                
                .reader-controls {
                    gap: 0.5rem;
                }
                
                .control-btn {
                    padding: 0.4rem 0.8rem;
                    font-size: 0.8rem;
                }
            }

            /* Settings Panel */
            .reader-settings-panel {
                position: fixed;
                top: 0;
                right: 0;
                width: 350px;
                height: 100vh;
                background: white;
                border-left: 1px solid #e5e7eb;
                box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
                z-index: 10001;
                overflow-y: auto;
            }

            .settings-panel-content {
                padding: 2rem;
            }

            .settings-panel-content h3 {
                margin: 0 0 1.5rem 0;
                color: #374151;
                border-bottom: 1px solid #e5e7eb;
                padding-bottom: 0.5rem;
            }

            .settings-group {
                margin-bottom: 1.5rem;
            }

            .settings-group label {
                display: block;
                margin-bottom: 0.5rem;
                font-weight: 500;
                color: #4b5563;
            }

            .settings-group input[type="range"] {
                width: 100%;
                margin-bottom: 0.5rem;
            }

            .settings-group select {
                width: 100%;
                padding: 0.5rem;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                background: white;
            }

            .setting-value {
                font-size: 0.9rem;
                color: #6b7280;
                font-weight: 500;
            }

            .settings-buttons {
                display: flex;
                gap: 1rem;
                margin-top: 2rem;
                padding-top: 1rem;
                border-top: 1px solid #e5e7eb;
            }

            .settings-buttons button {
                flex: 1;
                padding: 0.75rem;
                border: 1px solid #d1d5db;
                border-radius: 6px;
                background: white;
                cursor: pointer;
                font-size: 0.9rem;
            }

            .settings-buttons button:hover {
                background: #f3f4f6;
            }

            #reader-settings-reset {
                background: #ef4444 !important;
                color: white !important;
                border-color: #ef4444 !important;
            }

            #reader-settings-reset:hover {
                background: #dc2626 !important;
            }

            /* Theme styles */
            .reader-theme-dark {
                background: #1f2937;
                color: #f9fafb;
            }

            .reader-theme-dark .reader-header {
                background: #111827;
                border-color: #374151;
                color: #f9fafb;
            }

            .reader-theme-dark .reader-header h1 {
                color: #f9fafb;
            }

            .reader-theme-dark .reader-toc {
                background: #111827;
                border-color: #374151;
                color: #f9fafb;
            }

            .reader-theme-dark .reader-toc h3 {
                color: #f9fafb;
            }

            .reader-theme-dark .toc-link {
                color: #60a5fa;
            }

            .reader-theme-dark .toc-link:hover {
                color: #93c5fd;
            }

            .reader-theme-dark .toc-info {
                color: #9ca3af;
            }

            .reader-theme-dark .reader-node {
                background: #374151 !important;
                color: #f9fafb;
            }

            .reader-theme-dark .node-title {
                color: #f9fafb !important;
            }

            .reader-theme-dark .node-meta {
                color: #9ca3af !important;
            }

            .reader-theme-dark .node-content {
                color: #e5e7eb !important;
            }

            .reader-theme-dark .reader-separator.major {
                border-color: #4b5563;
            }

            .reader-theme-dark .reader-separator.minor {
                border-color: #374151;
            }

            .reader-theme-dark .no-content {
                color: #9ca3af;
            }

            .reader-theme-dark .no-content h2 {
                color: #f9fafb;
            }

            .reader-theme-sepia {
                background: #f7f3e9;
                color: #5c4b37;
            }

            .reader-theme-sepia .reader-header {
                background: #f0e6d2;
                border-color: #d6c7a1;
            }

            .reader-theme-sepia .reader-toc {
                background: #f0e6d2;
                border-color: #d6c7a1;
            }

            .reader-theme-sepia .reader-node {
                background: #faf6ec !important;
                color: #5c4b37;
            }

            /* Dark theme settings panel */
            .reader-theme-dark .reader-settings-panel {
                background: #1f2937;
                border-color: #374151;
                color: #f9fafb;
            }

            .reader-theme-dark .settings-panel-content h3 {
                color: #f9fafb;
                border-color: #374151;
            }

            .reader-theme-dark .settings-group label {
                color: #e5e7eb;
            }

            .reader-theme-dark .settings-group select {
                background: #374151;
                border-color: #4b5563;
                color: #f9fafb;
            }

            .reader-theme-dark .setting-value {
                color: #9ca3af;
            }

            .reader-theme-dark .settings-buttons {
                border-color: #374151;
            }

            .reader-theme-dark .settings-buttons button {
                background: #374151;
                border-color: #4b5563;
                color: #f9fafb;
            }

            .reader-theme-dark .settings-buttons button:hover {
                background: #4b5563;
            }

            /* Minimal mode styles */
            .reader-content-minimal {
                padding: 1rem 2rem;
            }

            .reader-node-minimal {
                margin-bottom: 1.5rem;
                padding: 0;
                background: transparent !important;
                border-radius: 0;
                transition: none;
            }

            /* Hierarchy background colors override for minimal mode when showing all levels */
            ${this.config.showAllLevels?`
            /* Leafs (deepest content) - White background */
            .reader-node-minimal[data-depth-from-leaf="0"] {
                background-color: #ffffff !important;
                border-left: 4px solid #e5e7eb !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            /* 1 level above leafs - Light green */
            .reader-node-minimal[data-depth-from-leaf="1"] {
                background-color: #f0fdf4 !important;
                border-left: 4px solid #22c55e !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            /* 2 levels above leafs - Light blue */
            .reader-node-minimal[data-depth-from-leaf="2"] {
                background-color: #eff6ff !important;
                border-left: 4px solid #3b82f6 !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            /* 3 levels above leafs - Light red */
            .reader-node-minimal[data-depth-from-leaf="3"] {
                background-color: #fef2f2 !important;
                border-left: 4px solid #ef4444 !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            /* 4 levels above leafs - Light gray */
            .reader-node-minimal[data-depth-from-leaf="4"] {
                background-color: #f9fafb !important;
                border-left: 4px solid #9ca3af !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            /* 5+ levels above leafs - Darker gray */
            .reader-node-minimal[data-depth-from-leaf="5"], 
            .reader-node-minimal[data-depth-from-leaf="6"], 
            .reader-node-minimal[data-depth-from-leaf="7"], 
            .reader-node-minimal[data-depth-from-leaf="8"], 
            .reader-node-minimal[data-depth-from-leaf="9"] {
                background-color: #f3f4f6 !important;
                border-left: 4px solid #6b7280 !important;
                padding: 0.75rem !important;
                border-radius: 4px !important;
                margin-bottom: 1rem !important;
            }
            `:""}

            .reader-node-minimal:last-child {
                margin-bottom: 0;
            }

            .reader-node-minimal:hover {
                box-shadow: none;
            }

            .node-minimal-title {
                font-size: 0.7rem;
                color: #6b7280;
                margin-bottom: 0;
                font-weight: 500;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }

            .node-content-minimal {
                color: #374151;
                line-height: inherit;
                margin-bottom: 0;
            }



            .node-content-minimal p {
                margin-top: 0;
                margin-bottom: 1rem;
                text-align: justify;
            }

            .node-content-minimal p:first-child {
                margin-top: 0;
            }

            .node-content-minimal p:last-child {
                margin-bottom: 0;
            }

            /* Full meta mode styles */
            .reader-content-with-meta {
                padding: 2rem;
            }

            .reader-node-with-meta {
                margin-bottom: 2rem;
                padding: 2rem;
            }

            .node-title-row {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 0.5rem;
            }

            .node-path {
                font-size: 0.75rem;
                color: #6b7280;
                font-weight: normal;
                margin-left: 1rem;
                flex-shrink: 0;
                font-style: italic;
            }

            /* Print styles */
            @media print {
                .reader-header,
                .reader-toc,
                .reader-settings-panel {
                    display: none !important;
                }
                
                .reader-container {
                    position: static;
                    width: auto;
                    height: auto;
                }
                
                .reader-body {
                    display: block;
                }
                
                .reader-content-area {
                    overflow: visible;
                }
                
                .reader-node {
                    page-break-inside: avoid;
                    margin-bottom: 1rem;
                    padding: 1rem;
                }
                
                .reader-separator.major {
                    page-break-after: always;
                }

                .node-minimal-title {
                    font-size: 0.6rem;
                }

                .reader-content-minimal {
                    padding: 0.5rem;
                }
            }

            /* Legacy edit mode styles removed - always-edit mode now */

            /* Reader Action Buttons */
            .reader-action-buttons {
                position: fixed;
                right: 20px;
                top: 50%;
                transform: translateY(-50%);
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
                padding: 12px;
                min-width: 160px;
                max-width: 200px;
                z-index: 10001;
            }

            .action-buttons-header {
                font-weight: 600;
                color: #374151;
                margin-bottom: 8px;
                font-size: 0.9rem;
                text-align: center;
                border-bottom: 1px solid #e5e7eb;
                padding-bottom: 8px;
            }

            .action-buttons-container {
                display: flex;
                flex-direction: column;
                gap: 6px;
            }

            .selection-mode-toggle {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                padding: 0.5rem;
                background-color: #f8f9fa;
                border-radius: 4px;
                font-size: 0.875rem;
                width: 100%;
                box-sizing: border-box;
                margin-bottom: 0.25rem;
            }

            .selection-mode-label {
                font-weight: 500;
                color: #374151;
                flex-shrink: 0;
            }

            .selection-mode-select {
                padding: 0.25rem 0.5rem;
                border: 1px solid #d1d5db;
                border-radius: 4px;
                font-size: 0.875rem;
                background: white;
                flex: 1;
            }

            .action-buttons-separator {
                width: 100%;
                height: 1px;
                background-color: #e5e7eb;
                margin: 0.25rem 0;
            }

            .reader-action-btn {
                padding: 8px 12px;
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                cursor: pointer;
                font-size: 0.85rem;
                color: #475569;
                transition: all 0.2s ease;
                text-align: left;
            }

            .reader-action-btn:hover {
                background: #e2e8f0;
                border-color: #cbd5e1;
                color: #334155;
            }

            .reader-action-btn:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }

            .reader-action-btn.processing {
                background: #dbeafe;
                border-color: #93c5fd;
                color: #1e40af;
            }

            .reader-undo-btn:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                background: #f1f5f9;
                color: #94a3b8;
            }

            .reader-undo-btn:not(:disabled):hover {
                background: #fef3c7;
                border-color: #f59e0b;
                color: #d97706;
            }
        `}setupEventListeners(){this.container.removeEventListener("dblclick",this.boundHandleDoubleClick),this.container.removeEventListener("click",this.boundHandleClick),this.container.addEventListener("dblclick",this.boundHandleDoubleClick),this.container.addEventListener("click",this.boundHandleClick)}handleDoubleClick(e){const r=e.target.closest("[data-node-id]");if(r&&this.onNavigateToNode){const o=r.dataset.nodeId;o&&this.onNavigateToNode(o)}}handleClick(e){var r,o;const t=e.target;if(t.id==="close-reader-btn")this.close();else if(t.id==="reader-actions-config")this.openActionsConfigModal();else if(t.classList.contains("reader-action-btn")){const n=t.getAttribute("data-action-id");n==="undo"?this.readerEditor.undoLastReplacement()&&this.updateUndoButtonState():n&&this.readerEditor.executeAction(n).then(()=>{this.updateUndoButtonState()})}else if(t.id==="reader-toc-btn")this.toggleTOC();else if(t.id==="reader-settings-btn")this.toggleSettings();else if(t.classList.contains("toc-link")){e.preventDefault();const n=t.dataset.nodeId;n&&this.handleTOCNavigation(n)}else if(t.tagName==="A"&&((r=t.getAttribute("href"))!=null&&r.startsWith("#node-"))){e.preventDefault();const n=(o=t.getAttribute("href"))==null?void 0:o.substring(6);n&&this.handleTOCNavigation(n)}else t.id==="reader-settings-close"?this.toggleSettings():t.id==="reader-settings-reset"&&this.resetSettings()}setupSettingsEventListeners(){const e=this.container.querySelector("#reader-settings-panel");if(!e)return;const t=e.querySelector("#reader-font-size");t&&t.addEventListener("input",l=>{const c=parseInt(l.target.value);this.config.fontSize=c,this.updateFontSizeDisplay(c),this.applySettings()});const r=e.querySelector("#reader-line-height");r&&r.addEventListener("input",l=>{const c=parseFloat(l.target.value);this.config.lineHeight=c,this.updateLineHeightDisplay(c),this.applySettings()});const o=e.querySelector("#reader-max-width");o&&o.addEventListener("input",l=>{const c=parseInt(l.target.value);this.config.maxWidth=c,this.updateMaxWidthDisplay(c),this.applySettings()});const n=e.querySelector("#reader-theme");n&&n.addEventListener("change",l=>{this.config.theme=l.target.value,this.applySettings()});const i=e.querySelector("#reader-separator-style");i&&i.addEventListener("change",l=>{this.config.separatorStyle=l.target.value,this.applySettings()});const s=e.querySelector("#reader-show-all-levels");s&&s.addEventListener("change",l=>{this.config.showAllLevels=l.target.checked,this.contentNodes=this.analyzeProjectContent();const c=this.container.querySelector(".reader-content-area");if(c&&(this.readerEditor.destroy(),c.innerHTML=this.generateContent(),this.readerEditor.initialize(),this.config.showTOC)){const d=this.container.querySelector(".reader-toc");d&&(d.innerHTML=this.generateTOCContent())}this.refreshStyles(),this.saveReaderConfig()})}updateFontSizeDisplay(e){const t=this.container.querySelector("#reader-font-size + .setting-value");t&&(t.textContent=`${e}px`)}updateLineHeightDisplay(e){const t=this.container.querySelector("#reader-line-height + .setting-value");t&&(t.textContent=e.toString())}updateMaxWidthDisplay(e){const t=this.container.querySelector("#reader-max-width + .setting-value");t&&(t.textContent=`${e}px`)}applySettings(){const e=this.container.querySelector(".reader-content");e&&(e.style.fontSize=`${this.config.fontSize}px`,e.style.lineHeight=this.config.lineHeight.toString(),e.style.maxWidth=`${this.config.maxWidth}px`),this.container.className=`reader-container reader-theme-${this.config.theme}`,this.saveReaderConfig()}resetSettings(){this.config={showTOC:!0,showAllLevels:!1,fontSize:16,lineHeight:1.6,maxWidth:800,theme:"light",separatorStyle:"standard"},this.applySettings()}buildClickMappings(){this.clickMappings=[],this.container.querySelectorAll("[data-node-id]").forEach(t=>{const r=t.dataset.nodeId;r&&this.clickMappings.push({nodeId:r,element:t,startOffset:0,endOffset:0})})}toggleTOC(){this.config.showTOC=!this.config.showTOC;const e=this.container.querySelector(".reader-toc");e&&(e.style.display=this.config.showTOC?"block":"none"),this.saveReaderConfig()}generateSettingsPanel(){return`
            <div id="reader-settings-panel" class="reader-settings-panel" style="display: none;">
                <div class="settings-panel-content">
                    <h3>Reader Settings</h3>
                    
                    <div class="settings-group">
                        <label for="reader-font-size">Font Size:</label>
                        <input type="range" id="reader-font-size" min="12" max="24" step="1" value="${this.config.fontSize}">
                        <span class="setting-value">${this.config.fontSize}px</span>
                    </div>
                    
                    <div class="settings-group">
                        <label for="reader-line-height">Line Height:</label>
                        <input type="range" id="reader-line-height" min="1.2" max="2.0" step="0.1" value="${this.config.lineHeight}">
                        <span class="setting-value">${this.config.lineHeight}</span>
                    </div>
                    
                    <div class="settings-group">
                        <label for="reader-max-width">Content Width:</label>
                        <input type="range" id="reader-max-width" min="600" max="3200" step="50" value="${this.config.maxWidth}">
                        <span class="setting-value">${this.config.maxWidth}px</span>
                    </div>
                    
                    <div class="settings-group">
                        <label for="reader-theme">Theme:</label>
                        <select id="reader-theme" value="${this.config.theme}">
                            <option value="light" ${this.config.theme==="light"?"selected":""}>Light</option>
                            <option value="dark" ${this.config.theme==="dark"?"selected":""}>Dark</option>
                            <option value="sepia" ${this.config.theme==="sepia"?"selected":""}>Sepia</option>
                        </select>
                    </div>
                    
                    <div class="settings-group">
                        <label for="reader-separator-style">Separator Style:</label>
                        <select id="reader-separator-style" value="${this.config.separatorStyle}">
                            <option value="minimal" ${this.config.separatorStyle==="minimal"?"selected":""}>Minimal</option>
                            <option value="standard" ${this.config.separatorStyle==="standard"?"selected":""}>Standard</option>
                            <option value="bold" ${this.config.separatorStyle==="bold"?"selected":""}>Bold</option>
                        </select>
                    </div>
                    
                    <div class="settings-group">
                        <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                            <input type="checkbox" id="reader-show-all-levels" ${this.config.showAllLevels?"checked":""}>
                            Show all hierarchy levels
                        </label>
                        <div style="font-size: 0.8rem; color: #6b7280; margin-top: 0.25rem;">
                            When unchecked, shows only the deepest available content
                        </div>
                    </div>
                    

                    
                    <div class="settings-buttons">
                        <button id="reader-settings-reset">Reset to Defaults</button>
                        <button id="reader-settings-close">Close</button>
                    </div>
                </div>
            </div>
        `}toggleSettings(){const e=this.container.querySelector("#reader-settings-panel");if(e){const t=e.style.display!=="none";this.isSettingsPanelOpen=!t,e.style.display=t?"none":"block",this.isSettingsPanelOpen&&this.setupSettingsEventListeners()}}openActionsConfigModal(){try{D(()=>h(null,null,function*(){const{showGenericModal:e}=yield import("./index-BTgsZSUm.js");return{showGenericModal:e}}),__vite__mapDeps([2,0,1,3])).then(({showGenericModal:e})=>{let t=null,r=!1;const o=e({content:this.renderActionsConfigModalContent(),actions:[{id:"reset",label:"Reset to Defaults",type:"secondary",handler:()=>h(this,null,function*(){confirm("Reset all actions to defaults? This will remove any custom actions.")&&(yield this.readerEditor.resetToDefaults(),this.refreshActionsList(),this.clearActionEditor(),t=null,r=!1,alert("Actions reset to defaults successfully!"))})},{id:"cancel",label:"Cancel",type:"secondary",handler:()=>h(this,null,function*(){if(r&&!confirm("You have unsaved changes. Cancel without saving?"))throw new Error("Cancel prevented");o.close()})},{id:"save",label:"Save Changes",type:"primary",handler:()=>h(this,null,function*(){const n=document.getElementById("action-editor-form"),i=n==null?void 0:n.getAttribute("data-action-id");i&&(yield this.saveCurrentAction(i)),this.updateActionButtons(),r=!1,alert("All changes saved successfully!"),o.close()})}]},{title:"🔧 Configure AI Actions",maxWidth:"1200px",width:"90vw"},{onOpen:()=>{this.setupActionsConfigEventListeners(t,r,n=>{t=n},n=>{r=n})},onClose:()=>{}})})}catch(e){console.error("Failed to open actions config modal:",e)}}renderActionsConfigModalContent(){return this.renderActionsConfigModalBody()}renderActionsConfigModalBody(){return`
            <style>
                .actions-config-modal {
                    width: 90vw;
                    max-width: 1200px;
                    max-height: 90vh;
                    display: flex;
                    flex-direction: column;
                }
                .actions-config-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1.5rem 2rem;
                    border-bottom: 1px solid #e5e7eb;
                    background-color: #f9fafb;
                }
                .actions-config-body {
                    flex: 1;
                    padding: 2rem;
                    display: flex;
                    gap: 2rem;
                }
                .actions-list {
                    flex: 1;
                    min-width: 300px;
                }
                .action-item {
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    margin-bottom: 1rem;
                    background-color: white;
                    transition: all 0.2s;
                }
                .action-item:hover {
                    border-color: #3b82f6;
                    box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
                }
                .action-item.selected {
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                .action-header {
                    padding: 1rem 1.5rem;
                    border-bottom: 1px solid #f3f4f6;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    cursor: pointer;
                }
                .action-title {
                    font-weight: 600;
                    color: #1f2937;
                    margin: 0;
                }
                .action-meta {
                    display: flex;
                    gap: 0.5rem;
                    align-items: center;
                    font-size: 0.875rem;
                    color: #6b7280;
                }
                .action-toggle {
                    position: relative;
                    width: 44px;
                    height: 24px;
                    background-color: #d1d5db;
                    border-radius: 12px;
                    cursor: pointer;
                    transition: background-color 0.2s;
                }
                .action-toggle.enabled {
                    background-color: #3b82f6;
                }
                .action-toggle::after {
                    content: '';
                    position: absolute;
                    top: 2px;
                    left: 2px;
                    width: 20px;
                    height: 20px;
                    background-color: white;
                    border-radius: 50%;
                    transition: transform 0.2s;
                }
                .action-toggle.enabled::after {
                    transform: translateX(20px);
                }
                .editor-panel {
                    flex: 2;
                    min-width: 500px;
                    border: 1px solid #e5e7eb;
                    border-radius: 12px;
                    background-color: white;
                    height: fit-content;
                }
                .editor-header {
                    padding: 1rem 1.5rem;
                    border-bottom: 1px solid #f3f4f6;
                    background-color: #f9fafb;
                    border-radius: 12px 12px 0 0;
                }
                .editor-content {
                    padding: 1.5rem;
                }
                .field-group {
                    margin-bottom: 1.5rem;
                }
                .field-label {
                    display: block;
                    font-weight: 600;
                    color: #374151;
                    margin-bottom: 0.5rem;
                    font-size: 0.875rem;
                }
                .field-input {
                    width: 100%;
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    font-size: 0.875rem;
                    transition: border-color 0.2s;
                }
                .field-input:focus {
                    outline: none;
                    border-color: #3b82f6;
                    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
                }
                .field-textarea {
                    min-height: 200px;
                    resize: vertical;
                    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                    font-size: 0.8rem;
                    line-height: 1.5;
                }
                .field-select {
                    width: 100%;
                    padding: 0.75rem;
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    background-color: white;
                    font-size: 0.875rem;
                }
                .placeholders-help {
                    background-color: #eff6ff;
                    border: 1px solid #bfdbfe;
                    border-radius: 8px;
                    padding: 1rem;
                    margin-top: 1rem;
                }
                .placeholders-title {
                    font-weight: 600;
                    color: #1e40af;
                    margin-bottom: 0.5rem;
                    font-size: 0.875rem;
                }
                .placeholders-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
                    gap: 0.5rem;
                }
                .placeholder-item {
                    background-color: #dbeafe;
                    color: #1e40af;
                    padding: 0.25rem 0.5rem;
                    border-radius: 4px;
                    font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
                    font-size: 0.75rem;
                    cursor: pointer;
                    transition: background-color 0.2s;
                }
                .placeholder-item:hover {
                    background-color: #bfdbfe;
                }
                .action-buttons {
                    display: flex;
                    gap: 0.75rem;
                    justify-content: flex-end;
                    padding: 1.5rem 2rem;
                    border-top: 1px solid #e5e7eb;
                    background-color: #f9fafb;
                }
                .btn {
                    padding: 0.75rem 1.5rem;
                    border: none;
                    border-radius: 8px;
                    font-size: 0.875rem;
                    font-weight: 500;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .btn-primary {
                    background-color: #3b82f6;
                    color: white;
                }
                .btn-primary:hover {
                    background-color: #2563eb;
                }
                .btn-primary:disabled {
                    background-color: #9ca3af;
                    cursor: not-allowed;
                }
                .btn-secondary {
                    background-color: #6b7280;
                    color: white;
                }
                .btn-secondary:hover {
                    background-color: #4b5563;
                }
                .btn-danger {
                    background-color: #ef4444;
                    color: white;
                }
                .btn-danger:hover {
                    background-color: #dc2626;
                }
                .btn-success {
                    background-color: #10b981;
                    color: white;
                }
                .btn-success:hover {
                    background-color: #059669;
                }
                .no-selection {
                    text-align: center;
                    color: #6b7280;
                    padding: 2rem;
                    font-style: italic;
                }
                .field-description {
                    font-size: 0.75rem;
                    color: #6b7280;
                    margin-top: 0.25rem;
                }
                .order-controls {
                    display: flex;
                    gap: 0.5rem;
                    margin-left: auto;
                }
                .order-btn {
                    width: 24px;
                    height: 24px;
                    border: 1px solid #d1d5db;
                    background-color: white;
                    border-radius: 4px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 0.75rem;
                    color: #6b7280;
                }
                .order-btn:hover {
                    background-color: #f3f4f6;
                    border-color: #9ca3af;
                }
            </style>
            <div class="actions-config-modal">
                <div class="actions-config-body">
                    <div class="actions-list">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                            <h3 style="margin: 0; color: #374151;">Actions</h3>
                            <button id="add-new-action" class="btn btn-success" style="padding: 0.5rem 1rem; font-size: 0.8rem;">+ Add New</button>
                        </div>
                        <div id="actions-list-container">
                            ${this.readerEditor.getAllActions().map(t=>this.renderActionListItem(t)).join("")}
                        </div>
                    </div>
                    <div class="editor-panel">
                        <div class="editor-header">
                            <h3 style="margin: 0; color: #374151;">Edit Action</h3>
                        </div>
                        <div class="editor-content">
                            <div id="editor-content-area">
                                <div class="no-selection">
                                    Select an action to edit its configuration
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}renderActionListItem(e){return`
            <div class="action-item" data-action-id="${e.id}">
                <div class="action-header" onclick="selectAction('${e.id}')">
                    <div>
                        <h4 class="action-title">${e.title}</h4>
                        <div class="action-meta">
                            <span>Model: ${e.model}</span>
                            <span>•</span>
                            <span>Order: ${e.order}</span>
                        </div>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <div class="order-controls">
                            <button class="order-btn" onclick="moveActionUp('${e.id}')" title="Move up">↑</button>
                            <button class="order-btn" onclick="moveActionDown('${e.id}')" title="Move down">↓</button>
                        </div>
                        <div class="action-toggle ${e.enabled?"enabled":""}" 
                             onclick="toggleAction('${e.id}')" 
                             data-enabled="${e.enabled}"></div>
                    </div>
                </div>
            </div>
        `}renderActionEditor(e){const t=["{{selected}}","{{content}}","{{title}}","{{node_path}}","{{project_title}}","{{level}}","{{children_count}}","{{context}}","{{word_count}}",'{{input "Title"}}'];return`
            <form id="action-editor-form" data-action-id="${e.id}">
                <div class="field-group">
                    <label class="field-label" for="action-title">Action Title</label>
                    <input type="text" id="action-title" class="field-input" value="${e.title}" required>
                    <div class="field-description">The text that appears on the action button</div>
                </div>
                
                <div class="field-group">
                    <label class="field-label" for="action-description">Description</label>
                    <input type="text" id="action-description" class="field-input" value="${e.description||""}" placeholder="Optional description for this action">
                    <div class="field-description">Help text that appears when hovering over the button</div>
                </div>
                
                <div class="field-group">
                    <label class="field-label" for="action-model">AI Model</label>
                    <select id="action-model" class="field-select">
                        <option value="creator" ${e.model==="creator"?"selected":""}>Creator (Creative, detailed responses)</option>
                        <option value="editor" ${e.model==="editor"?"selected":""}>Editor (Precise, concise editing)</option>
                        <option value="rater" ${e.model==="rater"?"selected":""}>Rater (Analysis and evaluation)</option>
                    </select>
                    <div class="field-description">Choose the AI model that best fits this action's purpose</div>
                </div>
                
                <div class="field-group">
                    <label class="field-label" for="action-order">Display Order</label>
                    <input type="number" id="action-order" class="field-input" value="${e.order}" min="1" required>
                    <div class="field-description">Controls the order of action buttons (1 = first)</div>
                </div>
                
                <div class="field-group">
                    <label class="field-label" for="action-prompt">Prompt Template</label>
                    <textarea id="action-prompt" class="field-input field-textarea" required>${e.prompt}</textarea>
                    <div class="field-description">Use placeholders like {{selected}} to insert dynamic content</div>
                    
                    <div class="placeholders-help">
                        <div class="placeholders-title">Available Placeholders (click to insert):</div>
                        <div class="placeholders-grid">
                            ${t.map(r=>`<span class="placeholder-item" onclick="insertPlaceholder('${r}')">${r}</span>`).join("")}
                        </div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 0.75rem; margin-top: 2rem;">
                    <button type="button" id="delete-action" class="btn btn-danger" ${e.id.startsWith("custom-")?"":'disabled title="Default actions cannot be deleted"'}>Delete Action</button>
                </div>
            </form>
        `}setupActionsConfigEventListeners(e,t,r,o){window.selectAction=i=>{t&&!confirm("You have unsaved changes. Continue without saving?")||(r(i),this.selectActionInModal(i),o(!1))},window.toggleAction=i=>h(this,null,function*(){var s;yield this.readerEditor.updateAction(i,{enabled:!((s=this.readerEditor.getAllActions().find(l=>l.id===i))!=null&&s.enabled)}),this.refreshActionsList(),o(!0)}),window.moveActionUp=i=>h(this,null,function*(){yield this.moveAction(i,-1),this.refreshActionsList(),o(!0)}),window.moveActionDown=i=>h(this,null,function*(){yield this.moveAction(i,1),this.refreshActionsList(),o(!0)}),window.insertPlaceholder=i=>{const s=document.getElementById("action-prompt");if(s){const l=s.selectionStart,c=s.selectionEnd,d=s.value;s.value=d.substring(0,l)+i+d.substring(c),s.focus(),s.setSelectionRange(l+i.length,l+i.length),o(!0)}};const n=document.getElementById("add-new-action");n==null||n.addEventListener("click",()=>h(this,null,function*(){yield this.addNewAction(),this.refreshActionsList(),o(!0)})),document.addEventListener("input",i=>{i.target.closest("#action-editor-form")&&o(!0)}),document.addEventListener("click",i=>{const s=i.target;if(s.id==="save-current-action"){const l=document.getElementById("action-editor-form"),c=l==null?void 0:l.getAttribute("data-action-id");c&&this.saveCurrentAction(c).then(()=>{o(!1)})}if(s.id==="delete-action"){const l=document.getElementById("action-editor-form"),c=l==null?void 0:l.getAttribute("data-action-id");c&&confirm("Are you sure you want to delete this action?")&&this.readerEditor.deleteAction(c).then(()=>{this.refreshActionsList(),r(null),this.clearActionEditor(),o(!0)})}})}selectActionInModal(e){document.querySelectorAll(".action-item").forEach(n=>n.classList.remove("selected"));const r=document.querySelector(`[data-action-id="${e}"]`);r==null||r.classList.add("selected");const o=this.readerEditor.getAllActions().find(n=>n.id===e);if(o){const n=document.getElementById("editor-content-area");n&&(n.innerHTML=this.renderActionEditor(o))}}refreshActionsList(){const e=document.getElementById("actions-list-container");if(e){const t=this.readerEditor.getAllActions();e.innerHTML=t.map(r=>this.renderActionListItem(r)).join("")}}clearActionEditor(){const e=document.getElementById("editor-content-area");e&&(e.innerHTML=`
                <div class="no-selection">
                    Select an action to edit its configuration
                </div>
            `)}saveCurrentAction(e){return h(this,null,function*(){if(!document.getElementById("action-editor-form"))return;const r={title:document.getElementById("action-title").value,description:document.getElementById("action-description").value,model:document.getElementById("action-model").value,order:parseInt(document.getElementById("action-order").value),prompt:document.getElementById("action-prompt").value};yield this.readerEditor.updateAction(e,r),this.refreshActionsList()})}addNewAction(){return h(this,null,function*(){const e={title:"New Action",prompt:`Please modify the following text:

{{selected}}

Modified text:`,model:"editor",enabled:!0,order:this.readerEditor.getAllActions().length+1,description:"Custom action"},t=yield this.readerEditor.addAction(e);setTimeout(()=>{window.selectAction(t)},100)})}moveAction(e,t){return h(this,null,function*(){const r=this.readerEditor.getAllActions(),o=r.find(s=>s.id===e);if(!o)return;const n=o.order+t;if(n<1||n>r.length)return;const i=r.find(s=>s.order===n);i&&(yield this.readerEditor.updateAction(i.id,{order:o.order})),yield this.readerEditor.updateAction(e,{order:n})})}updateActionButtons(){const e=this.container.querySelector("#reader-action-buttons"),t=this.container.querySelector("#action-buttons-container");if(!e||!t)return;const r=this.readerEditor.getEnabledActions();t.innerHTML="";const o=document.createElement("div");o.className="selection-mode-toggle",o.innerHTML=`
            <label class="selection-mode-label">AI Capture:</label>
            <select id="selection-mode-select" class="selection-mode-select">
                <option value="words">Words</option>
                <option value="sentences" selected>Sentences</option>
                <option value="paragraphs">Paragraphs</option>
            </select>
        `,t.appendChild(o);const n=document.createElement("div");n.className="action-buttons-separator",t.appendChild(n);const i=document.createElement("button");i.className="reader-action-btn reader-undo-btn",i.textContent="↶ Undo",i.setAttribute("data-action-id","undo"),i.setAttribute("data-original-text","↶ Undo"),i.title="Undo the last AI replacement",i.disabled=!0,t.appendChild(i),r.forEach(s=>{const l=document.createElement("button");l.className="reader-action-btn",l.textContent=s.title,l.setAttribute("data-action-id",s.id),l.setAttribute("data-original-text",s.title),l.title=s.description||s.title,t.appendChild(l)}),this.setupSelectionModeToggle(),this.updateUndoButtonState(),e.style.display="block"}setupSelectionModeToggle(){const e=this.container.querySelector("#selection-mode-select");if(!e)return;const t=this.readerEditor.getCurrentSelectionMode();e.value=t,e.addEventListener("change",()=>{const r=e.value;this.readerEditor.setSelectionMode(r)})}updateUndoButtonState(){const e=this.container.querySelector('[data-action-id="undo"]');if(!e)return;const t=this.readerEditor.canUndo();e.disabled=!t,t?(e.style.opacity="1",e.style.cursor="pointer"):(e.style.opacity="0.5",e.style.cursor="not-allowed")}hideActionButtons(){const e=this.container.querySelector("#reader-action-buttons");e&&(e.style.display="none")}close(){this.stopListeningForUpdates(),this.isSettingsPanelOpen=!1;const e=document.getElementById("reader-styles");e&&e.remove(),this.container.innerHTML="",this.container.style.display="none",this.hasBeenRendered=!1,W===this&&(W=null)}show(){return h(this,null,function*(){this.container.style.display="block",yield this.loadReaderConfig(),this.hasBeenRendered||this.render(),this.applySettings(),this.startListeningForUpdates()})}hide(){this.container.style.display="none",this.stopListeningForUpdates(),this.readerEditor&&this.readerEditor.destroy()}getContainer(){return this.container}startListeningForUpdates(){this.isListeningForUpdates||(this.isListeningForUpdates=!0,this.projectManager.on("nodeGenerationComplete",this.boundHandleNodeGenerationComplete),this.projectManager.on("nodeSummaryGenerated",this.boundHandleNodeSummaryGenerated),this.projectManager.on("project-loaded",this.boundHandleProjectUpdate))}stopListeningForUpdates(){this.isListeningForUpdates&&(this.isListeningForUpdates=!1,this.projectManager.off("nodeGenerationComplete",this.boundHandleNodeGenerationComplete),this.projectManager.off("nodeSummaryGenerated",this.boundHandleNodeSummaryGenerated),this.projectManager.off("project-loaded",this.boundHandleProjectUpdate))}handleNodeGenerationComplete(e){if(e.success){if(console.log(`📖 Reader auto-updating content for: "${e.node.title}" (${e.nodeId})`),!this.contentNodes.find(r=>r.id===e.nodeId)){console.log(`🆕 New node detected: "${e.node.title}" - rebuilding reader content`),this.refreshReaderForNewNodes();return}this.updateNodeContentInReader(e.nodeId,e.node.content)}else console.log(`❌ Node generation failed for: "${e.node.title}" (${e.nodeId}) - Reader not updated`)}handleNodeSummaryGenerated(e){}updateNodeContentInReader(e,t){var r;if(this.readerEditor){const o=(r=this.readerEditor.nodeEditors)==null?void 0:r.get(e);if(o){const n=o.element.querySelector(".text-editor-with-highlighting");n&&document.activeElement!==n?(o.editor.setText(t),o.originalContent=t,o.isDirty=!1,this.updateNodeWordCount(e,t),console.log(`📝 Reader content updated successfully for node: ${e}`)):console.log(`⏭️ Reader update skipped - node ${e} is currently being edited by user`)}else{console.log(`⚠️ Reader update failed - no editor found for node: ${e}`);const n=this.readerEditor.nodeEditors?Array.from(this.readerEditor.nodeEditors.keys()):[];console.log("🔍 Available editors in reader:",n)}}else console.log("⚠️ Reader update failed - ReaderEditor not initialized")}updateNodeWordCount(e,t){const r=this.contentNodes.find(o=>o.id===e);if(r){const o=this.calculateWordCount(t);r.wordCount=o,r.estimatedReadingTime=Math.ceil(o/200),r.hasContent=!!(t&&t.trim()),this.config.showTOC&&this.refreshTOC(),console.log(`📊 Updated word count for "${r.title}": ${o} words`)}}refreshTOC(){const e=this.container.querySelector(".reader-toc");e&&(e.innerHTML=this.generateTOCContent(),console.log("🔄 TOC refreshed with updated word counts"))}refreshReaderForNewNodes(){let e=new Map;this.readerEditor&&(e=this.readerEditor.preserveAllContent()),this.contentNodes=this.analyzeProjectContent();const t=this.container.querySelector(".reader-content-area");t&&(t.innerHTML=this.generateContent()),this.config.showTOC&&this.refreshTOC(),this.buildClickMappings(),this.readerEditor&&this.readerEditor.initialize(e)}handleProjectUpdate(){console.log("📋 Project structure changed - checking for new nodes");const e=new Set(this.contentNodes.map(i=>i.id)),t=this.analyzeProjectContent(),r=new Set(t.map(i=>i.id)),o=t.some(i=>!e.has(i.id)),n=this.contentNodes.some(i=>!r.has(i.id));o||n?(console.log(`🔄 Project structure changed: ${t.length} total nodes (was ${this.contentNodes.length})`),this.refreshReaderForNewNodes()):console.log("✅ No structural changes detected")}preserveReadingPosition(){}refreshContent(){}}let W=null;function to(a,e){return h(this,null,function*(){let t=document.getElementById("reader-container");return t||(t=document.createElement("div"),t.id="reader-container",document.body.appendChild(t)),(!W||W.projectManager!==a)&&(W&&(W.hide(),W=null),W=new eo(a,t,e)),yield W.show(),W})}let v=null,E=null,K=new Set,xe=!0,Ce=!1,H=0,F=[];function Vt(){const a=document.getElementById("globalAbortBtn");a&&(a.style.display="inline-block")}function Me(){const a=document.getElementById("globalAbortBtn");a&&(a.style.display="none")}function ut(){return h(this,null,function*(){try{const{StorageService:a}=yield D(()=>h(null,null,function*(){const{StorageService:t}=yield Promise.resolve().then(()=>Q);return{StorageService:t}}),void 0);yield(yield a.getInstance()).set("expert_app_collapsed_nodes",Array.from(K))}catch(a){console.warn("Failed to save collapsed nodes state:",a)}})}function ro(){return h(this,null,function*(){try{const{StorageService:a}=yield D(()=>h(null,null,function*(){const{StorageService:r}=yield Promise.resolve().then(()=>Q);return{StorageService:r}}),void 0),t=yield(yield a.getInstance()).get("expert_app_collapsed_nodes");t&&(K=new Set(t))}catch(a){console.warn("Failed to load collapsed nodes state:",a),K=new Set}})}function gt(){return h(this,null,function*(){try{const{StorageService:a}=yield D(()=>h(null,null,function*(){const{StorageService:t}=yield Promise.resolve().then(()=>Q);return{StorageService:t}}),void 0);yield(yield a.getInstance()).set("expert_app_checkbox_states",{includeContent:xe,recursive:Ce})}catch(a){console.warn("Failed to save checkbox states:",a)}})}function oo(){return h(this,null,function*(){try{const{StorageService:a}=yield D(()=>h(null,null,function*(){const{StorageService:r}=yield Promise.resolve().then(()=>Q);return{StorageService:r}}),void 0),t=yield(yield a.getInstance()).get("expert_app_checkbox_states");t&&(xe=t.includeContent,Ce=t.recursive)}catch(a){console.warn("Failed to load checkbox states:",a)}})}function he(a){v=a,Wt(a),(!E||!v.findNodeById(E))&&(E=v.rootNode.id);const e=x("project-tree"),t=x("node-details");e.innerHTML="",t.innerHTML="",Kt(),U(),X()}function Wt(a){const e=c=>{U(),Vt(),X()},t=c=>{if(!a.isAnyNodeGenerating())he(a),te(),me();else if(U(),E){const u=a.findNodeById(E);if(u){const g=document.getElementById("node-content"),f=document.getElementById("node-context");g&&(g.value=u.content),f&&(f.value=u.context)}}setTimeout(()=>{a.isAnyNodeGenerating()||(te(),me(),Me())},200)},r=c=>{a.isAnyNodeGenerating()?U():he(a)},o=c=>{alert(`An error occurred: ${c}`),he(a)},n=c=>{!c.message||c.message.trim()===""?(te(),me(),setTimeout(()=>{a.isAnyNodeGenerating()||(te(),me(),Me())},100)):te({operations:{message:c.message,current:c.current,total:c.total}})},i=c=>{const{progress:d}=c,u={message:`Iteration: ${d.iteration} / ${d.maxIterations}`,current:d.iteration,total:d.maxIterations},g={message:`Stage: ${d.type.charAt(0).toUpperCase()+d.type.slice(1)} (${d.step} / ${d.totalStepsInIteration})`,current:d.step,total:d.totalStepsInIteration};let f="";switch(d.type){case"creator":f="AI is generating content...";break;case"rater":f=`AI is evaluating against criterion: ${d.payload.criterion}`;break;case"editor":f="AI is compiling feedback for the next iteration...";break}te({iterations:u,stages:g,detail:f})},s=c=>{if(c.nodeId===E){const d=x("node-context");d&&(d.value=c.summary)}},l=()=>{he(a)};a._completionListener&&(a.off("nodeGenerationStarted",a._generationStartedListener),a.off("nodeGenerationComplete",a._completionListener),a.off("error",a._errorListener),a.off("high-level-progress",a._highLevelProgressListener),a.off("loop-progress",a._loopProgressListener),a.off("nodeSummaryGenerated",a._summaryGeneratedListener),a.off("project-loaded",a._projectLoadedListener)),a._generationStartedListener=e,a._completionListener=t,a._errorListener=o,a._highLevelProgressListener=n,a._loopProgressListener=i,a._summaryGeneratedListener=s,a._projectLoadedListener=l,a.on("nodeGenerationStarted",e),a.on("nodeGenerationComplete",t),a.on("nodeGenerationAborted",r),a.on("error",o),a.on("high-level-progress",n),a.on("loop-progress",i),a.on("nodeSummaryGenerated",s),a.on("project-loaded",l)}function Kt(){const a=document.getElementById("active-profile-selector");if(!a)return;const e=V(),t=(e==null?void 0:e.getProfileNames())||[],r=(e==null?void 0:e.getLastUsedProfileName())||"default";a.innerHTML=t.map(o=>`<option value="${o}" ${r===o?"selected":""}>${o}</option>`).join("")}function X(){const a=x("node-details");if(a.innerHTML="",!v||!E){a.innerHTML='<div class="placeholder">No node selected.</div>';return}const e=v.findNodeById(E);if(!e){a.innerHTML=`<div class="placeholder">Error: Node with ID "${E}" not found.</div>`;return}v._listenersSetup||(Wt(v),v._listenersSetup=!0);const t=V();t!=null&&t.getProfileNames();const r=document.createElement("div");r.className="node-details-container",r.innerHTML=`
        <style>
            .node-details-container {
                padding: 1rem;
                display: flex;
                flex-direction: column;
                gap: 1.5rem;
                height: 100%;
                box-sizing: border-box;
            }
            .node-details-header {
                padding-bottom: 1rem;
                border-bottom: 1px solid var(--border-color);
            }
            .node-details-header h2 {
                font-size: 2rem;
                font-weight: bold;
                margin: 0;
            }
            .node-details-header .node-path {
                font-size: 0.9rem;
                color: #6c757d;
                margin-top: 0.25rem;
            }
            .node-section {
                background-color: #ffffff;
                border: 1px solid var(--border-color);
                border-radius: 12px;
                padding: 1.5rem;
                display: flex;
                flex-direction: column;
                gap: 0.75rem;
                box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            }
            .node-section label {
                font-weight: bold;
                font-size: 1.1rem;
                color: #343a40;
            }
            .large-textarea {
                width: 100%;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                padding: 0.75rem;
                font-size: 1rem;
                line-height: 1.5;
                background-color: var(--input-bg);
                resize: vertical;
            }
            .node-actions {
                display: flex;
                justify-content: flex-end;
                margin-top: 0.5rem;
            }
            .settings-bar {
                display: flex;
                align-items: center;
                gap: 0.75rem;
                width: 100%;
            }
            .settings-bar label {
                font-size: 1rem;
                white-space: nowrap;
            }
            .settings-bar select, .settings-bar input {
                flex-grow: 1;
                padding: 0.5rem;
                border: 1px solid var(--border-color);
                border-radius: 8px;
            }
            .settings-bar input[type="number"] {
                flex-grow: 0;
                width: 70px;
            }
            .prompt-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 0.75rem;
            }
        </style>
        <div class="node-details-header">
            <h2 id="node-title-display" contenteditable="true">${e.title}</h2>
            <div class="node-path">Path: ${v.getNodePath(e.id)}</div>
            ${e.level===0?`<div class="template-info" style="font-size: 0.9rem; color: #6c757d; margin-top: 0.25rem;">Template: <strong>${v.template.name}</strong></div>`:""}
            <div style="margin-top: 1rem; display: flex; gap: 1rem;">
                <button id="delete-node-btn" class="button button-secondary" style="background-color: #dc3545; color: white; border-color: #dc3545;">
                    ${e.level===0?"Delete Project":"Delete Node"}
                </button>
                ${e.children.length>0?`
                    <button id="delete-subnodes-btn" class="button button-secondary" style="background-color: #fd7e14; color: white; border-color: #fd7e14;">
                        Delete All Subnodes
                    </button>
                `:""}
                <button id="export-node-btn" class="button button-secondary" style="background-color: #6366f1; color: white; border-color: #6366f1;">
                    📤 Export
                </button>
                <button id="import-node-btn" class="button button-secondary" style="background-color: #10b981; color: white; border-color: #10b981;">
                    📥 Import
                </button>
                <button id="chat-node-btn" class="button button-secondary" style="background-color: #f59e0b; color: white; border-color: #f59e0b;">
                    💬 Chat
                </button>
            </div>
        </div>

        <div class="node-section generation-section">
            <div class="prompt-header">
                <label for="node-generation-prompt">Generation</label>
                <div class="placeholder-buttons">
                    <button class="placeholder-btn" data-placeholder="path" title="View path placeholder value">{{path}}</button>
                    <button class="placeholder-btn" data-placeholder="context" title="View context placeholder value">{{context}}</button>
                    <button class="placeholder-btn" data-placeholder="title" title="View title placeholder value">{{title}}</button>
                    <button class="placeholder-btn" data-placeholder="content" title="View content placeholder value">{{content}}</button>
                    <button class="placeholder-btn" data-placeholder="draftorfresh" title="View draftorfresh placeholder value">{{draftorfresh}}</button>
                    ${e.isLeaf?"":'<button class="placeholder-btn" data-placeholder="child_level_name" title="View child level name placeholder value">{{child_level_name}}</button>'}
                    ${e.isLeaf?"":'<button class="placeholder-btn" data-placeholder="count" title="View count placeholder value">{{count}}</button>'}
                    <button id="default-prompt-btn" class="button button-secondary">Default</button>
                </div>
            </div>
            <textarea id="node-generation-prompt" class="large-textarea" rows="8" placeholder="Enter a prompt here to generate content from scratch...">${e.generationPrompt||""}</textarea>
            
            <!-- Generation Controls -->
            <div style="display: flex; gap: 1rem; align-items: flex-start; margin-top: 1rem;">
                <!-- Left side: Single generation controls -->
                <div style="display: flex; flex-direction: column; gap: 0.75rem; min-width: 250px;">
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <div style="display: flex; align-items: center; gap: 0.5rem;">
                            <label for="generation-count-input" style="font-size: 0.9rem; white-space: nowrap;">Count:</label>
                            <input type="number" id="generation-count-input" min="1" max="20" value="${e.generationChildrenCount}" style="width: 70px; padding: 0.5rem; border: 1px solid var(--border-color); border-radius: 4px;">
                        </div>
                        <button id="node-generate-btn" class="button button-primary">Generate</button>
                    </div>
                    
                    ${e.isLeaf?"":`
                        <div style="border-top: 1px solid #e9ecef; padding-top: 0.75rem;">
                            <button id="node-generate-all-btn" class="button" style="width: 100%; margin-bottom: 0.5rem;">Generate All Children</button>
                            <div style="display: flex; gap: 1rem; font-size: 0.9rem;">
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id="include-content-checkbox" ${xe?"checked":""}>
                                    <label for="include-content-checkbox" style="cursor: pointer; user-select: none;">Include content</label>
                                </div>
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <input type="checkbox" id="recursive-checkbox" ${Ce?"checked":""}>
                                    <label for="recursive-checkbox" style="cursor: pointer; user-select: none;">Recursive</label>
                                </div>
                            </div>
                        </div>
                    `}
                </div>
                
                <!-- Right side: Progress bars -->
                <div id="generation-progress-container" style="flex: 1; display: none; min-width: 300px;">
                    <div style="display: flex; flex-direction: column; gap: 0.75rem; padding: 0.75rem; background-color: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;">
                        <div class="progress-tier">
                            <div id="progress-text-operations" style="font-size: 0.9rem; font-weight: 600; color: #495057; margin-bottom: 0.25rem;"></div>
                            <div class="progress-bar-wrapper">
                                <div id="progress-bar-operations" class="progress-bar" style="width: 0%;"></div>
                            </div>
                        </div>
                        
                        <!-- Middle and Bottom Level: Iterations and Stages side by side -->
                        <div style="display: flex; gap: 1rem;">
                            <!-- Left: LoopOrchestrator iterations -->
                            <div class="progress-tier" style="flex: 1;">
                                <div id="progress-text-iterations" style="font-size: 0.85rem; color: #6c757d; margin-bottom: 0.25rem;"></div>
                                <div class="progress-bar-wrapper">
                                    <div id="progress-bar-iterations" class="progress-bar" style="width: 0%;"></div>
                                </div>
                            </div>
                            
                            <!-- Right: Stage within iteration -->
                            <div class="progress-tier" style="flex: 1;">
                                <div id="progress-text-stages" style="font-size: 0.8rem; color: #6c757d; margin-bottom: 0.25rem;"></div>
                                <div class="progress-bar-wrapper">
                                    <div id="progress-bar-stages" class="progress-bar" style="width: 0%;"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="progress-text-detail" style="font-style: italic; color: #6c757d; font-size: 0.75rem; margin-top: 0.25rem;"></div>
                    </div>
                </div>
                
                <style>
                .progress-tier {
                    margin-bottom: 0.25rem;
                }
                .progress-tier:last-of-type {
                    margin-bottom: 0;
                }
                .progress-bar-wrapper {
                    background-color: #e9ecef;
                    border-radius: 6px;
                    height: 16px;
                    overflow: hidden;
                    position: relative;
                }
                .progress-bar {
                    background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
                    height: 100%;
                    border-radius: 6px;
                    transition: width 0.3s ease-in-out;
                    position: relative;
                    min-width: 0;
                }
                .progress-bar::after {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%);
                    animation: progress-shine 2s infinite;
                }
                @keyframes progress-shine {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(100%); }
                }
                .version-nav-btn {
                    background: #f8f9fa;
                    border: 1px solid #dee2e6;
                    color: #495057;
                    border-radius: 4px;
                    width: 28px;
                    height: 28px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 1.1rem;
                    font-weight: bold;
                    transition: all 0.2s;
                }
                .version-nav-btn:hover:not(:disabled) {
                    background: #e9ecef;
                    border-color: #adb5bd;
                    color: #343a40;
                }
                .version-nav-btn:disabled {
                    background: #f8f9fa;
                    border-color: #e9ecef;
                    color: #adb5bd;
                    cursor: not-allowed;
                }
                </style>
            </div>
            
            <!-- Generation Status Display -->
            <div id="generation-status" style="display: none; margin-top: 0.75rem; padding: 0.5rem 0.75rem; background-color: #e8f4fd; border: 1px solid #bee5eb; border-radius: 6px; font-size: 0.9rem; color: #0c5460; font-style: italic;">
                <!-- Status messages will appear here -->
            </div>
        </div>

        <div class="node-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                <label for="node-content">Content</label>
                <div style="display: flex; align-items: center; gap: 1rem;">
                    <div id="version-navigation" style="display: none; align-items: center; gap: 0.5rem; font-size: 0.9rem;">
                        <button id="version-prev-btn" class="version-nav-btn" title="Previous version">‹</button>
                        <span id="version-indicator">Version 1 of 1</span>
                        <button id="version-next-btn" class="version-nav-btn" title="Next version">›</button>
                        <button id="use-this-version-btn" class="button button-primary" style="display: none; padding: 0.25rem 0.5rem; font-size: 0.8rem;">Use This Version</button>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <input type="checkbox" id="show-ratings-checkbox" style="margin: 0;">
                        <label for="show-ratings-checkbox" style="font-weight: normal; font-size: 0.9rem; margin: 0;">Show ratings</label>
                    </div>
                </div>
            </div>
            <div id="content-display-area">
                <textarea id="node-content" class="large-textarea" rows="15" placeholder="Node content will be generated or can be written here...">${e.content||""}</textarea>
                <div id="ratings-display" style="display: none;">
                    <!-- Ratings will be populated here -->
                </div>
            </div>
        </div>
        
        <div class="node-section">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <label for="node-context">Context</label>
                    <button id="context-info-btn" class="info-button" title="Learn about Context features" style="
                        width: 20px; height: 20px; border-radius: 50%; border: 1px solid #6c757d; 
                        background: #f8f9fa; color: #6c757d; font-size: 12px; font-weight: bold;
                        display: inline-flex; align-items: center; justify-content: center;
                        cursor: pointer; margin-left: 4px;
                    ">i</button>
                    <span style="font-size: 0.8rem; color: #6c757d; font-style: italic;">(propagates recursively to all children)</span>
                </div>
                <div style="display: flex; gap: 0.5rem;">
                    <button id="node-extract-context-btn" class="button button-secondary">Extract Context</button>
                </div>
            </div>
            <textarea id="node-context" class="large-textarea" rows="5" placeholder="Additional context information for this node can be written here.">${e.context||""}</textarea>
        </div>


    `,a.appendChild(r);const o=x("node-generation-prompt"),n=x("node-generate-btn"),i=x("default-prompt-btn"),s=x("show-ratings-checkbox");s&&(s.checked=!1,Je(!1)),no(e),e.generationPrompt||(e.generationPrompt=v.getRawGenerationPrompt(e)),o.value=e.generationPrompt;const l=v.isAnyNodeGenerating(),c=e.isGenerating,d=l||e.isPromptGenerating;e.isPromptGenerating?o.placeholder="Generating detailed prompt...":e.generationPrompt?o.placeholder="The prompt for generating content. You can edit it here.":o.placeholder="A detailed prompt was not generated. You can write one here or try expanding the parent node again.";const u=v.getGenerationService().canAbortGeneration();n.disabled=d||u,n.className="button button-primary",n.id="node-generate-btn",i.disabled=d||u;const g=x("node-extract-context-btn");if(g&&(g.disabled=d||u),c?n.innerHTML='<span class="spinner" style="width: 16px; height: 16px; border-width: 2px; vertical-align: middle; margin-right: 8px;"></span> Generating...':u?n.textContent="Generate (Operation in progress)":n.textContent="Generate",!e.isLeaf){const b=x("node-generate-all-btn");b&&(b.className="button",b.innerHTML="Generate All Children",b.id="node-generate-all-btn",b.disabled=u,u?b.title="Operation in progress. Use the global abort button to cancel.":e.getState()==="Empty"?b.title="This node has no content. Clicking will show instructions.":b.title="Smart fill: Creates children only if none exist, generates content only for empty nodes. Use 'Include content' and 'Recursive' to control behavior.");const P=x("include-content-checkbox"),I=x("recursive-checkbox");P&&P.addEventListener("change",()=>{xe=P.checked,gt().catch(console.error)}),I&&I.addEventListener("change",()=>{Ce=I.checked,gt().catch(console.error)})}const f=x("node-content"),w=x("node-context"),y=x("node-generation-prompt"),S=x("node-title-display");f&&f.addEventListener("input",()=>{if(v&&E){const b=v.findNodeById(E);b&&(b.content=f.value,clearTimeout(f._saveTimeout),f._saveTimeout=setTimeout(()=>{v.saveToStorage().catch(console.error)},1e3))}}),w&&w.addEventListener("input",()=>{if(v&&E){const b=v.findNodeById(E);b&&(b.context=w.value,clearTimeout(w._saveTimeout),w._saveTimeout=setTimeout(()=>{v.saveToStorage().catch(console.error)},1e3))}}),y&&y.addEventListener("input",()=>{if(v&&E){const b=v.findNodeById(E);b&&(b.generationPrompt=y.value,clearTimeout(y._saveTimeout),y._saveTimeout=setTimeout(()=>{v.saveToStorage().catch(console.error)},1e3))}}),S&&S.addEventListener("input",()=>{if(v&&E){const b=v.findNodeById(E);b&&(b.title=S.textContent||"",clearTimeout(S._saveTimeout),S._saveTimeout=setTimeout(()=>{v.saveToStorage().catch(console.error),U()},1e3))}})}function no(a){F=[],H=0;const e=o=>!o||o.length===0?0:o.reduce((n,i)=>n+i.score,0),t=a.getChosenIteration();F.push({content:a.content,ratings:(t==null?void 0:t.ratings)||null,isCurrent:!0,label:"Current",totalScore:t!=null&&t.ratings?e(t.ratings):0});const r=a.getLatestGenerationSession();r&&r.iterations.length>0&&r.iterations.forEach(o=>{o.wasChosen||F.push({content:o.content,ratings:o.ratings,isCurrent:!1,label:"",timestamp:o.timestamp,totalScore:e(o.ratings)})}),F.sort((o,n)=>n.totalScore-o.totalScore),F.forEach((o,n)=>{o.isCurrent?o.label=`Current (Score: ${o.totalScore})`:o.label=`Version ${n+1} (Score: ${o.totalScore})`}),H=F.findIndex(o=>o.isCurrent),Ze()}function Ze(){const a=document.getElementById("version-navigation"),e=document.getElementById("version-indicator"),t=document.getElementById("version-prev-btn"),r=document.getElementById("version-next-btn"),o=document.getElementById("use-this-version-btn");if(!(!a||!e||!t||!r||!o))if(F.length>1){a.style.display="flex";const n=F[H];e.textContent=n.label,t.disabled=H===0,r.disabled=H===F.length-1,o.style.display=n.isCurrent?"none":"inline-block"}else a.style.display="none"}function ft(a){a==="prev"&&H>0?H--:a==="next"&&H<F.length-1&&H++,Yt(),Ze()}function Yt(){const a=F[H];if(!a)return;const e=document.getElementById("node-content");e&&(e.value=a.content);const t=document.getElementById("show-ratings-checkbox");t!=null&&t.checked&&Jt()}function io(){if(!v||!E)return;const a=v.findNodeById(E),e=F[H];!a||!e||e.isCurrent||(a.content=e.content,v.saveToStorage().catch(console.error),H=0,F[0].content=e.content,Yt(),Ze(),alert("Content updated to selected version!"))}function Je(a){const e=document.getElementById("node-content"),t=document.getElementById("ratings-display");!e||!t||(a?(e.style.display="none",t.style.display="block",Jt()):(e.style.display="block",t.style.display="none"))}function Jt(){const a=document.getElementById("ratings-display");if(!a||!v||!E)return;const e=v.findNodeById(E);if(!e)return;const t=F[H];let r=[],o="Current",n=null;if(t&&t.ratings)r=t.ratings,o=t.label,n=t.timestamp;else if(t&&t.isCurrent){const l=e.getChosenIteration();l&&l.ratings&&(r=l.ratings,n=l.timestamp)}if(!r||r.length===0){a.innerHTML=`
            <div style="padding: 2rem; text-align: center; color: #6c757d; background-color: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;">
                <h4 style="margin: 0 0 1rem 0; color: #495057;">No Ratings Available</h4>
                <p style="margin: 0 0 1rem 0; font-size: 0.9rem;">This ${o.toLowerCase()} content doesn't have any quality ratings yet.</p>
                <p style="margin: 0 0 1.5rem 0; font-size: 0.85rem; color: #868e96;">
                    Ratings are created when content is generated through the AI system. If you edited the content manually, 
                    the previous ratings were cleared since they no longer apply to the modified text.
                </p>
                ${t&&t.isCurrent?`
                    <button id="regenerate-ratings-btn" class="button button-primary" style="padding: 0.5rem 1rem; font-size: 0.9rem;">
                        Generate Ratings for Current Content
                    </button>
                `:""}
            </div>
        `;return}const i=Math.max(...r.map(l=>Math.max(l.score,l.goal)),10);let s=`
        <div style="padding: 1.5rem; background-color: #f8f9fa; border-radius: 8px; border: 1px solid #e9ecef;">
            <h4 style="margin: 0 0 1rem 0; color: #495057;">Quality Ratings for ${o} Content</h4>
            <div style="display: flex; flex-direction: column; gap: 1rem;">
    `;r.forEach(l=>{const c=l.score/i*100,d=l.goal/i*100,u=l.score>=l.goal,g=u?"#28a745":"#dc3545",f=u?"✓":"✗";s+=`
            <div style="margin-bottom: 1rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                    <div style="font-weight: 600; color: #343a40;">${l.criterion}</div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <span style="color: ${g}; font-size: 1.1rem;">${f}</span>
                        <span style="font-weight: 600; color: ${g};">${l.score}/${l.goal}</span>
                    </div>
                </div>
                
                <div style="position: relative; background-color: #e9ecef; border-radius: 6px; height: 24px; overflow: hidden;">
                    <!-- Goal line -->
                    <div style="position: absolute; left: ${d}%; top: 0; bottom: 0; width: 2px; background-color: #ffc107; z-index: 2;"></div>
                    <!-- Score bar -->
                    <div style="height: 100%; background: linear-gradient(90deg, ${u?"#28a745":"#dc3545"} 0%, ${u?"#34ce57":"#e74c3c"} 100%); width: ${c}%; border-radius: 6px; transition: width 0.3s ease-in-out; position: relative;">
                        <!-- Shine effect -->
                        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%); animation: progress-shine 2s infinite;"></div>
                    </div>
                </div>
                
                <div style="margin-top: 0.5rem; font-size: 0.85rem; color: #6c757d; font-style: italic;">
                    "${l.justification}"
                </div>
            </div>
        `}),s+=`
            </div>
            <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #dee2e6; font-size: 0.8rem; color: #6c757d;">
                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
                    <div style="width: 12px; height: 2px; background-color: #ffc107;"></div>
                    <span>Goal threshold</span>
                </div>
                ${n?`Generated on: ${new Date(n).toLocaleString()}`:"Timestamp not available"}
            </div>
        </div>
    `,a.innerHTML=s}function Xt(a,e=!1){const t=a.id===E,r=a.children.length>0,o=K.has(a.id);let i=`<div class="tree-item" style="padding-left: ${a.level*20}px;">`;if(r){const l=o?"▶":"▼";i+=`<span class="tree-expand-btn" data-node-id="${a.id}" style="cursor: pointer; margin-right: 4px; user-select: none; font-size: 12px;" title="Click: toggle this node | Double-click: toggle all nodes at this level">${l}</span>`}else i+='<span style="margin-right: 16px;"></span>';return i+=`<span class="${`tree-node ${t?"selected":""} ${e?"project-root":""}`}" data-id="${a.id}">
                ${a.title} ${a.isGenerating?'<span class="spinner" style="width:12px; height:12px; border-width: 2px;"></span>':""}
             </span>`,i+="</div>",r&&!o&&a.children.forEach(l=>{i+=Xt(l,!1)}),i}function so(a,e,t){const r=e.findNodeById(t);if(!r)return;const o=document.querySelector(".generation-section");if(!o)return;const n=o.getBoundingClientRect(),i={path:"The hierarchical path from root to this node",context:"Compiled contextual information from ancestors, siblings, and parent",title:"The title of the current node",content:"The current content of the node (if any)",draftorfresh:"Instructions for handling existing content (draft improvement or new generation)",child_level_name:"The name of the child level (for branch nodes)",count:"The number of items to generate (for list generation)"};let s;switch(a){case"path":s=e.getTreeService().getNodePath(t,e.rootNode);break;case"context":s=e.getContextService().compileNodeContext(t,e.rootNode);break;case"title":s=r.title;break;case"content":s=r.content||"";break;case"draftorfresh":r.content?r.content.startsWith("Draft:")?s=`You have this existing draft to build upon:
---
${r.content}
---

Please expand this draft into full, detailed content. Use the draft as a guide for what should be covered, but write complete, polished content that goes well beyond the brief draft description.`:s=`You have this existing content to revise or expand:
---
${r.content}
---

Please improve and expand this content.`:s="Now, write the full content for this node.";break;case"child_level_name":s=r.childLevelName||"";break;case"count":s="5";break;default:s=""}const l=document.createElement("div");l.className="placeholder-overlay",l.innerHTML=`
        <div class="placeholder-content" style="
            width: ${n.width}px;
            height: ${n.height}px;
            max-width: none;
            max-height: none;
            position: absolute;
            top: ${n.top+window.scrollY}px;
            left: ${n.left+window.scrollX}px;
        ">
            <div class="placeholder-header">
                <h3>{{${a}}}</h3>
                <button class="placeholder-close-btn" type="button">&times;</button>
            </div>
            <div class="placeholder-body">
                <div class="placeholder-description">
                    ${i[a]||"Placeholder value"}
                </div>
                <div class="placeholder-value ${s?"":"placeholder-empty"}">
                    ${s||"(empty)"}
                </div>
            </div>
        </div>
    `;const c=l.querySelector(".placeholder-close-btn"),d=()=>{l.remove()};c&&c.addEventListener("click",d),l.addEventListener("click",g=>{g.target===l&&d()});const u=g=>{g.key==="Escape"&&(d(),document.removeEventListener("keydown",u))};document.addEventListener("keydown",u),document.body.appendChild(l)}function Qt(){const a=x("main-content");a.addEventListener("click",e=>{if(!e.target||!(e.target instanceof HTMLElement))return;const t=e.target.closest("button");if(t){if(t.classList.contains("placeholder-btn")){const r=t.getAttribute("data-placeholder");r&&v&&E&&so(r,v,E);return}switch(t.id){case"default-prompt-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;const o=x("node-generation-prompt"),n=v.getRawGenerationPrompt(r);o.value=n,r.generationPrompt=n}break;case"node-generate-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;if(r.getState()==="Final"){const d=`This node contains final content that will be replaced.

Current content: "${r.content.substring(0,100)+(r.content.length>100?"...":"")}"

Are you sure you want to generate new content and replace the existing content?

This action cannot be undone.`;if(!confirm(d))return}const o=v.getGenerationCoordinator(),n=x("node-generation-prompt");r.generationPrompt=n.value;const i=x("generation-count-input"),s=i?parseInt(i.value,10):r.generationChildrenCount,l=o.startOperation("single-content",r.id,[r.id]);if(!l){alert("Another generation operation is already in progress. Please wait for it to complete.");return}v.getGenerationService().generateNodeContent(r.id,s).then(()=>{o.completeOperation(l,!0)}).catch(c=>{o.completeOperation(l,!1,c)})}break;case"node-generate-all-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;const o=v.getGenerationCoordinator();if(r.getState()==="Empty"){alert(`This node has no content. Please write or generate content for this node first.

The content should be an outline or description that can be used to create child nodes.`);return}const n=xe,i=Ce,s=d=>{const u=[d.id];for(const g of d.children)i?u.push(...s(g)):u.push(g.id);return u},l=s(r),c=o.startOperation("bulk-children",r.id,l);if(!c){alert("Another generation operation is already in progress. Please wait for it to complete.");return}console.log("🚀 Starting generateAllChildrenContent with:",{nodeId:r.id,includeContent:n,recursive:i}),v.getGenerationService().generateAllChildrenContent(r.id,n,i).then(()=>{console.log("✅ generateAllChildrenContent completed successfully"),o.completeOperation(c,!0)}).catch(d=>{console.error("❌ generateAllChildrenContent failed:",d),console.error("Error details:",d),o.completeOperation(c,!1,d)})}break;case"node-extract-context-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;D(()=>h(null,null,function*(){const{openExtractContextModal:o}=yield Promise.resolve().then(()=>Fe);return{openExtractContextModal:o}}),void 0).then(({openExtractContextModal:o})=>{o(v,r)}).catch(o=>{console.error("Failed to open extract context modal:",o),alert("Failed to open extract context dialog. Please try again.")})}break;case"context-info-btn":D(()=>h(null,null,function*(){const{ContextInfoModal:r}=yield import("./ContextInfoModal-D7FTTwSD.js");return{ContextInfoModal:r}}),__vite__mapDeps([3,1])).then(({ContextInfoModal:r})=>{new r().open()}).catch(r=>{console.error("Failed to open context info modal:",r),alert("Failed to open context information dialog. Please try again.")});break;case"regenerate-ratings-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;if(!r.content||r.content.trim()===""){alert("No content to rate. Please add content to this node first.");return}if(!confirm(`This will generate quality ratings for the current content.

Note: This uses AI tokens and may take a moment to complete.

Do you want to proceed?`))return;const n=v.getGenerationCoordinator(),i=n.startOperation("single-content",r.id,[r.id]);if(!i){alert("Another generation operation is already in progress. Please wait for it to complete.");return}v.getGenerationService().rateNodeContent(r.id).then(()=>{n.completeOperation(i,!0);const s=document.getElementById("show-ratings-checkbox");s&&(s.checked=!0,Je(!0))}).catch(s=>{n.completeOperation(i,!1,s)})}break;case"delete-node-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;if(r.level===0){const o=`Are you sure you want to delete the entire project "${r.title}"?

This will permanently delete:
- The project and all its content
- All child nodes and their content
- All generated summaries and history

This action cannot be undone.`;if(confirm(o)){const n=v;if(At(r.id),h(null,null,function*(){try{if(ve().length===0)n&&(yield n.clearAllProjectsFromStorage());else{const l=yield D(()=>Promise.resolve().then(()=>Q),void 0).then(d=>d.StorageService.getInstance());if(l.isIndexedDB()){const d=l.indexedDBService;d&&(yield d.delete("projects",r.id))}const c=se();c&&(yield c.saveToStorage())}}catch(s){console.error("Failed to update storage after project deletion:",s)}}),ve().length===0){E=null,v=null;const s=x("node-details");s.innerHTML='<div style="padding: 2rem; text-align: center; color: #6c757d;"><h3>No Projects</h3><p>All projects have been deleted. Create a new project to get started.</p></div>',U()}else Pe()}}else{const n=r.children.length>0?`
- ${r.children.length} child node(s) and all their content`:"",i=`Are you sure you want to delete "${r.title}"?

This will permanently delete:
- This node and its content
- Generated summary and history${n}

This action cannot be undone.`;if(confirm(i))if(v.removeNode(r.id)){v.saveToStorage().catch(console.error);const l=r.parentId?v.findNodeById(r.parentId):v.rootNode;E=l?l.id:v.rootNode.id,U(),X()}else alert("Failed to delete the node. It may be a root node or have an invalid parent.")}}break;case"delete-subnodes-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;if(r.children.length===0){alert("This node has no subnodes to delete.");return}const o=r.children.length,n=`Are you sure you want to delete all ${o} subnode(s) of "${r.title}"?

This will permanently delete:
- All ${o} child nodes and their content
- All nested subnodes and their content
- All generated summaries and history

The parent node "${r.title}" will remain intact.

This action cannot be undone.`;if(confirm(n)){const i=[...r.children];let s=0;for(const l of i)v.removeNode(l.id)&&s++;s>0?(v.saveToStorage().catch(console.error),U(),X(),alert(s===o?`Successfully deleted all ${s} subnodes.`:`Deleted ${s} out of ${o} subnodes. Some nodes may have failed to delete.`)):alert("Failed to delete any subnodes. Please try again.")}}break;case"export-node-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;D(()=>h(null,null,function*(){const{openExportModal:o}=yield Promise.resolve().then(()=>Fe);return{openExportModal:o}}),void 0).then(({openExportModal:o})=>{o(v,r)}).catch(o=>{alert("Failed to open export dialog. Please try again.")})}break;case"import-node-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;const o=document.createElement("input");o.type="file",o.accept=".json",o.style.display="none",o.addEventListener("change",n=>{var c;const s=(c=n.target.files)==null?void 0:c[0];if(!s)return;const l=new FileReader;l.onload=d=>{var u;try{const g=(u=d.target)==null?void 0:u.result,f=JSON.parse(g);v&&(lo(v,r.id,f),he(v))}catch(g){console.error("Import failed:",g),alert("Import failed: "+(g instanceof Error?g.message:"Invalid JSON file"))}},l.onerror=()=>{alert("Failed to read file. Please try again.")},l.readAsText(s)}),document.body.appendChild(o),o.click(),document.body.removeChild(o)}break;case"chat-node-btn":{if(!v||!E)return;const r=v.findNodeById(E);if(!r)return;D(()=>h(null,null,function*(){const{openNodeChatModal:o}=yield Promise.resolve().then(()=>Fe);return{openNodeChatModal:o}}),void 0).then(({openNodeChatModal:o})=>{o(v,r)}).catch(o=>{console.error("Failed to open chat modal:",o),alert("Failed to open chat dialog. Please try again.")})}break;case"version-prev-btn":ft("prev");break;case"version-next-btn":ft("next");break;case"use-this-version-btn":io();break;case"open-reader-btn":{if(!v){alert("No project is currently active. Please create or select a project first.");return}to(v,r=>{E=r,X()}).catch(r=>{console.error("Failed to open reader view:",r),alert("Failed to open reader view. Please try again.")})}break}}}),a.addEventListener("change",e=>h(null,null,function*(){if(!(!e.target||!(e.target instanceof HTMLElement))){if(e.target.id==="active-profile-selector"){const t=e.target,r=V();r&&(yield r.setLastUsedProfile(t.value),E&&X())}else if(e.target.id==="show-ratings-checkbox"){const t=e.target;Je(t.checked)}}}))}function Pe(a){const e=se();v=e,e&&(E=e.rootNode.id),ro().catch(console.error),oo().catch(console.error);const t=x("main-content"),r=V(),o=(r==null?void 0:r.getProfileNames())||[],n=(r==null?void 0:r.getLastUsedProfileName())||"default",i=o.map(s=>`<option value="${s}" ${n===s?"selected":""}>${s}</option>`).join("");if(t.innerHTML=`
        <style>
            #global-profile-bar {
                background-color: #f8f9fa;
                border-bottom: 1px solid var(--border-color);
                padding: 1rem;
                display: flex;
                align-items: center;
                gap: 1rem;
                margin-bottom: 1rem;
            }
            #global-profile-bar label {
                font-weight: bold;
                font-size: 1.1rem;
                color: #343a40;
                white-space: nowrap;
            }
            #global-profile-bar select {
                padding: 0.5rem;
                border: 1px solid var(--border-color);
                border-radius: 8px;
                font-size: 1rem;
                min-width: 200px;
            }
            #project-container { display: flex; gap: 1rem; align-items: flex-start; }
            #project-tree { flex: 1; max-width: 400px; }
            #node-details { flex: 2; }
            .tree-item { display: flex; align-items: center; }
            .tree-expand-btn { 
                color: #6c757d; 
                font-weight: bold;
                width: 16px;
                text-align: center;
            }
            .tree-expand-btn:hover { color: var(--primary-color); }
            .tree-node { 
                padding: 0.25rem 0.5rem; 
                border-radius: 4px; 
                cursor: pointer; 
                flex-grow: 1;
                margin-left: 2px;
            }
            .tree-node.selected { background-color: var(--primary-color); color: white; }
            .tree-node:hover:not(.selected) { background-color: #e9ecef; }
            .project-root {
                font-weight: bold;
                color: #495057;
                border-left: 3px solid var(--primary-color);
                background-color: #f8f9fa;
            }
            .details-view { background-color: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
            .details-view h2, .details-view h3 { margin-top: 0; }
            .details-view textarea, .details-view select, .details-view input { width: 100%; padding: 0.5rem; border-radius: 4px; border: 1px solid var(--border-color); }
            .details-view .form-group { margin-bottom: 1rem; }
            .action-buttons { display: flex; gap: 1rem; align-items: center; margin-top: 1rem; }
            .spinner {
                display: inline-block;
                width: 20px;
                height: 20px;
                border: 3px solid rgba(0,0,0,0.1);
                border-radius: 50%;
                border-top-color: var(--primary-color);
                animation: spin 1s ease-in-out infinite;
            }
            @keyframes spin { to { transform: rotate(360deg); } }
        </style>
        <div id="global-profile-bar">
            <label for="active-profile-selector">Active profile:</label>
            <select id="active-profile-selector">${i}</select>
            <span style="color: #6c757d; font-size: 0.9rem;">This profile will be used for all AI operations (Generate, Summarize, etc.)</span>
            <button id="open-reader-btn" style="margin-left: auto; padding: 0.5rem 1rem; border: 1px solid var(--border-color); border-radius: 8px; background: var(--primary-color); color: white; cursor: pointer; font-size: 0.9rem;">📖 Reader View</button>
        </div>
        <div id="project-container">
            <div id="project-tree"></div>
            <div id="node-details"></div>
        </div>
    `,U(),Me(),E)X();else{const s=x("node-details");s.innerHTML='<div style="padding: 2rem; text-align: center; color: #6c757d;">Select a node to view details.</div>'}}let B={operations:null,iterations:null,stages:null,detail:""};function te(a){const e=document.getElementById("generation-progress-container");if(!e)return;const t=x("progress-text-operations"),r=x("progress-bar-operations"),o=x("progress-text-iterations"),n=x("progress-bar-iterations"),i=x("progress-text-stages"),s=x("progress-bar-stages"),l=x("progress-text-detail");if(!a){B={operations:null,iterations:null,stages:null,detail:""},e.style.display="none";return}a.operations&&(B.operations=a.operations),a.iterations&&(B.iterations=a.iterations),a.stages&&(B.stages=a.stages),a.detail!==void 0&&(B.detail=a.detail),e.style.display="block",t.style.display="block",r.style.display="block",o.style.display="block",n.style.display="block",i.style.display="block",s.style.display="block";const c=(d,u,g)=>{const f=g>0?Math.round(u/g*100):0;d.style.width=`${f}%`};B.operations?(t.textContent=B.operations.message,c(r,B.operations.current,B.operations.total)):(t.textContent="",r.style.width="0%"),B.iterations?(o.textContent=B.iterations.message,c(n,B.iterations.current,B.iterations.total)):(o.textContent="",n.style.width="0%"),B.stages?(i.textContent=B.stages.message,c(s,B.stages.current,B.stages.total)):(i.textContent="",s.style.width="0%"),l.textContent=B.detail||"",l.style.display=B.detail?"block":"none"}window.updateProgressUI=te;window.showGenerationOverlay=ao;window.hideGenerationOverlay=me;window.showGlobalAbortButton=Vt;window.hideGlobalAbortButton=Me;function ao(){const a=x("content-display-area");if(!a){console.warn("Content display area not found, cannot show overlay");return}const e=document.getElementById("generation-overlay");e&&e.remove();const t=document.createElement("div");t.id="generation-overlay",t.style.cssText=`
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(248, 249, 250, 0.95);
        z-index: 1000;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        border-radius: 8px;
        backdrop-filter: blur(2px);
    `,t.innerHTML=`
        <div style="text-align: center; padding: 2rem;">
            <div class="spinner" style="width: 32px; height: 32px; border-width: 3px; margin-bottom: 1rem;"></div>
            <h3 style="margin: 0 0 0.5rem 0; color: #495057;">Generation in Progress</h3>
            <p style="margin: 0; color: #6c757d; font-size: 0.9rem;">Content is being generated and will appear here</p>
        </div>
    `,a.style.position="relative",a.appendChild(t)}function me(){const a=document.getElementById("generation-overlay");a&&a.remove();const e=x("content-display-area");e&&(e.style.position="")}function U(){const a=x("project-tree"),e=ve();if(e.length===0){a.innerHTML='<div style="padding: 2rem; text-align: center; color: #6c757d;">No projects available. Create a new project to get started.</div>';return}let t="";e.forEach(r=>{t+=Xt(r.rootNode,!0)}),a.innerHTML=t,a.querySelectorAll(".tree-node").forEach(r=>{r.addEventListener("click",o=>{o.stopPropagation();const n=o.currentTarget.dataset.id;if(n){let i=null,s=null;for(const l of e)if(s=l.findNodeById(n),s){i=l;break}if(s&&i){if(s.isGenerating)return;E=n,v=i,Xe(i.rootNode.id),U(),X()}}})}),a.querySelectorAll(".tree-expand-btn").forEach(r=>{r.addEventListener("click",o=>{o.stopPropagation();const n=o.currentTarget.dataset.nodeId;n&&(K.has(n)?K.delete(n):K.add(n),ut().catch(console.error),U())}),r.addEventListener("dblclick",o=>{o.stopPropagation();const n=o.currentTarget.dataset.nodeId;if(n){let i=null,s=null;for(const l of e)if(s=l.findNodeById(n),s){i=l;break}if(s&&i){const l=i.getTreeService().getNodesAtLevel(s.level,i.rootNode);K.has(n)?l.forEach(d=>{d.children.length>0&&K.delete(d.id)}):l.forEach(d=>{d.children.length>0&&K.add(d.id)}),ut().catch(console.error),U()}}})})}function Zt(a){if(!a.children||!Array.isArray(a.children)||a.children.length===0)return 0;let e=0;for(const t of a.children){const r=Zt(t);e=Math.max(e,r)}return 1+e}function lo(a,e,t){const r=a.findNodeById(e);if(!r)throw new Error("Target node not found");if(!t||typeof t!="object")throw new Error("Invalid import data: Expected JSON object");if(!t.title)throw new Error("Invalid import data: Missing title field");if(t.children&&Array.isArray(t.children)&&t.children.length>0){const o=Zt(t),n=r.level,i=r.template.length,s=i-n-1;if(o>s)throw new Error(`Hierarchy mismatch: The imported data has ${o} levels of children, but the target node can only accommodate ${s} more levels.

Target node is at level ${n} in a ${i}-level template (${r.template.join(" → ")}).`)}t.title!==void 0&&(r.title=t.title),t.content!==void 0&&(r.content=t.content),t.context!==void 0&&(r.context=t.context),t.generationPrompt!==void 0&&(r.generationPrompt=t.generationPrompt),t.children&&Array.isArray(t.children)&&t.children.length>0&&(r.children.length>0&&confirm(`The target node "${r.title}" already has ${r.children.length} children.

Click OK to REPLACE all existing children with imported ones.
Click Cancel to APPEND imported children to existing ones.`)&&r.children.forEach(i=>{a.removeNode(i.id)}),t.children.forEach((n,i)=>{er(a,r.id,n,i)})),a.saveToStorage().catch(console.error)}function er(a,e,t,r){if(!t.title){console.warn(`Skipping child node at index ${r}: Missing title`);return}const o=a.addNode(t.title,e);t.content!==void 0&&(o.content=t.content),t.context!==void 0&&(o.context=t.context),t.generationPrompt!==void 0&&(o.generationPrompt=t.generationPrompt),t.children&&Array.isArray(t.children)&&t.children.forEach((n,i)=>{er(a,o.id,n,i)})}const co=Object.freeze(Object.defineProperty({__proto__:null,initializeProjectUI:Pe,refreshGlobalProfileSelector:Kt,renderNodeDetails:X,renderProjectUI:he,setupEventListeners:Qt},Symbol.toStringTag,{value:"Module"})),mt="openrouter_api_key",He="openrouter_model_purposes",Ae=[{key:"creator",label:"Creator"},{key:"rater",label:"Rater"},{key:"editor",label:"Editor"}];function yt(a){const e=[];if(a.prompt){const t=parseFloat(a.prompt);if(!isNaN(t)){const r=t*1e6;e.push(`Input: $${r.toLocaleString(void 0,{maximumFractionDigits:2})} per million tokens`)}}if(a.completion){const t=parseFloat(a.completion);if(!isNaN(t)){const r=t*1e6;e.push(`Output: $${r.toLocaleString(void 0,{maximumFractionDigits:2})} per million tokens`)}}return e}class ho{constructor(e,t){p(this,"onSelect");p(this,"closeModal");p(this,"apiKey","");p(this,"models",[]);p(this,"loading",!1);p(this,"testing",!1);p(this,"error",null);p(this,"fetched",!1);p(this,"selectedModels",{});p(this,"root",null);p(this,"storageService");p(this,"initializationPromise");this.onSelect=e,this.closeModal=t,this.storageService=$.getInstance(),this.initializationPromise=this.initializeAsync()}waitForInitialization(){return h(this,null,function*(){return this.initializationPromise})}initializeAsync(){return h(this,null,function*(){yield this.loadFromStorage(),this.apiKey&&!this.fetched&&(yield this.fetchModels())})}render(e){this.root=e,this.update()}update(){if(!this.root)return;this.root.innerHTML="";const e=document.createElement("div");e.className="model-selector-container",e.style.width="100%",e.style.padding="2vw 2vw 2vw 2vw",e.style.background="rgba(255,255,255,0.95)",e.style.borderRadius="1.5rem",e.style.boxShadow="0 4px 32px 0 rgba(0,0,0,0.10), 0 1.5px 6px 0 rgba(0,0,0,0.08)",e.style.display="flex",e.style.flexDirection="column",e.style.gap="1.5rem",e.style.boxSizing="border-box";const t=document.createElement("h2");t.textContent="Configure OpenRouter Models",t.style.fontSize="1.5rem",t.style.fontWeight="bold",t.style.marginBottom="0.5rem",t.style.textAlign="center",t.style.letterSpacing="0.01em",t.style.background="linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)",t.style.color="white",t.style.borderRadius="1rem",t.style.padding="0.75rem 0",t.style.boxShadow="0 2px 8px 0 rgba(59,130,246,0.10)",e.appendChild(t);const r=document.createElement("div");r.style.display="flex",r.style.flexDirection="column",r.style.gap="0.5rem",r.style.marginBottom="0.5rem";const o=document.createElement("input");o.type="password",o.placeholder="Enter OpenRouter API Key",o.value=this.apiKey,o.style.padding="0.75rem 1rem",o.style.border="1.5px solid #d1d5db",o.style.borderRadius="0.75rem",o.style.fontSize="1rem",o.style.background="#f9fafb",o.style.transition="border-color 0.2s",o.addEventListener("focus",()=>{o.style.borderColor="#3b82f6"}),o.addEventListener("blur",()=>{o.style.borderColor="#d1d5db"}),o.addEventListener("input",c=>h(this,null,function*(){this.apiKey=c.target.value,yield this.saveToStorage(),this.update()})),r.appendChild(o);const n=document.createElement("div");n.innerHTML="<strong>Info:</strong> Your API key and model selections are stored in your browser's IndexedDB. Anyone with access to this browser profile can view them.",n.style.fontSize="0.85rem",n.style.color="#b45309",n.style.background="#fef3c7",n.style.borderRadius="0.5rem",n.style.padding="0.5rem 0.75rem",r.appendChild(n);const i=document.createElement("div");i.style.display="flex",i.style.gap="0.75rem",i.style.width="100%";const s=document.createElement("button");s.textContent=this.testing?"Testing...":"Test API Key",s.disabled=this.testing||!this.apiKey,s.style.padding="0.75rem 1rem",s.style.background=this.testing||!this.apiKey?"#d1d5db":"#10b981",s.style.color="white",s.style.fontWeight="bold",s.style.border="none",s.style.borderRadius="0.75rem",s.style.fontSize="1rem",s.style.cursor=this.testing||!this.apiKey?"not-allowed":"pointer",s.style.transition="background 0.2s",s.style.flex="1",s.addEventListener("mouseenter",()=>{s.disabled||(s.style.background="#059669")}),s.addEventListener("mouseleave",()=>{s.disabled||(s.style.background="#10b981")}),s.addEventListener("click",()=>this.testApiKey()),i.appendChild(s);const l=document.createElement("button");if(l.textContent=this.loading?"Fetching...":"Fetch Models",l.disabled=this.loading||!this.apiKey,l.style.padding="0.75rem 1rem",l.style.background=this.loading||!this.apiKey?"#93c5fd":"linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)",l.style.color="white",l.style.fontWeight="bold",l.style.border="none",l.style.borderRadius="0.75rem",l.style.fontSize="1rem",l.style.cursor=this.loading||!this.apiKey?"not-allowed":"pointer",l.style.transition="background 0.2s",l.style.flex="1",l.addEventListener("mouseenter",()=>{l.disabled||(l.style.background="linear-gradient(90deg, #2563eb 0%, #0ea5e9 100%)")}),l.addEventListener("mouseleave",()=>{l.disabled||(l.style.background="linear-gradient(90deg, #3b82f6 0%, #06b6d4 100%)")}),l.addEventListener("click",()=>this.fetchModels()),i.appendChild(l),r.appendChild(i),e.appendChild(r),this.error){const c=document.createElement("p");c.textContent=`Error: ${this.error}`,c.style.color="#dc2626",c.style.background="#fee2e2",c.style.borderRadius="0.5rem",c.style.padding="0.5rem 0.75rem",c.style.fontWeight="bold",e.appendChild(c)}if(this.fetched&&!this.loading&&!this.error&&this.models.length>0){const c=document.createElement("div");c.style.display="grid",c.style.gridTemplateColumns="repeat(2, minmax(0, 1fr))",c.style.gap="1.5rem",c.style.width="100%",c.style.boxSizing="border-box",c.style.margin="0 auto",c.style.alignItems="stretch",c.style.justifyItems="stretch",c.style.maxWidth="100%",c.style.padding="0",c.style.gridTemplateRows="auto auto",c.style.gridAutoRows="1fr",c.style.gridAutoFlow="row",Ae.forEach(w=>{const y=document.createElement("div");y.style.background="#f3f4f6",y.style.border="1.5px solid #d1d5db",y.style.borderRadius="1rem",y.style.padding="1rem 1.25rem",y.style.boxShadow="0 1px 4px 0 rgba(0,0,0,0.04)",y.style.display="flex",y.style.flexDirection="column",y.style.gap="0.5rem",y.style.height="100%";const S=document.createElement("div");S.textContent=`${w.label} Model`,S.style.fontWeight="bold",S.style.marginBottom="0.25rem",y.appendChild(S);const b=document.createElement("select");b.style.padding="0.5rem 1rem",b.style.border="1.5px solid #d1d5db",b.style.borderRadius="0.75rem",b.style.fontSize="1rem",b.style.background="#fff",b.style.transition="border-color 0.2s",b.addEventListener("focus",()=>{b.style.borderColor="#3b82f6"}),b.addEventListener("blur",()=>{b.style.borderColor="#d1d5db"});const P=document.createElement("option");P.value="",P.disabled=!0,P.textContent="Select a model...",b.appendChild(P),[...this.models].sort((G,A)=>G.name.localeCompare(A.name)).forEach(G=>{const A=document.createElement("option");A.value=G.id,A.textContent=G.name,b.appendChild(A)});const k=this.models.find(G=>G.id===this.selectedModels[w.key]);b.value=k?k.id:"";let L=document.createElement("div"),M;k?(L.textContent=k.description,L.style.fontSize="0.95rem",L.style.color="#374151",L.style.marginTop="0.25rem",y.appendChild(L),k.pricing&&(M=document.createElement("ul"),M.style.listStyle="disc inside",M.style.marginLeft="1.5rem",M.style.marginTop="0.5rem",yt(k.pricing).forEach(G=>{const A=document.createElement("li");A.textContent=G,A.style.fontSize="0.9rem",A.style.color="#2563eb",M&&M.appendChild(A)}),y.appendChild(M))):(L.textContent="",y.appendChild(L)),b.addEventListener("change",G=>{this.selectedModels[w.key]=G.target.value;const A=this.models.find(z=>z.id===this.selectedModels[w.key]);L.textContent=A?A.description:"",M&&(M.innerHTML="",A&&A.pricing&&yt(A.pricing).forEach(z=>{const ae=document.createElement("li");ae.textContent=z,ae.style.fontSize="0.9rem",ae.style.color="#2563eb",M==null||M.appendChild(ae)})),this.update()}),y.appendChild(b),k&&M&&y.appendChild(M),c.appendChild(y)}),e.appendChild(c);const d=document.createElement("div");d.style.display="flex",d.style.justifyContent="flex-end",d.style.gap="1rem",d.style.marginTop="1.5rem";const u=document.createElement("button");u.textContent="Cancel",u.disabled=!0,this.isSavedConfigValid().then(w=>{u.disabled=!w}),u.addEventListener("click",()=>{this.closeModal()}),d.appendChild(u);const g=document.createElement("button"),f=this.areAllModelsSelected();g.textContent="Save and Close",g.disabled=!f,g.addEventListener("click",()=>h(this,null,function*(){this.areAllModelsSelected()&&(yield this.saveToStorage(),this.onSelect(this.selectedModels))})),d.appendChild(g),e.appendChild(d)}this.root.appendChild(e)}testApiKey(){return h(this,null,function*(){this.testing=!0,this.error=null,this.update();try{const t=yield new we(this.apiKey).fetchModels();t&&t.length>0?(this.error=null,alert(`✅ API Key is valid! Found ${t.length} available models. You can now fetch models and configure the service.`)):alert("⚠️ API Key appears to work, but no models were returned. You may want to check your account status.")}catch(e){const t=e instanceof Error?e.message:"Unknown error occurred";this.error=`API Key Test Failed: ${t}`,alert(`❌ API Key Test Failed: ${t}`)}finally{this.testing=!1,this.update()}})}fetchModels(){return h(this,null,function*(){this.loading=!0,this.error=null,this.fetched=!1,this.update();try{const e=new we(this.apiKey);this.models=yield e.fetchModels();const t=new Set(this.models.map(r=>r.id));for(const r of Ae)this.selectedModels[r.key]&&!t.has(this.selectedModels[r.key])&&(this.selectedModels[r.key]="");this.fetched=!0}catch(e){const t=e instanceof Error?e.message:"Unknown error occurred";throw this.error=t,e}finally{this.loading=!1,this.update()}})}loadFromStorage(){return h(this,null,function*(){try{const e=yield this.storageService,t=yield e.get(mt);t&&(this.apiKey=t);const r=yield e.get(He);r&&(this.selectedModels=r)}catch(e){console.error("Failed to load model configuration from storage",e),this.selectedModels={},this.apiKey=""}})}saveToStorage(){return h(this,null,function*(){try{const e=yield this.storageService;yield e.set(mt,this.apiKey),yield e.set(He,this.selectedModels)}catch(e){console.error("Failed to save model configuration to storage",e)}})}areAllModelsSelected(){return Ae.every(e=>this.selectedModels[e.key]&&this.selectedModels[e.key]!=="")}setSelectedModels(e){return h(this,null,function*(){this.selectedModels=T({},e),yield this.saveToStorage(),this.update()})}getSelectedModels(){return this.selectedModels}getApiKey(){return this.apiKey}isSavedConfigValid(){return h(this,null,function*(){try{const t=yield(yield this.storageService).get(He);return t?Ae.every(r=>t[r.key]):!1}catch(e){return console.error("Failed to check saved config validity",e),!1}})}}let _=null,q=!1,ie=!1;function po(){try{const a=Y();if(!a){alert("Template manager is not initialized.");return}_=a.getTemplateNames()[0]||null;const r=Rt({content:`
        <style>
            #template-editor-container { display: flex; flex-direction: column; gap: 1.5rem; }
            .template-controls { display: flex; gap: 1rem; align-items: center; }
            .template-controls select, .template-controls input { flex-grow: 1; padding: 0.5rem; }
            .hierarchy-editor { display: flex; flex-direction: column; gap: 0.5rem; }
            .hierarchy-layer { display: flex; align-items: center; gap: 0.5rem; }
            .hierarchy-layer input { flex-grow: 1; padding: 0.5rem; }
            .template-actions { display: flex; justify-content: flex-end; gap: 1rem; margin-top: 1rem; }
        </style>
        <div id="template-editor-container">
            <h2>Manage Templates</h2>
            <div class="template-controls">
                <select id="template-select"></select>
                <button id="delete-template-btn" class="button button-danger">Delete</button>
                <button id="restore-defaults-btn" class="button button-secondary" style="background-color: #fd7e14; color: white; border-color: #fd7e14;">Restore Defaults</button>
            </div>
            <div class="template-controls">
                <input type="text" id="template-name-input" placeholder="Enter template name..."/>
                <button id="save-as-new-btn" class="button button-secondary">Save as New</button>
            </div>
            <div id="hierarchy-editor-container">
                <h3>Hierarchy Levels</h3>
                <div id="hierarchy-editor" class="hierarchy-editor"></div>
                <button id="add-layer-btn" class="button button-secondary" style="margin-top: 0.5rem;">+ Add Level</button>
            </div>
        </div>
    `,actions:[{id:"cancel",label:"✕ Close",type:"secondary",handler:()=>h(null,null,function*(){if(q&&!confirm("You have unsaved changes. Are you sure you want to cancel?"))throw new Error("__KEEP_MODAL_OPEN__");r.close()})},{id:"save",label:"Save Changes",type:"primary",handler:()=>h(null,null,function*(){xo(r)})}]},{title:"Manage Templates",maxWidth:"800px"},{onOpen:()=>{uo()}})}catch(a){console.error("❌ Error in openTemplateEditor:",a),alert("Failed to open template editor: "+(a instanceof Error?a.message:"Unknown error"))}}function uo(){q=!1,Te(),ge(),x("template-select").addEventListener("change",go),x("save-as-new-btn").addEventListener("click",mo),x("delete-template-btn").addEventListener("click",yo),x("restore-defaults-btn").addEventListener("click",bo),x("add-layer-btn").addEventListener("click",vo),x("hierarchy-editor").addEventListener("click",a=>{a.target.classList.contains("remove-layer-btn")&&wo(a.target)}),x("template-editor-container").addEventListener("input",a=>{a.target.id!=="template-select"&&(ie||(q=!0))})}function go(a){if(q&&!confirm("You have unsaved changes. Are you sure you want to switch?")){a.target.value=_||"";return}_=a.target.value,q=!1,ge()}function fo(){const a=Y(),e=x("template-name-input");if(!a||!_)return;const t=e.value.trim();if(!t){alert("Template name cannot be empty.");return}const r=rr();try{if(t!==_){if(a.getTemplate(t)){alert(`A template named '${t}' already exists. Please choose a different name or use 'Save as New'.`);return}a.getTemplateNames().length>1&&a.deleteTemplate(_)}a.saveTemplate(t,r),q=!1,alert(`Template '${t}' saved successfully.`),_=t,Te(),ge()}catch(o){throw alert(`Error saving template: ${o.message}`),o}}function mo(){const a=Y(),e=x("template-name-input");if(!a)return;const t=e.value.trim();if(!t){alert("Please enter a name for the new template.");return}if(a.getTemplate(t)){alert(`A template named '${t}' already exists. Please choose a different name.`);return}const r=rr();try{a.saveTemplate(t,r),q=!1,alert(`Template '${t}' created successfully.`),_=t,Te(),ge()}catch(o){alert(`Error creating template: ${o.message}`)}}function yo(){const a=Y();if(!(!a||!_)&&confirm(`Are you sure you want to delete the template '${_}'?`))try{a.deleteTemplate(_),_=a.getTemplateNames()[0]||null,q=!1,Te(),ge(),alert("Template deleted.")}catch(e){alert(`Error deleting template: ${e.message}`)}}function bo(){const a=Y();if(a&&confirm("Are you sure you want to restore all templates to defaults? This will remove any custom templates you have created."))try{a.restoreDefaults(),_=a.getTemplateNames()[0]||null,q=!1,Te(),ge(),alert("Templates restored to defaults successfully.")}catch(e){alert(`Error restoring defaults: ${e.message}`)}}function vo(){const a=x("hierarchy-editor"),e=a.children.length,t=tr("",e);a.appendChild(t),q=!0}function wo(a){var t;(t=a.closest(".hierarchy-layer"))==null||t.remove();const e=x("hierarchy-editor");Array.from(e.children).forEach((r,o)=>{const n=r.querySelector("input");n&&(n.dataset.index=String(o))}),q=!0}function xo(a){try{fo(),a.close()}catch(e){throw new Error("__KEEP_MODAL_OPEN__")}}function Te(){const a=Y(),e=x("template-select");if(!a||!e)return;ie=!0;const t=a.getTemplateNames().sort();e.innerHTML=t.map(r=>`<option value="${r}">${r}</option>`).join(""),_&&(e.value=_),ie=!1}function ge(){const a=Y(),e=x("template-name-input"),t=x("hierarchy-editor");if(!a||!e||!t)return;if(ie=!0,!_){e.value="",t.innerHTML="No template selected.",ie=!1;return}const r=a.getTemplate(_);if(!r){e.value="",t.innerHTML=`Template '${_}' not found.`,ie=!1;return}e.value=r.name,t.innerHTML="",r.hierarchyLevels.forEach((o,n)=>{const i=tr(o,n);t.appendChild(i)}),ie=!1,q=!1}function tr(a,e){const t=document.createElement("div");return t.className="hierarchy-layer",t.innerHTML=`
        <input type="text" value="${a}" data-index="${e}" placeholder="e.g., Chapter" />
        <button class="remove-layer-btn button button-danger">-</button>
    `,t}function rr(){const a=x("template-name-input"),e=x("hierarchy-editor"),t=a.value.trim(),r=[];e.querySelectorAll(".hierarchy-layer input").forEach(s=>{r.push(s.value)});const o=Y(),n=_?o==null?void 0:o.getTemplate(_):void 0,i=n?n.scaffoldingDocuments:[];return new C(t,r,i)}function Co(a){const e=De(),t=V();if(!e||!t)return;or();const r=t.getLastUsedProfileName()||"default",o=t.getProfile(r)||{prompt:"",criteria:[],maxIterations:5,selectedModels:{},contextExtractionPrompt:`Extract relevant context from the following content for use in generating new content:

{{content}}

Provide a clear, structured summary of the key information that would be useful for content generation.`};o.selectedModels=a,t.saveProfile(r,o)}function or(){const a=De(),e=V();if(!a){console.error("ModelSelector not available. Cannot configure services.");return}const t=new we(a.getApiKey(),a.getSelectedModels());e&&t.setSettingsManager(e);const r=new Ut(t,Tt()||void 0);Nt(t),kt(r)}function bt(a,e){const t=$e(),r=V(),o=Se();if(!t||!r||!o){alert("Core services not initialized. Cannot create project.");return}const n=new N(a,e,t,r,o);Ee(n),n.saveToStorage(),Re(),Pe()}function So(a,e,t){const r=$e(),o=V(),n=Se();if(!r||!o||!n){alert("Core services not initialized. Cannot import project.");return}try{const i=new N(a,e,r,o,n),s=i.rootNode;t.title!==void 0&&(s.title=t.title,i.projectTitle=t.title),t.content!==void 0&&(s.content=t.content),t.context!==void 0&&(s.context=t.context),t.generationPrompt!==void 0&&(s.generationPrompt=t.generationPrompt),t.children&&Array.isArray(t.children)&&t.children.forEach((l,c)=>{nr(i,s.id,l,c)}),Ee(i),i.saveToStorage(),Pe(),alert(`Project "${a}" imported successfully!`)}catch(i){console.error("Import project failed:",i),alert("Import failed: "+(i instanceof Error?i.message:"Unknown error"))}}function nr(a,e,t,r){if(!t.title){console.warn(`Skipping child node at index ${r}: Missing title`);return}const o=a.addNode(t.title,e);t.content!==void 0&&(o.content=t.content),t.context!==void 0&&(o.context=t.context),t.generationPrompt!==void 0&&(o.generationPrompt=t.generationPrompt),t.children&&Array.isArray(t.children)&&t.children.forEach((n,i)=>{nr(a,o.id,n,i)})}function Eo(){return h(this,null,function*(){try{const a=$e(),e=V(),t=Se();if(!a||!e||!t)throw new Error("Cannot load projects without core services.");const{projects:r,activeProjectId:o}=yield N.loadAllProjectsFromStorage(a,e,t);r.forEach(n=>Ee(n)),o&&Xe(o)}catch(a){console.error("Failed to load projects from storage:",a);try{const e=yield D(()=>Promise.resolve().then(()=>Q),void 0).then(t=>t.StorageService.getInstance());yield e.delete("expert_app_current_project"),yield e.delete("expert_app_projects"),yield e.delete("expert_app_active_project")}catch(e){console.error("Failed to cleanup corrupted storage:",e)}}})}function Po(){return h(this,null,function*(){console.log("🔍 Running browser compatibility check...");const{compatible:a,issues:e}=we.checkBrowserCompatibility();if(a)console.log("✅ Browser compatibility check passed");else if(console.warn("⚠️ Browser compatibility issues detected:",e),e.length>0){const i=e.join(`
• `);alert(`⚠️ Browser Compatibility Warning

The following features may not work properly:
• ${i}

Please consider updating your browser or trying a different browser.`)}try{mr()}catch(i){console.error("❌ DOM validation failed:",i)}const t=new de;It(t);const r=new qt;Mt(r);const o=new ho(Co,()=>{});Lt(o),yield t.waitForInitialization(),yield o.waitForInitialization();const n=Ot({settingsManager:t,modelSelector:o,refreshGlobalProfileSelector:()=>{D(()=>h(null,null,function*(){const{refreshGlobalProfileSelector:i}=yield Promise.resolve().then(()=>co);return{refreshGlobalProfileSelector:i}}),void 0).then(({refreshGlobalProfileSelector:i})=>{i()})}});jt(n),or(),yield Eo(),Pe();try{x("settingsBtn").addEventListener("click",()=>{We()})}catch(i){console.error("❌ Failed to attach settings button listener:",i)}try{x("runTestsBtn").addEventListener("click",()=>{h(null,null,function*(){const i=Se();if(!i){alert("API client not initialized. Cannot run tests.");return}fe(`
                <h2>Select Test Suite</h2>
                <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1.5rem;">
                    <button id="runCoreTestsBtn" class="button button-primary" style="padding: 1rem; font-size: 1rem;">
                        Core Functionality Tests
                        <div style="font-size: 0.875rem; opacity: 0.8; margin-top: 0.25rem;">
                            Document nodes, project management, templates, tree operations
                        </div>
                    </button>
                    <button id="runStorageTestsBtn" class="button button-primary" style="padding: 1rem; font-size: 1rem;">
                        Storage System Tests
                        <div style="font-size: 0.875rem; opacity: 0.8; margin-top: 0.25rem;">
                            IndexedDB, storage abstraction, service layer storage
                        </div>
                    </button>
                    <button id="runAllTestsBtn" class="button button-secondary" style="padding: 1rem; font-size: 1rem;">
                        Run All Tests
                        <div style="font-size: 0.875rem; opacity: 0.8; margin-top: 0.25rem;">
                            Complete test suite (may take longer)
                        </div>
                    </button>
                </div>
            `);const l=()=>h(null,null,function*(){const g=yield new ze(i).runPhase1Tests();fe(g)}),c=()=>h(null,null,function*(){const g=yield new ze(i).runStorageTests();fe(g)}),d=()=>h(null,null,function*(){const u=new ze(i),g=yield u.runPhase1Tests(),f=yield u.runStorageTests(),w=`
                    ${g}
                    <hr style="margin: 2rem 0;">
                    ${f}
                `;fe(w)});setTimeout(()=>{var u,g,f;(u=document.getElementById("runCoreTestsBtn"))==null||u.addEventListener("click",()=>void l()),(g=document.getElementById("runStorageTestsBtn"))==null||g.addEventListener("click",()=>void c()),(f=document.getElementById("runAllTestsBtn"))==null||f.addEventListener("click",()=>void d())},100)})})}catch(i){console.error("❌ Failed to attach run tests button listener:",i)}try{x("newProjectBtn").addEventListener("click",()=>Ke(bt))}catch(i){console.error("❌ Failed to attach new project button listener:",i)}try{x("importProjectBtn").addEventListener("click",()=>{const i=document.createElement("input");i.type="file",i.accept=".json",i.style.display="none",i.addEventListener("change",s=>{var u;const c=(u=s.target.files)==null?void 0:u[0];if(!c)return;const d=new FileReader;d.onload=g=>{var f;try{const w=(f=g.target)==null?void 0:f.result,y=JSON.parse(w);let S=y.template;if(!S||!S.name||!S.hierarchyLevels||!S.scaffoldingDocuments)if(y.template&&Array.isArray(y.template))S={name:`Imported Template (${y.title||"Unknown"})`,hierarchyLevels:y.template,scaffoldingDocuments:[]};else if(y.children&&y.children.length>0){let P=null;for(const I of y.children)if(I.template&&Array.isArray(I.template)){P=I.template;break}if(P)S={name:`Imported Template (${y.title||"Unknown"})`,hierarchyLevels:P,scaffoldingDocuments:[]};else throw new Error("Invalid import file: Missing or incomplete template information")}else throw new Error("Invalid import file: Missing or incomplete template information");const b=new C(S.name,S.hierarchyLevels,S.scaffoldingDocuments);So(y.title||"Imported Project",b,y)}catch(w){console.error("Import failed:",w),alert("Import failed: "+(w instanceof Error?w.message:"Invalid JSON file"))}},d.onerror=()=>{alert("Failed to read file. Please try again.")},d.readAsText(c)}),document.body.appendChild(i),i.click(),document.body.removeChild(i)})}catch(i){console.error("❌ Failed to attach import project button listener:",i)}try{x("manageTemplatesBtn").addEventListener("click",po)}catch(i){console.error("❌ Failed to attach manage templates button listener:",i)}try{x("globalAbortBtn").addEventListener("click",()=>{const i=se();i&&i.getGenerationService().canAbortGeneration()&&confirm("Are you sure you want to abort the current generation? Any partial progress will be saved.")&&i.getGenerationService().abortCurrentGeneration()})}catch(i){console.error("❌ Failed to attach global abort button listener:",i)}Ie().addEventListener("click",i=>{i.target===Ie()&&Gt()}),Le().addEventListener("click",i=>{i.target===Le()&&Re()}),!o.getApiKey()||!o.areAllModelsSelected()?We():se()||Ke(bt)})}const To=new URLSearchParams(window.location.search);To.get("clean")==="true"&&h(null,null,function*(){try{const{StorageService:a}=yield D(()=>h(null,null,function*(){const{StorageService:t}=yield Promise.resolve().then(()=>Q);return{StorageService:t}}),void 0);yield(yield a.getInstance()).clear(),window.location.href=window.location.pathname}catch(a){console.error("Failed to clear storage:",a),alert("Failed to clear application data. Please try again or contact support.")}});document.addEventListener("DOMContentLoaded",()=>{h(null,null,function*(){yield Po(),Qt()})});export{Ue as A,Qe as B,Ir as C,$t as E,Dt as G,qe as M,kr as P,Ar as S,O as a,Tr as b,Lr as c,Mr as d,$r as e,Bt as f,Pr as g,Ot as h,jt as i,ue as j,Dr as k,Rr as l,_r as m,Br as n,We as o,Oe as p,Ne as q,it as r,Rt as s,le as t,m as u,st as v,re as w,$ as x};
